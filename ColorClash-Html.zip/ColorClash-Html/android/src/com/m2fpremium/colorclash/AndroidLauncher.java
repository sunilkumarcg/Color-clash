package com.m2fpremium.colorclash;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.widget.Toast;

import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;

public class AndroidLauncher extends AndroidApplication implements AndroidOnlyInterface {
	final AndroidLauncher context=this;


	AndroidApplicationConfiguration config;

	private PhoneStateListener mPhoneStateListener;
	private TelephonyManager mgr;
	private AudioManager audio;

	int adcnt=0,adInd=0;

	public static PackageManager pm;

	@Override
	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		config = new AndroidApplicationConfiguration();
		config.useImmersiveMode = true;
		config.hideStatusBar = true;

		pm=this.getPackageManager();
		telephone();

		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

	
		initialize(new MyGdxGame(this), config);
		
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int width = displaymetrics.widthPixels;
		int height = displaymetrics.heightPixels;
		
		constants.ConstantValues.isAndroidDevice=true;
		
		constants.ConstantValues.inputX =width/2; /*ConstantValues.CAMERA_WIDTH*/
		
		//System.out.println("hgt:"+height);
	/*	if (height > 1300 && isTablet(this)) {
			constants.ConstantValues.CAMERA_WIDTH = 960;
			constants.ConstantValues.xAdjPos = 80;
		}*/
		
	}

	@Override
	public void showToast(final String str1) {
		// TODO Auto-generated method stub
	//	System.out.println(str1);
		runOnUiThread(new Runnable() {
			public void run() {
				
				Toast.makeText(AndroidLauncher.this,str1, Toast.LENGTH_SHORT).show();
			}
		});
	}
	
	private void PauseTheGame() {
		// TODO Auto-generated method stub
		if (GameStateManager.GAMEPLAY== constants.ConstantValues.stateNo) {
			if (!GamePlay.gameState.equals("pause") && !GamePlay.gameState.contains("gameover") && !GamePlay.gameState.contains("saveme")) {
				GamePlay.gameState = "pause";
			}
		}
		if (GameStateManager.ENDLESSPLAY== constants.ConstantValues.stateNo) {
			if (!EndlessPlay.gameState.equals("pause") && !EndlessPlay.gameState.contains("gameover")&& !EndlessPlay.gameState.contains("saveme")) {
				EndlessPlay.gameState="pause";
			}
		}
		if (GameStateManager.DASHPLAY== constants.ConstantValues.stateNo) {
			if (!DashPlay.gameState.equals("pause") && !DashPlay.gameState.contains("gameover")&& !DashPlay.gameState.contains("saveme")) {
				DashPlay.gameState="pause";
			}
		}
		if (GameStateManager.SPINPLAY== constants.ConstantValues.stateNo) {
			if (!SpinPlay.gameState.equals("pause") && !SpinPlay.gameState.contains("gameover")&& !SpinPlay.gameState.contains("saveme")) {
				SpinPlay.gameState="pause";
			}
		}
	}
	
	@Override
	public  void onPause() {
		// TODO Auto-generated method stub
		
		PauseTheGame();
		super.onPause();
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}


	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
	
		config.useImmersiveMode = true;
		config.hideStatusBar = true;

	}



	private void telephone() {

		// Prefs.getSound();
		mPhoneStateListener = new PhoneStateListener() {
			protected boolean mWasPlayingWhenCalled = false;

			@Override
			public void onCallStateChanged(int state, String incomingNumber) {
				if (state == TelephonyManager.CALL_STATE_RINGING) {	
					PauseTheGame();
					mWasPlayingWhenCalled = true;
				} else if (state == TelephonyManager.CALL_STATE_IDLE) {
					if (mWasPlayingWhenCalled) {						
						mWasPlayingWhenCalled = false;
					}
				} else if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
					
				}

				super.onCallStateChanged(state, incomingNumber);
			}
		};
		mgr = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
		mgr.listen(mPhoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);

		audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
	}
	
	public static boolean isTablet(Context context) {
		return (context.getResources().getConfiguration().screenLayout
				& Configuration.SCREENLAYOUT_SIZE_MASK)
				>= Configuration.SCREENLAYOUT_SIZE_LARGE;
	}

	
}
