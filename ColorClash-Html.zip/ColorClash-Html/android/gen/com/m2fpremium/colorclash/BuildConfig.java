/** Automatically generated file. DO NOT MODIFY */
package com.m2fpremium.colorclash;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}