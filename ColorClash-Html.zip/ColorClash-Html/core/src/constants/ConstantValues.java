package constants;

import com.m2fpremium.colorclash.LocalizedStrings;

public class ConstantValues {
	
	public static final String  TITLE = LocalizedStrings.APP_NAME;
	

    public static int CAMERA_WIDTH = 800;
    public static int CAMERA_HEIGHT = 1280;
    
    public final static int CAMERA_HEIGHT_lmt = (int) (CAMERA_HEIGHT/2.5f);
    
    public static int stateNo=0;

    public static int inputX = 200;
	 public static int xAdjPos = 0; // for samsung s7 purpose

    public static int totColors = 4;
    public static char pattern = 'r';
    public static int setno = 1;
    
    public static float elapsedTime = 0f;
    public static float RUNNING_FRAME_DURATION = 0.76f;
    public static float accumulator = 0;
    
    public static boolean isMusicEnabled = true; //checge to true
    public static boolean isSoundEnabled = true;
    public static boolean isAndroidDevice = false;
    public static boolean isBSuspend = false;
    
    public static boolean isClassicTut = false;
    public static boolean isClassicTutorial = false;
    public static boolean isSpinTutorial = false;
    public static boolean isTapTapTutorial = false;
    
    public static boolean isClassicLeft = false;
    public static boolean isClassicRight = false;
    
    public static int classicCnt = 0;
    public static int classicSteps = 0;
    public static int taptapSteps = 0;
    public static int spinSteps = 0;
    
    public static int classicTotSteps = 5;
    public static int taptapTotSteps = 2; 
    public static int spinTotSteps = 1;

    public static int rateCnt = 0;
    public static boolean isShowRateUs = true;

    public static boolean isAdsLoaded = false;
    public static boolean isAdsCampaignEnabled = false;
    public static String adsOrientation = "portrait";

    public static int langCode=1;
}
