package com.m2fpremium.colorclash;

public class ScaleAnimation {
    private boolean Update;
    private float Xspeed;
    private float Yspeed;
    private boolean decr;
    private boolean incr;
    private float f103x;
    private float xLimit;
    private float f104y;
    private float yLimit;

    public boolean isUpdate() {
        return this.Update;
    }

    public void setUpdate(boolean update) {
        this.Update = update;
    }

    public ScaleAnimation(float Xspeed, float Yspeed, float xLimit, float yLimit, float imgScaleStartPointX,float imgScaleStartPointY ) {
        this.f103x = imgScaleStartPointX;
        this.f104y = imgScaleStartPointY;
        Initilize(f103x, f104y);
        this.Xspeed = Xspeed;
        this.Yspeed = Yspeed;
        this.xLimit = xLimit;
        this.yLimit = yLimit;
    }

    public void Initilize(float x, float y) {
        this.incr = true;
        this.decr = true;
        setScaleX(x);
        setScaleY(y);
    }

    public void update() {
        ScaleX();
        ScaleY();
    }

    public void update(boolean b) {
        if (b) {
            ScaleX();
            ScaleY();
        }
    }

    public float getScaleX() {
        return this.f103x;
    }

    public float getScaleY() {
        return this.f104y;
    }

    public void setScaleX(float x) {
        this.f103x = x;
    }

    public void setScaleY(float y) {
        this.f104y = y;
    }
    
    public void setScaleSpeedXX(float x){
    	this.Xspeed = x;
    }
    
    public void setScaleSpeedYY(float y){
    	this.Yspeed = y;
    }

    private void ScaleX() {
        if (this.incr) {
            this.f103x -= this.Xspeed;
        }
        if (this.f103x < this.xLimit && this.incr) {
            this.incr = false;
        }
        if (!this.incr && this.f103x <= 1.0f) {
            this.f103x += this.Xspeed;
        }
        if (!this.incr && this.f103x > 1.0f) {
            this.incr = true;
        }
    }

    private void ScaleY() {
        if (this.decr) {
            this.f104y -= this.Yspeed;
        }
        if (this.f104y < this.yLimit && this.decr) {
            this.decr = false;
        }
        if (!this.decr && this.f104y <= 1.0f) {
            this.f104y += this.Yspeed;
        }
        if (!this.decr && this.f104y > 1.0f) {
            this.decr = true;
        }
    }
}
