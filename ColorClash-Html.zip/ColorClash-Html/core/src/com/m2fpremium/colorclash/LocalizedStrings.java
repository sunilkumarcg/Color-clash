package com.m2fpremium.colorclash;

public class LocalizedStrings {
	public static final String APP_NAME="Color Clash";
	
	public static final String gamepause="GAME PAUSED";
	public static final String gameover="GAME OVER";
	
	public static final String backpress="Press back again to exit the game";
	
	public static  String aboutDesc="Version 1.0.0 \nCopyrights 2019 \nAll Rights Reserved \nDeveloped and Published by \nMobi2Fun Mobile Entertainment Pvt Ltd";
	public static final String helpDesc="Match the identical colored shapes \n\n "
			+ "Controls: \n\n"
			+"TapTap Mode:\n"
			+"Tap on the identical fixed colored block to match the falling color,\n"
			+"Swipe down to dash\n\n"
			+"Spin Mode:\n"
			+"Tap & Hold to control rotation\n\n"
			+"Classic & Dash Mode:\n"
			+"Tap Left/Swipe Left to rotate anticlockwise, \n"
			+"Tap Right/Swipe Right to rotate clockwise, \n"
			+"Swipe down to dash.\n\n"
			;

	public static final String helpDescIt="Abbina le forme con colori identici \n\n "
			+ "Controlli: \n\n"
			+"Modalità tocco :\n"
			+"Tocca su un blocco dello stesso colore per abbinare il colore cadente,\n"
			+"scorri verso il basso per accelerare.\n\n"
			+"Modalità spin:\n"
			+"Tocca e tieni premuto per controllare la rotazione dei blocchi colorati\n\n"
			+"Modalità classica e accelerata:\n"
			+"Tocca/Scorri verso sinistra per ruotare in senso antiorario, \n"
			+"Tocca/Scorri verso sinistra per ruotare in senso orario, \n"
			+"Scorri verso il basso per accelerare.\n\n"
			;

	public static final String helpDescSp="Combina las formas de colores idénticas \n\n "
			+ "Controles: \n\n"
			+"Modo toque toque:\n"
			+"Toca en el bloque de color fijo idéntico para que coincida con el color descendente, \n"
			+"desliza hacia abajo para acelerar.\n\n"
			+"Modo de giro:\n"
			+"Toca y mantén presionado para controlar la rotación de los bloques de color\n\n"
			+"Modo clásico y acelerado:\n"
			+"Toca/desliza hacia la izquierda para girar en sentido antihorario, \n"
			+"Toca/desliza hacia la derecha para girar en sentido horario, \n"
			+"Desliza hacia abajo para acelerar.\n\n"
			;

	public static final String backalert="Press back again to exit the game";
	
	public static final String score="SCORE";
	public static final String bestScore="BEST SCORE";

	public static final String internetAlert="No internet connection,please check..";
	public static String alertText= "Rate Us";
	public static String yesText= "Yes";
	public static String notNowText= "Not Now";
	public static String neverText= "Never";

	public static String saveMealert= "Save Me";
	public static String noText= "No";
	public static String watchAlertText= "Watch video to continue..";

	public static String widthText="";
}
