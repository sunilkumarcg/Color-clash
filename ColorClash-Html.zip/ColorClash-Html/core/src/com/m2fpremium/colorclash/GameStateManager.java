package com.m2fpremium.colorclash;

import java.util.Stack;


public class GameStateManager {
	public static final int LOGO = 1;
    public static final int SPLASH = 2;
    public static final int MENU = 3;
    public static final int HELP = 4;
    public static final int ABOUT = 5;
    public static final int EXIT = 6;
    public static final int SETTING = 7;
    public static final int PLAY = 8;
    public static final int GAMEPLAY = 9;
    public static final int RESET = 10;
    public static final int SPINPLAY = 11;
    public static final int ENDLESSPLAY = 12;
    public static final int DASHPLAY = 13;
    public static final int MODES = 14;
    public static final int LANGUAGE = 15;

    private MyGdxGame game;
    private Stack<GameState> gameStates;

    public GameStateManager(MyGdxGame game) {
        this.game = game;
        this.gameStates = new Stack();
        pushState(LOGO);
    }

    public MyGdxGame game() {
        return this.game;
    }

    public void update(float dt) {
        ((GameState) this.gameStates.peek()).update(dt);
    }

    public void render() {
        ((GameState) this.gameStates.peek()).render();
    }

    private GameState getState(int state) {
    	 if (state == LOGO) {
    		 constants.ConstantValues.stateNo = LOGO;
             return new Logo(this);
         }   
    	 if (state == SPLASH) {
    		 constants.ConstantValues.stateNo = SPLASH;
             return new Splash(this);
         }
        if (state == LANGUAGE) {
            constants.ConstantValues.stateNo = LANGUAGE;
            return new LanguageScreen(this);
        }
    	 if (state == MENU) {
    		 constants.ConstantValues.stateNo = MENU;
    		 return new MenuScreen(this);
    	 }
    	 if (state == HELP) {
    		 constants.ConstantValues.stateNo = HELP;
    		 return new Help(this);
    	 }
    	 if (state == ABOUT) {
    		 constants.ConstantValues.stateNo = ABOUT;
    		 return new About(this);
    	 }
    
    	 if (state == GAMEPLAY) {
    		 constants.ConstantValues.stateNo = GAMEPLAY;
    		 return new GamePlay(this);
    	 }
    	 if (state == SPINPLAY) {
    		 constants.ConstantValues.stateNo = SPINPLAY;
    		 return new SpinPlay(this);
    	 }
    	 if (state == RESET) {
    		 constants.ConstantValues.stateNo = RESET;
    		 return new ResetScreen(this);
    	 }
    	 if (state == ENDLESSPLAY) {
    		 constants.ConstantValues.stateNo = ENDLESSPLAY;
    		 return new EndlessPlay(this);
		}
    	 if (state == DASHPLAY) {
    		 constants.ConstantValues.stateNo = DASHPLAY;
    		 return new DashPlay(this);
		}
    	 if (state == MODES) {
    		 constants.ConstantValues.stateNo = MODES;
    		 return new ModeScreen(this);
		}
        return null;
    }

    public void setState(int state) {
        popState();
        pushState(state);
    }

    public void popState() {
        ((GameState) this.gameStates.pop()).dispose();
    }

    public void pushState(int state) {
        this.gameStates.push(getState(state));
    }
}
