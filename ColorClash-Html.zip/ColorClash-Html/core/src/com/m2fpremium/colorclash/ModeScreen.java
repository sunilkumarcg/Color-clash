package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenManager;
import aurelienribon.tweenengine.primitives.MutableFloat;
import constants.ConstantValues;


public class ModeScreen extends GameState {

    AndroidOnlyInterface gameinterface;

	
    SpriteBatch batch,batch1;
    Sprite bgSprite,titleSprite;
    
    GameButton button[];
    String btnName="";
    public static boolean button_initializ = false;    
    
    TextureRegion[] classicRegn = new TextureRegion[2];
  //  TextureRegion[] playRegn1 = new TextureRegion[2];
    TextureRegion[] endlessRegn = new TextureRegion[2];
    TextureRegion[] spinPlayRegn = new TextureRegion[2];
    TextureRegion[] taptapRegn = new TextureRegion[2];

  
    TextureAtlas uiAtlas,atlas;
    
    private float down_X;
   	private float down_Y;
   	private float up_X;
   	private float up_Y;
   	private int backval=0;
    
   	boolean tweenbool=false;
   	FontObj fontObj;
   	private final TweenManager tweenManager = new TweenManager();
   	private MutableFloat textX = new MutableFloat(0);
	private MutableFloat textY  = new MutableFloat(constants.ConstantValues.CAMERA_HEIGHT);
	private MutableFloat textX1 = new MutableFloat(0);
	private MutableFloat textY1  = new MutableFloat(constants.ConstantValues.CAMERA_HEIGHT);
	
	int gap = (constants.ConstantValues.CAMERA_HEIGHT) - (constants.ConstantValues.CAMERA_HEIGHT/2-72);
	int gap1=0;
	
	public ModeScreen(GameStateManager gsm) {
		super(gsm);
		
		fontObj=new FontObj();
		backval=0;
		MyInputProcessor myInputProcessor = new MyInputProcessor();
	    InputMultiplexer im = myInputProcessor.returnInput();
		Gdx.input.setInputProcessor(im);  	
		
		
	//	Tween.to(textY, 3, 1.0f).target(ConstantValues.CAMERA_HEIGHT - 100).ease(Back.IN).start(tweenManager);
		
		button = new GameButton[4];
		
		batch = new SpriteBatch();
		bgSprite= new Sprite(MyGdxGame.uiAtlas.findRegion("Menu-bg"));
		if(ConstantValues.langCode==3)
			titleSprite = new Sprite(new TextureRegion(new Texture(Gdx.files.internal("ingame/title_IT.png"))));
		else if(ConstantValues.langCode==2)
			titleSprite = new Sprite(new TextureRegion(new Texture(Gdx.files.internal("ingame/title_ES.png"))));
		else
			titleSprite = new Sprite(MyGdxGame.uiAtlas.findRegion("title"));

		//	titleSprite.setScale(0.7f);
		titleSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2-titleSprite.getWidth()/2, titleSprite.getY()+titleSprite.getHeight()/4 +100);

		batch1 = new SpriteBatch();
				
		uiAtlas = new TextureAtlas("packers/ui/ui.pack");
		try {
			
			/*playRegn1[0] = uiAtlas.findRegion("resume_off");
			playRegn1[1] = uiAtlas.findRegion("resume_on");*/
		
		
			classicRegn[0] = uiAtlas.findRegion("classic");
			classicRegn[1] = uiAtlas.findRegion("classic");
			
			endlessRegn[0] = uiAtlas.findRegion("dash");
			endlessRegn[1] = uiAtlas.findRegion("dash");
			
			spinPlayRegn[0]= uiAtlas.findRegion("spin");
			spinPlayRegn[1]= uiAtlas.findRegion("spin");

			taptapRegn[0]= uiAtlas.findRegion("taptap");
			taptapRegn[1]= uiAtlas.findRegion("taptap");
			
        	loadMenuImages();
        	
        	SoundManager.stopAll();
        	SoundManager.playMenuMusic();
		} catch (Exception e) {
			// TODO: handle exception
		}
		textX = new MutableFloat( (constants.ConstantValues.CAMERA_WIDTH/2 - taptapRegn[0].getRegionWidth()*0.6f) - gap);
		textX1= new MutableFloat( ( constants.ConstantValues.CAMERA_WIDTH/2 + spinPlayRegn[0].getRegionWidth()*0.6f) + gap);
		textY1= new MutableFloat( (constants.ConstantValues.CAMERA_HEIGHT/4 -classicRegn[0].getRegionHeight()*0.3f) - gap);

		Tween.to(textY, 0, 0.5f).target(textY.floatValue() - gap).start(tweenManager);
		Tween.to(textX, 0, 0.5f).target(textX.floatValue() + gap).start(tweenManager);
		Tween.to(textX1, 0, 0.5f).target(textX1.floatValue() - gap).start(tweenManager);
		Tween.to(textY1, 0, 0.5f).target(textY1.floatValue() + gap).start(tweenManager);

	
	}

	
	
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleInput() {
		// TODO Auto-generated method stub
	 	if (button_initializ) {
			for (int i = 0; i < button.length; i++) {

				if (button[i].isClicked() && btnName.equals("") && tweenbool) {
					
					 if (i == 0) {
							SoundManager.playClick();
							btnName = "play";
							button[0].buttonTouched = true;					
					}
					else if (i == 1) {
							SoundManager.playClick();
							btnName = "dash";
						button[1].buttonTouched = true;					
					}
					else if (i == 2) {
							SoundManager.playClick();
							btnName = "spin";
							button[2].buttonTouched = true;					
					}
					else if (i == 3) {
							SoundManager.playClick();
							btnName = "taptap";
							button[3].buttonTouched = true;					
					}
				}
			}
		}
	 	
	 	if (MyInput.isDown(0)) {
			down_X = MyInput.Down_x;
			down_Y = constants.ConstantValues.CAMERA_HEIGHT - MyInput.Down_y;
		}
		if (MyInput.isUp(0)) {
			up_X = MyInput.Up_x;
			up_Y = constants.ConstantValues.CAMERA_HEIGHT - MyInput.Up_y;
			
			handleTheGame();
		}
		
		if (MyInputProcessor.isKeyDown ) 
		{
			ChangeScreen(GameStateManager.MENU);
		}
	
	}
	

	public void handleTheGame() {
		// TODO Auto-generated method stub
		if (button_initializ) {
			for (int j = 0; j < button.length; j++) {
				button[j].buttonTouched = false;
			}
		}	
		
		if (btnName.equals("help")) {
			ChangeScreen(GameStateManager.HELP);
		}
		else if (btnName.equals("about")) {
			ChangeScreen(GameStateManager.ABOUT);
		}
		else if (btnName.equals("play")) {
			for (int i = 0; i < Levels.totlevels; i++) {
				Levels.directions[i] = Levels.mode1directions[i];
				Levels.features[i] = Levels.mode1features[i];
			}
			Levels.mode="mixup";
			ChangeScreen(GameStateManager.GAMEPLAY);
		}
		else if (btnName.equals("dash")) {
			for (int j = 0; j < Levels.totlevels; j++) {
				Levels.directions[j] = Levels.mode1directions[j];   
				Levels.features[j] = Levels.mode1features[j];                                    
			}
			Levels.mode="endless";
			ChangeScreen(GameStateManager.ENDLESSPLAY);
		}
		else if (btnName.equals("spin")) {
			for (int j = 0; j < Levels.totlevels; j++) {
				Levels.directions[j] = Levels.mode1directions[j];   
				Levels.features[j] = Levels.mode1features[j];                                    
			}
			Levels.mode="spin";
			ChangeScreen(GameStateManager.SPINPLAY);
		}
		else if (btnName.equals("taptap")) {
			for (int j = 0; j < Levels.totlevels; j++) {
				Levels.directions[j] = Levels.mode1directions[j];   
				Levels.features[j] = Levels.mode1features[j];                                    
			}
			Levels.mode="dash";
			ChangeScreen(GameStateManager.DASHPLAY);
		}
		btnName="";
	}

	@Override
	public void render() {
		// TODO Auto-generated method stub
		  tweenManager.update(Gdx.graphics.getDeltaTime());
		  if (!tweenbool) {
			  if (tweenManager.containsTarget(textX)) {
				}
				else 
				{
					tweenbool=true;
				}
		  }

    	cam.update();
    	Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
    	
    	batch.setProjectionMatrix(cam.combined); 
        batch.begin();
        bgSprite.draw(batch);
        titleSprite.draw(batch);
     
    	
    /*	MyGdxGame.getMediumFont().draw(batch, LocalizedStrings.APP_NAME,
    			ConstantValues.CAMERA_WIDTH/2 - fontObj.getStringWidth(MyGdxGame.getMediumFont(), LocalizedStrings.APP_NAME),textY.floatValue());

*/        
        if (button_initializ) { 
			if (button[0].buttonTouched) {
				button[0].render(batch, classicRegn[1], constants.ConstantValues.CAMERA_WIDTH/2 -  classicRegn[0].getRegionWidth()*0.6f ,textY.floatValue()/*,0*/);
			} else {
				button[0].render(batch, classicRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 -  classicRegn[0].getRegionWidth()*0.6f ,textY.floatValue()/*,0*/);
			}
	
			if (button[1].buttonTouched) {
				button[1].render(batch, endlessRegn[1], constants.ConstantValues.CAMERA_WIDTH/2 + endlessRegn[0].getRegionWidth() *0.6f,textY1.floatValue()/*,0*/);
			} else {
				button[1].render(batch, endlessRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 + endlessRegn[0].getRegionWidth() *0.6f,textY1.floatValue()/*,0*/);
			}
			if (button[2].buttonTouched) {
				button[2].render(batch, spinPlayRegn[1],textX1.floatValue(), constants.ConstantValues.CAMERA_HEIGHT/2 -classicRegn[0].getRegionHeight()*0.25f/*,0*/);
			} else {
				button[2].render(batch, spinPlayRegn[0],textX1.floatValue(), constants.ConstantValues.CAMERA_HEIGHT/2 -classicRegn[0].getRegionHeight()*0.25f/*,0*/);
			}
			
			if (button[3].buttonTouched) {
				button[3].render(batch, taptapRegn[1],textX.floatValue(), constants.ConstantValues.CAMERA_HEIGHT/4 -classicRegn[0].getRegionHeight()*0.3f/*,0*/);
			} else {
				button[3].render(batch, taptapRegn[0],textX.floatValue(), constants.ConstantValues.CAMERA_HEIGHT/4 -classicRegn[0].getRegionHeight()*0.3f/*,0*/);
			}
			if (MyGdxGame.demobool) {
				MyGdxGame.demoSprite.draw(batch);
			}
    	}
        if (tweenbool) {
        	MyGdxGame.getMediumFont().draw(batch,""+PreferenceClass.readBestScoreClassic(),textX.floatValue(),textY.floatValue()-classicRegn[0].getRegionHeight()/3);
        	MyGdxGame.getMediumFont().draw(batch,""+PreferenceClass.readBestScoreSpin(),textX1.floatValue(),textY.floatValue()-classicRegn[0].getRegionHeight()/3);
        	MyGdxGame.getMediumFont().draw(batch,""+PreferenceClass.readBestScoreTap(),textX.floatValue(),textY1.floatValue()-classicRegn[0].getRegionHeight()/3);
        	MyGdxGame.getMediumFont().draw(batch,""+PreferenceClass.readBestScoreDash(),textX1.floatValue(),textY1.floatValue()-classicRegn[0].getRegionHeight()/3);

		}
    	
        batch.end();
	}

	@Override
	public void update(float f) {
		// TODO Auto-generated method stub
		if (button_initializ) {
			for (int i = 0; i < button.length; i++) {
				button[i].update(Gdx.graphics.getDeltaTime());
			}
		}
		handleInput();
	}

	  private void loadMenuImages() {
			// TODO Auto-generated method stub
		  int adjx=30;
	    	button[0] = new GameButton(classicRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 -  classicRegn[0].getRegionWidth()*0.6f  , constants.ConstantValues.CAMERA_HEIGHT,cam,new ScaleAnimation(0.05f, 0.05f, 0.9f, 0.9f, 0.0f, 0.0f));
	    	
	    	button[1] = new GameButton(endlessRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 + endlessRegn[0].getRegionWidth() *0.6f ,  constants.ConstantValues.CAMERA_HEIGHT/4 -classicRegn[0].getRegionHeight()*0.3f,cam,new ScaleAnimation(0.05f, 0.05f, 0.9f, 0.9f, 0.0f, 0.0f));
	    	button[2] = new GameButton(spinPlayRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 + spinPlayRegn[0].getRegionWidth()*0.6f ,  constants.ConstantValues.CAMERA_HEIGHT/2 -classicRegn[0].getRegionHeight()*0.25f,cam,new ScaleAnimation(0.05f, 0.05f, 0.9f, 0.9f, 0.0f, 0.0f));
	    	button[3] = new GameButton(taptapRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 - taptapRegn[0].getRegionWidth()*0.6f ,  constants.ConstantValues.CAMERA_HEIGHT/4 -classicRegn[0].getRegionHeight()*0.3f,cam,new ScaleAnimation(0.05f, 0.05f, 0.9f, 0.9f, 0.0f, 0.0f));

	    	MyInput.Down_x = 0;
			MyInput.Down_y = 0;
			MyInput.Up_x = 0;
			MyInput.Up_y = 0;
			MyInput.Drag_x = 0;
			MyInput.Drag_y = 0;
	    	
			button_initializ = true;
		}
} 
