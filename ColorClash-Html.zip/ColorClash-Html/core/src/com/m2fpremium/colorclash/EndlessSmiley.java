package com.m2fpremium.colorclash;

import java.util.Random;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;


public class EndlessSmiley {
	
	public static Sprite[] SmileySprites= new Sprite[10];	
	public static Sprite[] SmileyBlurSprites= new Sprite[10];

	public static int[] smileyVisible = new int[SmileySprites.length];
	public static String[] smileyDir = new String[SmileySprites.length];
	public static int[] SmileyIconNos= new int[SmileySprites.length];
	
	Rectangle[] smileyRectangles = new Rectangle[SmileySprites.length];
	
	int[] smileyNo = new int[4];
	public static int smileyTime=0;
	public static int fixedSmileyTime=0;
	public static int smileySpeed=6;
	public static int smileyDash=-1;
	public static int smileyInd = 0;

	public static int smileyGameOverNo = 0;
	public static int smileyGameOverPartNo = 0;
	public static boolean savemebool=false;

	Random ran;
	
	public EndlessSmiley() {
		// TODO Auto-generated constructor stub
		ran = new Random();
		for (int i = 0; i < smileyNo.length; i++) {
			smileyNo[i] = i;
		}
		for (int i = 0; i < smileyVisible.length; i++) {
			smileyVisible[i] = 0;
			smileyDir[i]="down";
			SmileyIconNos[i]=0;
		}
		smileyDash=-1;
		savemebool=false;
		createSmileys();
	}
	
	private void createSmileys() {
		// TODO Auto-generated method stub
		for (int i = 0; i < SmileySprites.length; i++) {
			ShuffleLogic.shuffleArray(smileyNo);
			SmileyIconNos[i] = smileyNo[0];
			SmileySprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(EndlessPlay.getPattern()+(SmileyIconNos[i]+1)+"rect"));
			SmileyBlurSprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(GamePlay.getBlurPattern()+(SmileyIconNos[i]+1)+"blur"));
			smileyRectangles[i] = new Rectangle(SmileySprites[i].getX(), SmileySprites[i].getY(), SmileySprites[i].getWidth()/2, SmileySprites[i].getHeight());
		}
	}
	public void moveSmileys() {
		// TODO Auto-generated method stub
			if (Levels.mode.equals("endless")) {
				smileyTime =  smileyTime+(smileySpeed/4);
			}
			else
			{
				smileyTime++;
			}
			
			checkCollision();
			if (smileyTime > fixedSmileyTime && Levels.transState.equals("none")) {
				showSmiley();
				smileyTime=0;
			}
			for (int i = 0; i < SmileySprites.length; i++) {
				if (smileyVisible[i]!=0  ) {
					switch (smileyDir[i]) {
					case "down":
						//System.out.println(""+smileyDash+"is smile");
						if (smileyDash==i) {
							SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed*3);	
						}
						else
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed);
						break;
					case "up":
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()+smileySpeed);
						break;
					
					default:
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed);
						break;
					}
					smileyRectangles[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY());
				
					if (smileyDir[i].contains("down")) {
						if (SmileyBlurSprites[i].isFlipY()) {
							SmileyBlurSprites[i].flip(false, false);
						}
						SmileyBlurSprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()/*+SmileySprites[i].getHeight()/2*/);
					}
					else
					{
						if (!SmileyBlurSprites[i].isFlipY()) {
						SmileyBlurSprites[i].flip(false, true);
						}
						SmileyBlurSprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()/*-SmileySprites[i].getHeight()*/);
					}
					
					if (SmileySprites[i].getY() < -SmileySprites[i].getHeight()) {
						smileyVisible[i]=0 ;
					}
					if (!constants.ConstantValues.isClassicTutorial && (SmileySprites[0].getY() <= constants.ConstantValues.CAMERA_HEIGHT/2 + smileySpeed) && (SmileySprites[0].getY() > constants.ConstantValues.CAMERA_HEIGHT/2)  ) {
						TapandholdTut.showTut=true;
					}
				}			
			}
			
	}
	int scalefac=0;
	public void renderSmileys(SpriteBatch batch) {
		// TODO Auto-generated method stub
		scalefac++;
		if (scalefac > 5) {
			scalefac=0;
		}
		for (int i = 0; i < SmileySprites.length; i++) {
			if (smileyVisible[i] !=0) {
				if (EndlessPlay.gameState.equals("run")) {
					if (scalefac == 5) {
						if (SmileyBlurSprites[i].getScaleY() == 1.0f) {
							SmileyBlurSprites[i].setScale(1.0f, 0.74f);
						} else if (SmileyBlurSprites[i].getScaleY() == 0.74f) {
							SmileyBlurSprites[i].setScale(1.0f, 0.5f);
						} else if (SmileyBlurSprites[i].getScaleY() == 0.5f) {
							SmileyBlurSprites[i].setScale(1.0f, 0.75f);
						} else if (SmileyBlurSprites[i].getScaleY() == 0.75f) {
							SmileyBlurSprites[i].setScale(1.0f, 1.0f);
						}
					}
					
					if ((constants.ConstantValues.isClassicTutorial || !TapandholdTut.showTut) && SmileyBlurSprites[i].getScaleY() != 1.0f && constants.ConstantValues.pattern == 'd') {
						if (smileyDir[i].contains("down")) {
							SmileyBlurSprites[i].setPosition(SmileyBlurSprites[i].getX(),
									SmileyBlurSprites[i].getY() - SmileyBlurSprites[i].getHeight() / 8);
						} else {
							SmileyBlurSprites[i].setPosition(SmileyBlurSprites[i].getX(),
									SmileyBlurSprites[i].getY() + SmileyBlurSprites[i].getHeight() / 8);
						}
					} 
				}
				SmileyBlurSprites[i].draw(batch);
				SmileySprites[i].draw(batch);
			}
		}
	}
	
	public void showSmiley() {
		// TODO Auto-generated method stub
		if (constants.ConstantValues.isClassicTutorial) {
		for (int i = 0; i < SmileySprites.length; i++) {
			if (smileyVisible[i]==0) {

				if (Levels.blockPlace.equals("down")) {
					smileyDir[i] = "down";			
				}
			
				
				smileyVisible[i]=1;
				
				SmileySprites[i]=null;
				SmileyBlurSprites[i]=null;
				ShuffleLogic.shuffleArray(smileyNo);
				SmileyIconNos[i] = smileyNo[0];
				SmileySprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(EndlessPlay.getPattern()+(SmileyIconNos[i]+1)+"rect"));
				SmileyBlurSprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(GamePlay.getBlurPattern()+(SmileyIconNos[i]+1)+"blur"));

				setSmileyPosition(i);
				Levels.emoCnt++;
				break;		
			}
		}
		}
		else if(constants.ConstantValues.classicCnt==0)
		{
			if (smileyVisible[smileyInd]==0) {
				
				smileyVisible[smileyInd] = 1;				
				SmileySprites[smileyInd] = null;
				SmileyBlurSprites[smileyInd] = null;
				
				if (constants.ConstantValues.classicSteps==0 || constants.ConstantValues.classicSteps==2) {
					SmileyIconNos[smileyInd] = EndlessSquareBlock.symSequence[1];
				}
				else
				{
					SmileyIconNos[smileyInd] = EndlessSquareBlock.symSequence[0];
				}
				
				SmileySprites[smileyInd] = new Sprite(
						MyGdxGame.gameAtlas.findRegion(GamePlay.getPattern() + (SmileyIconNos[smileyInd] + 1) + "rect"));
				
				SmileyBlurSprites[smileyInd] = new Sprite(MyGdxGame.gameAtlas
						.findRegion(GamePlay.getBlurPattern() + (SmileyIconNos[smileyInd] + 1) + "blur"));

				if (constants.ConstantValues.classicSteps==0) {
				SmileySprites[smileyInd].setPosition(EndlessSquareBlock.xypos[0][0], constants.ConstantValues.CAMERA_HEIGHT);
				}
				else
				{
				SmileySprites[smileyInd].setPosition(EndlessSquareBlock.xypos[1][0], constants.ConstantValues.CAMERA_HEIGHT);
				}
				
				Levels.emoCnt++;
				if (Levels.emoCnt==3) {
					Levels.emoCnt=0;					
				}
			}
		}
		else 
		{
			if (smileyVisible[smileyInd]==0) {
				
				smileyVisible[smileyInd] = 1;				
				SmileySprites[smileyInd] = null;
				SmileyBlurSprites[smileyInd] = null;
				
				if (constants.ConstantValues.classicSteps==0 ) {
					SmileyIconNos[smileyInd] = EndlessSquareBlock.symSequence[1];
				}
				else
				{
					SmileyIconNos[smileyInd] = EndlessSquareBlock.symSequence[0];
				}
				
				SmileySprites[smileyInd] = new Sprite(
						MyGdxGame.gameAtlas.findRegion(GamePlay.getPattern() + (SmileyIconNos[smileyInd] + 1) + "rect"));
				
				SmileyBlurSprites[smileyInd] = new Sprite(MyGdxGame.gameAtlas
						.findRegion(GamePlay.getBlurPattern() + (SmileyIconNos[smileyInd] + 1) + "blur"));

				if (constants.ConstantValues.classicSteps==0) {
				SmileySprites[smileyInd].setPosition(EndlessSquareBlock.xypos[0][0], constants.ConstantValues.CAMERA_HEIGHT);
				}
				else
				{
				SmileySprites[smileyInd].setPosition(EndlessSquareBlock.xypos[1][0], constants.ConstantValues.CAMERA_HEIGHT);
				}
				
				Levels.emoCnt++;
				if (Levels.emoCnt==2) {
					Levels.emoCnt=0;					
				}
			}
		}
	}
	
	
	private void setSmileyPosition(int i) {
		// TODO Auto-generated method stub
		float smileyX=EndlessSquareBlock.xypos[0][0];
		float smileyX1=EndlessSquareBlock.xypos[1][0];
		float SmileyY=0;
		switch (smileyDir[i]) {
		case "up":
			SmileyY = 0 - SmileySprites[i].getHeight();
			break;
		case "down":				
			SmileyY = constants.ConstantValues.CAMERA_HEIGHT;
			break;		
		default:
			break;
		}
		
		if (ran.nextInt()%3 == 0) {
			SmileySprites[i].setPosition(smileyX,SmileyY);
		}
		else
		{
			SmileySprites[i].setPosition(smileyX1, SmileyY);
		}
	}
	
	public void checkCollision() {
		// TODO Auto-generated method stub
		for (int i = 0; i < smileyRectangles.length; i++) {
			for (int j = 0; j < EndlessSquareBlock.collisionRectangles.length; j++) {
				if (smileyVisible[i]!=0 && smileyRectangles[i].overlaps(EndlessSquareBlock.collisionRectangles[j])  && EndlessPlay.startRot)
				{
					if( SmileyIconNos[i] ==  EndlessSquareBlock.symSequence[j])
					{
						//System.out.println("collision no:"+j);
						Levels.emoCollisionCnt++;
						Score.updateScore();
						if (constants.ConstantValues.isClassicRight) {
							if (constants.ConstantValues.classicCnt==1 && Score.score >=3) {
								Score.score=0;
								Levels.emoCollisionCnt=0;
								constants.ConstantValues.isClassicRight=false;
								constants.ConstantValues.isClassicLeft=false;
							}
							else if (constants.ConstantValues.classicCnt==2 && Score.score >=2)
							{
								Score.score=0;
								Levels.emoCollisionCnt=0;
								constants.ConstantValues.isClassicRight=false;
								constants.ConstantValues.isClassicLeft=false;
							}												
						}
						smileyVisible[i] = 0;
						EndlessSmiley.smileyDash=-1;
							
						for (int j2 = 0; j2 < EndlessSquareBlock.emoSymbols.length; j2++) {
							if (EndlessSquareBlock.emoSymbols[j2].getX() == EndlessSquareBlock.xypos[j][0] && 
									EndlessSquareBlock.emoSymbols[j2].getY() == EndlessSquareBlock.xypos[j][1]) {
								EndlessSquareBlock.emoSymbols[j2].setScale(1.15f);
								if (EndlessSquareBlock.emoSymbolNos[j2]==1) {
									EndlessSquareBlock.emoSymbolNos[j2] = 0;
								}
								break;
							}
						}
						
					}
					else
					{

						
							smileyGameOverNo=i;
							smileyGameOverPartNo=j;
							gameOverFn();
					
					}
				}
			}
		}
	}
	public static void gameOverFn()
	{
		int i = smileyGameOverNo;
		int j = smileyGameOverPartNo;
		if(SmileyIconNos[i]>=0) {
			smileyVisible[i] = 0;
			EndlessPlay.gameState = "gameoveranim";
			String direction = "down";
			if (smileyDir[i].contains("up")) {
				direction = "up";
			}
			ParticleEffectsClass.startEmitter();
			ParticleEffectsClass.setPosition(EndlessSquareBlock.collisionRectangles[j].getX(), EndlessSquareBlock.collisionRectangles[j].getY(), direction);
			SoundManager.playGameOver();
			Score.compareScores();
			for (int k = 0; k < SmileyIconNos.length; k++) {
				SmileyIconNos[k] = -1;
			}
		}
	}

}
