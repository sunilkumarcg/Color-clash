package com.m2fpremium.colorclash;

import java.util.Random;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class SpinSmiley {
	
	public static Sprite[] SmileySprites= new Sprite[10];
	public static Sprite[] SmileyBlurSprites= new Sprite[10];

	public static int[] smileyVisible = new int[SmileySprites.length];
	public static String[] smileyDir = new String[SmileySprites.length];
	public static int[] SmileyIconNos= new int[SmileySprites.length];
	
	Rectangle[] smileyRectangles = new Rectangle[SmileySprites.length];
	
	int[] smileyNo = new int[4];
	public static int smileyTime=0;
	public static int fixedSmileyTime=0;
	public static int smileySpeed=6;
	int tapind=0;
	Random ran;

	public static int smileyGameOverNo = 0;
	public static int smileyGameOverPartNo = 0;
	public static boolean savemebool=false;

	public SpinSmiley() {
		// TODO Auto-generated constructor stub
		ran = new Random();
		 tapind=0;
		for (int i = 0; i < smileyNo.length; i++) {
			smileyNo[i] = i;
		}
		for (int i = 0; i < smileyVisible.length; i++) {
			smileyVisible[i] = 0;
			smileyDir[i]="down";
			SmileyIconNos[i]=0;
		}
		savemebool=false;
		createSmileys();
	}
	
	private void createSmileys() {
		// TODO Auto-generated method stub
		for (int i = 0; i < SmileySprites.length; i++) {
			ShuffleLogic.shuffleArray(smileyNo);
			SmileyIconNos[i] = smileyNo[0];
			SmileySprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(SpinPlay.getPattern()+(SmileyIconNos[i]+1)+"rect"));
			SmileyBlurSprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(GamePlay.getBlurPattern()+(SmileyIconNos[i]+1)+"blur"));

			smileyRectangles[i] = new Rectangle(SmileySprites[i].getX(), SmileySprites[i].getY(), SmileySprites[i].getWidth(), SmileySprites[i].getHeight());
		
		}
	}
	public void moveSmileys() {
		// TODO Auto-generated method stub
			if (Levels.mode.equals("dash")&& !TapandholdTut.showTut) {
				smileyTime =  smileyTime+(smileySpeed/4);
			}
			else if( !TapandholdTut.showTut)
			{
				smileyTime++;
			}
			
			checkCollision();

			if (smileyTime > fixedSmileyTime && Levels.transState.equals("none")&& !TapandholdTut.showTut) {
				showSmiley();
				smileyTime=0;
			}
			for (int i = 0; i < SmileySprites.length; i++) {
				if (smileyVisible[i]!=0  && !TapandholdTut.showTut) {
					switch (smileyDir[i]) {
					case "down":
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed);
						break;
					case "up":
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()+smileySpeed);
						break;
					
					default:
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed);
						break;
					}
					smileyRectangles[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY());
				
					
				
					if (SmileySprites[i].getY() < -SmileySprites[i].getHeight()) {
						smileyVisible[i]=0 ;
					}
					
					if (smileyDir[i].contains("down")) {
						if (SmileyBlurSprites[i].isFlipY()) {
							SmileyBlurSprites[i].flip(false, false);
						}
						SmileyBlurSprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()/*+SmileySprites[i].getHeight()/2*/);
					}
					else
					{
						if (!SmileyBlurSprites[i].isFlipY()) {
						SmileyBlurSprites[i].flip(false, true);
						}
						SmileyBlurSprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-SmileySprites[i].getHeight());
					}
					
					if (!constants.ConstantValues.isSpinTutorial) {
						if (SmileySprites[tapind].getY()> constants.ConstantValues.CAMERA_HEIGHT/2+ constants.ConstantValues.CAMERA_HEIGHT/4 && SmileySprites[tapind].getY() <= constants.ConstantValues.CAMERA_HEIGHT/2+ constants.ConstantValues.CAMERA_HEIGHT/4+smileySpeed) {
							TapandholdTut.tutSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2, constants.ConstantValues.CAMERA_HEIGHT/2);
							TapandholdTut.showTut=true;		
						}
					}
					
				}			
			}
			
	}
	int scalefac=0;
	public void renderSmileys(SpriteBatch batch) {
		// TODO Auto-generated method stub
		if (!TapandholdTut.showTut) {
			scalefac++;
			if (scalefac > 5) {
				scalefac=0;
			}
		}
	
		for (int i = 0; i < SmileySprites.length; i++) {
			if (smileyVisible[i] !=0) {
				if (SpinPlay.gameState.equals("run")) {
					if (scalefac == 5 && !TapandholdTut.showTut) {
						if (SmileyBlurSprites[i].getScaleY() == 1.0f) {
							SmileyBlurSprites[i].setScale(1.0f, 0.74f);
						} else if (SmileyBlurSprites[i].getScaleY() == 0.74f) {
							SmileyBlurSprites[i].setScale(1.0f, 0.5f);
						} else if (SmileyBlurSprites[i].getScaleY() == 0.5f) {
							SmileyBlurSprites[i].setScale(1.0f, 0.75f);
						} else if (SmileyBlurSprites[i].getScaleY() == 0.75f) {
							SmileyBlurSprites[i].setScale(1.0f, 1.0f);
						}
					}
					if (!TapandholdTut.showTut && SmileyBlurSprites[i].getScaleY() != 1.0f
							&& constants.ConstantValues.pattern == 'd') {
						if (smileyDir[i].contains("down")) {
							SmileyBlurSprites[i].setPosition(SmileyBlurSprites[i].getX(),
									SmileyBlurSprites[i].getY() - SmileyBlurSprites[i].getHeight() / 8);
						} else {
							SmileyBlurSprites[i].setPosition(SmileyBlurSprites[i].getX(),
									SmileyBlurSprites[i].getY() + SmileyBlurSprites[i].getHeight() / 8);
						}
					} 
				}
				SmileyBlurSprites[i].draw(batch);

				SmileySprites[i].draw(batch);
			}
		}
	}
	
	public void showSmiley() {
		// TODO Auto-generated method stub
		for (int i = 0; i < SmileySprites.length; i++) {
			if (smileyVisible[i]==0) {
				int num= ran.nextInt()%6;

				if (Levels.blockPlace.equals("down")) {

					if (Levels.features[Levels.levelNo].equals("diag")) {
						if (num<2) {
						smileyDir[i] = "diagdownleft";	
						}
						else
						{
						smileyDir[i] = "diagdownright";	
						}
					}
					else if (Levels.features[Levels.levelNo].equals("zigzag") || Levels.features[Levels.levelNo].equals("zigzaghide")) {
						if (num<2) 
						{
							smileyDir[i] = "zigzagdownleft";	
						}
						else
						{
							smileyDir[i] = "zigzagdownright";	
						}
					}
					else
					smileyDir[i] = "down";			
				}
				
				
				smileyVisible[i]=1;
				
				SmileySprites[i]=null;
				SmileyBlurSprites[i] = null;
				ShuffleLogic.shuffleArray(smileyNo);
				SmileyIconNos[i] = smileyNo[0];
				SmileySprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(SpinPlay.getPattern()+(SmileyIconNos[i]+1)+"rect"));
				SmileyBlurSprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(GamePlay.getBlurPattern()+(SmileyIconNos[i]+1)+"blur"));

				setSmileyPosition(i);
				Levels.emoCnt++;
				break;		
			}
		}
	}
	
	private void setSmileyPosition(int i) {
		// TODO Auto-generated method stub
		float smileyX=SpinSquareBlock.xypos[0][0];
		float smileyX1=SpinSquareBlock.xypos[1][0];
		float SmileyY=0;
		switch (smileyDir[i]) {
		case "up":
			SmileyY = 0 - SmileySprites[i].getHeight();
			break;
		case "down":				
			SmileyY = constants.ConstantValues.CAMERA_HEIGHT;
			break;
	
		default:
			break;
		}
		
		if (ran.nextInt()%3 == 0) {
			SmileySprites[i].setPosition(smileyX1,SmileyY);
		}
		else
		{
			SmileySprites[i].setPosition(smileyX, SmileyY);
		}
	}

	
	public void checkCollision() {
		// TODO Auto-generated method stub
		for (int i = 0; i < smileyRectangles.length; i++) {
			for (int j = 0; j < SpinSquareBlock.emoSymbols.length; j++) {
			 	if (smileyVisible[i]!=0 && smileyRectangles[i].overlaps(SpinSquareBlock.collisionRectangles[j])  )
				{

					if ((SmileyIconNos[i]+1)==(SpinSquareBlock.symSequence[j]+1)) {
						Levels.emoCollisionCnt++;
						Score.updateScore();
						smileyVisible[i] = 0;

						for (int j2 = 0; j2 < SpinSquareBlock.emoSymbols.length; j2++) {
							if (SpinSquareBlock.emoSymbols[j2].getX() == SpinSquareBlock.xypos[j][0] && 
									SpinSquareBlock.emoSymbols[j2].getY() == SpinSquareBlock.xypos[j][1]) {
								SpinSquareBlock.emoSymbols[j2].setScale(1.5f);
								if (SpinSquareBlock.emoSymbolNos[j2]==1) {
									SpinSquareBlock.emoSymbolNos[j2] = 0;
								}
								break;
							}
						}
					}
					else
					{
					
							smileyGameOverNo=i;
							smileyGameOverPartNo=j;
							gameOverFn();
					
					}	
				}
			}
		}
	}

	public static void gameOverFn()
	{
		int i = smileyGameOverNo;
		int j = smileyGameOverPartNo;
		if(SmileyIconNos[i]>=0) {
		//System.out.println("angle is:"+SpinSquareBlock.angle);
		smileyVisible[i] = 0;
		SpinPlay.gameState="gameoveranim";
		String direction ="down";
		if (smileyDir[i].contains("up")) {
			direction="up";
		}
		ParticleEffectsClass.startEmitter();
		ParticleEffectsClass.setPosition(SpinSquareBlock.collisionRectangles[j].getX(),SpinSquareBlock.collisionRectangles[j].getY(),direction);
		SoundManager.playGameOver();
		Score.compareScores();
			for (int k = 0; k < SpinSquareBlock.collisionRectangles.length; k++) {
				SpinSquareBlock.collisionRectangles[k].setPosition(-1000, -1000);
			}
			for (int k = 0; k < SmileyIconNos.length; k++) {
				SmileyIconNos[k]=-1;
			}
			Score.compareScores();
		}
	}
}
