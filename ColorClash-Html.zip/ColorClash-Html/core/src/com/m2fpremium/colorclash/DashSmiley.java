package com.m2fpremium.colorclash;

import java.util.Random;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class DashSmiley {
	
	public static Sprite[] SmileySprites= new Sprite[10];
	public static Sprite[] SmileyBlurSprites= new Sprite[10];

	public static int[] smileyVisible = new int[SmileySprites.length];
	public static String[] smileyDir = new String[SmileySprites.length];
	public static int[] SmileyIconNos= new int[SmileySprites.length];
	
	public static Rectangle[] smileyRectangles = new Rectangle[SmileySprites.length];
	
	int[] smileyNo = new int[4];
	public static int smileyTime=0;
	public static int fixedSmileyTime=0;
	public static int smileySpeed=6;
	public static int smileyDash=-1;
	public static int smileySwitch=-1;
	public static int tapind=0;

	public static int smileyGameOverNo = 0;
	public static int smileyGameOverPartNo = 0;
	public static boolean savemebool=false;

	Random ran;
	
	public DashSmiley() {
		// TODO Auto-generated constructor stub
		ran = new Random();
		for (int i = 0; i < smileyNo.length; i++) {
			smileyNo[i] = i;
		}
		for (int i = 0; i < smileyVisible.length; i++) {
			smileyVisible[i] = 0;
			smileyDir[i]="down";
			SmileyIconNos[i]=0;
		}
		tapind=0;
		smileyDash=-1;
		savemebool=false;
		createSmileys();
	}
	
	private void createSmileys() {
		// TODO Auto-generated method stub
		for (int i = 0; i < SmileySprites.length; i++) {
			ShuffleLogic.shuffleArray(smileyNo);
			SmileyIconNos[i] = smileyNo[0];
			SmileySprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(DashPlay.getPattern()+(SmileyIconNos[i]+1)+"rect"));
			SmileyBlurSprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(GamePlay.getBlurPattern()+(SmileyIconNos[i]+1)+"blur"));

			smileyRectangles[i] = new Rectangle(SmileySprites[i].getX(), SmileySprites[i].getY(), SmileySprites[i].getWidth()/2, SmileySprites[i].getHeight());
		}
	}
	public void moveSmileys() {
		// TODO Auto-generated method stub
			if (Levels.mode.equals("endless")) {
				smileyTime =  smileyTime+(smileySpeed/4);
			}
			else
			{
				smileyTime++;
			}
			
			checkCollision();
			if (smileyTime > fixedSmileyTime && Levels.transState.equals("none")) {
				showSmiley();
				smileyTime=0;
			}
			for (int i = 0; i < SmileySprites.length; i++) {
				if (smileyVisible[i]!=0  && DashPlay.gameState.equals("run")) {
					switch (smileyDir[i]) {
					case "down":
						//System.out.println(""+smileyDash+"is smile");
						if (smileyDash==i) {
							SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed*3);	
						}
						else
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed);
						break;
					case "up":
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()+smileySpeed);
						break;
					
					default:
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed);
						break;
					}
					smileyRectangles[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY());
				
					
					
					if (SmileySprites[i].getY() < -SmileySprites[i].getHeight()) {
						smileyVisible[i]=0 ;
					}
					if (smileyDir[i].contains("down")) {
						if (SmileyBlurSprites[i].isFlipY()) {
							SmileyBlurSprites[i].flip(false, false);
						}
						SmileyBlurSprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()/*+SmileySprites[i].getHeight()/2*/);
					}
					else
					{
						if (!SmileyBlurSprites[i].isFlipY()) {
						SmileyBlurSprites[i].flip(false, true);
						}
						SmileyBlurSprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-SmileySprites[i].getHeight());
					}
				}			
			}
			
			if (!constants.ConstantValues.isTapTapTutorial) {
				if (SmileySprites[tapind].getY()> constants.ConstantValues.CAMERA_HEIGHT/2 && SmileySprites[tapind].getY() <= constants.ConstantValues.CAMERA_HEIGHT/2+smileySpeed) {
					int no=0,no1=0;
					for (int i = 0; i < DashSquareBlock.emoSymbols.length; i++) {
						if (SmileySprites[tapind].getX()== DashSquareBlock.xypos[i][0]) {
							no = i;
						}
						if (SmileyIconNos[tapind] == DashSquareBlock.symSequence[i]) {
								no1 = i;
						}
						
					}
				/*	if (SmileyIconNos[tapind]==DashSquareBlock.symSequence[no]) {
						if (DashPlay.gameState.equals("run1")) {
							DashPlay.gameState="run";
						}
					}
					else
					{*/
						//System.out.println("state:"+DashPlay.gameState);
						if (DashPlay.gameState.equals("run")) {
							DashPlay.gameState="runtut";
							TapandholdTut.showTut=true;
							TapandholdTut.tutSprite.setPosition(DashSquareBlock.xypos[no1][0], DashSquareBlock.xypos[no1][1]-50);
							
					//	}
					}
				}
			}
	}
	int scalefac=0;
	public void renderSmileys(SpriteBatch batch) {
		// TODO Auto-generated method stub
		if (DashPlay.gameState.equals("run")) {
			scalefac++;
			if (scalefac > 5) {
				scalefac=0;
			}
		}
	
		for (int i = 0; i < SmileySprites.length; i++) {
			if (smileyVisible[i] !=0) {
				if (DashPlay.gameState.equals("run")) {
					if (scalefac==5) {
						if (SmileyBlurSprites[i].getScaleY() == 1.0f) {
							SmileyBlurSprites[i].setScale(1.0f, 0.74f);								
							}
						else if (SmileyBlurSprites[i].getScaleY() == 0.74f)
						{
							SmileyBlurSprites[i].setScale(1.0f, 0.5f);				
						}				
						else if (SmileyBlurSprites[i].getScaleY() == 0.5f)
						{
							SmileyBlurSprites[i].setScale(1.0f, 0.75f);				
						}
						else if (SmileyBlurSprites[i].getScaleY() == 0.75f)
						{
							SmileyBlurSprites[i].setScale(1.0f,1.0f);				
						}
					}
					if (SmileyBlurSprites[i].getScaleY()!=1.0f&& constants.ConstantValues.pattern=='d') {
						if (smileyDir[i].contains("down")) {
							SmileyBlurSprites[i].setPosition(SmileyBlurSprites[i].getX(), SmileyBlurSprites[i].getY()-SmileyBlurSprites[i].getHeight()/8);
						}
						else
						{
							SmileyBlurSprites[i].setPosition(SmileyBlurSprites[i].getX(), SmileyBlurSprites[i].getY()+SmileyBlurSprites[i].getHeight()/8);
						}
					}
					
				}
				
				SmileyBlurSprites[i].draw(batch);

				SmileySprites[i].draw(batch);
			}
		}
	}
	
	public void showSmiley() {
		// TODO Auto-generated method stub
		for (int i = 0; i < SmileySprites.length; i++) {
			if (smileyVisible[i]==0) {

				if (Levels.blockPlace.equals("down")) {
					smileyDir[i] = "down";			
				}
			
				
				smileyVisible[i]=1;
				
				SmileySprites[i]=null;
				SmileyBlurSprites[i]=null;
				ShuffleLogic.shuffleArray(smileyNo);
				SmileyIconNos[i] = smileyNo[0];
				SmileySprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(DashPlay.getPattern()+(SmileyIconNos[i]+1)+"rect"));
				SmileyBlurSprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(GamePlay.getBlurPattern()+(SmileyIconNos[i]+1)+"blur"));

				setSmileyPosition(i);
				Levels.emoCnt++;
				break;		
			}
		}
	}
	
	
	private void setSmileyPosition(int i) {
		// TODO Auto-generated method stub
		
		float SmileyY=0;
		switch (smileyDir[i]) {
		case "up":
			SmileyY = 0 - SmileySprites[i].getHeight();
			break;
		case "down":				
			SmileyY = constants.ConstantValues.CAMERA_HEIGHT;
			break;		
		default:
			break;
		}
		
		int no= Math.abs(ran.nextInt()%4);
		float smileyX=DashSquareBlock.xypos[no][0];
		SmileySprites[i].setPosition(smileyX,SmileyY);
		
		if (!constants.ConstantValues.isTapTapTutorial) {
			if (i == 0 && DashSquareBlock.symSequence[no] == SmileyIconNos[0]) {
				if (no<3) {
					SmileySprites[i].setPosition(DashSquareBlock.xypos[no+1][0],SmileyY);
				}
				else
				{
					SmileySprites[i].setPosition(DashSquareBlock.xypos[no-1][0],SmileyY);
				}
			}
			else if (i == 1 && DashSquareBlock.symSequence[no] == SmileyIconNos[1]) {
				if (no<3) {
					SmileySprites[i].setPosition(DashSquareBlock.xypos[no+1][0],SmileyY);
				}
				else
				{
					SmileySprites[i].setPosition(DashSquareBlock.xypos[no-1][0],SmileyY);
				}
			}
		}
		
		
	}
	
	public void checkCollision() {
		// TODO Auto-generated method stub
		for (int i = 0; i < smileyRectangles.length; i++) {
			for (int j = 0; j < DashSquareBlock.collisionRectangles.length; j++) {
				if (smileyVisible[i]!=0 && smileyRectangles[i].overlaps(DashSquareBlock.collisionRectangles[j]) )
				{
					if( SmileyIconNos[i] ==  DashSquareBlock.symSequence[j])
					{
						//System.out.println("collision no:"+j);
						Levels.emoCollisionCnt++;
						Score.updateScore();
						smileyVisible[i] = 0;
						DashSmiley.smileyDash=-1;
						if ( !constants.ConstantValues.isTapTapTutorial)
							{
								tapind++;
								if (tapind <= 1) {
									DashPlay.gameState="runtut";	
									TapandholdTut.showTut=true;
									int no=0,no1=0;
									for (int k = 0; k < DashSquareBlock.emoSymbols.length; k++) {
										if (SmileySprites[tapind].getX()== DashSquareBlock.xypos[k][0]) {
											no = k;
										}
										if (SmileyIconNos[tapind] == DashSquareBlock.symSequence[k]) {
												no1 = k;
										}
										
									}
									TapandholdTut.tutSprite.setPosition(DashSquareBlock.xypos[no1][0], DashSquareBlock.xypos[no1][1]-50);
								}
								else
								{
								DashPlay.gameState="run";	
								TapandholdTut.showTut=false;
								constants.ConstantValues.isTapTapTutorial=true;
								PreferenceClass.saveTaptapTut(1);
								}
							}
						for (int j2 = 0; j2 < DashSquareBlock.emoSymbols.length; j2++) {
							if (DashSquareBlock.emoSymbols[j2].getX() == DashSquareBlock.xypos[j][0] && 
									DashSquareBlock.emoSymbols[j2].getY() == DashSquareBlock.xypos[j][1]) {
								if (constants.ConstantValues.isTapTapTutorial)
								DashSquareBlock.emoSymbols[j2].setScale(1.15f);
								if (DashSquareBlock.emoSymbolNos[j2]==1) {
									DashSquareBlock.emoSymbolNos[j2] = 0;
								}
								break;
							}
						}
						
					}
					else
					{
						
							smileyGameOverNo=i;
							smileyGameOverPartNo=j;
							gameOverFn();
						
					}
				}
			}
		}
	}

	public static void gameOverFn()
	{
		int i = smileyGameOverNo;
		int j = smileyGameOverPartNo;
		if(SmileyIconNos[i]>=0) {
			smileyVisible[i] = 0;
			DashPlay.gameState="gameoveranim";
			String direction ="down";
			if (smileyDir[i].contains("up")) {
				direction="up";
			}
			ParticleEffectsClass.startEmitter();
			ParticleEffectsClass.setPosition(DashSmiley.SmileySprites[i].getX(),DashSquareBlock.collisionRectangles[j].getY(),direction);
			SoundManager.playGameOver();
			Score.compareScores();
			for (int k = 0; k < SmileyIconNos.length; k++) {
				SmileyIconNos[k] = -1;
			}
		}
	}
}
