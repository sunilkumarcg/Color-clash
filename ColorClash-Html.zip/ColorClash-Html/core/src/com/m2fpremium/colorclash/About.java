package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Align;

import constants.ConstantValues;

public class About extends GameState {

    SpriteBatch batch,batch1;
    Sprite bgSprite,titleSprite;
   
    GameButton button[];
    String btnName="";
    public static boolean button_initializ = false;    
    
    TextureRegion[] backRegn = new TextureRegion[2];
 
    TextureAtlas uiAtlas,atlas;
    
    private float down_X;
   	private float down_Y;
   	private float up_X;
   	private float up_Y;
    
   FontObj fontObj;
   	
	public About(GameStateManager gsm) {
		super(gsm);
		
		fontObj= new FontObj();
		MyInputProcessor myInputProcessor = new MyInputProcessor();
	    InputMultiplexer im = myInputProcessor.returnInput();
		Gdx.input.setInputProcessor(im);  		
		
		button = new GameButton[1];
		
		batch = new SpriteBatch();
		bgSprite= new Sprite( MyGdxGame.uiAtlas.findRegion("Menu-bg"));
		bgSprite.setPosition(0, 0);
		bgSprite.setSize(ConstantValues.CAMERA_WIDTH, ConstantValues.CAMERA_HEIGHT);
		if(ConstantValues.langCode==2)
			titleSprite = new Sprite(new TextureRegion(new Texture(Gdx.files.internal("ingame/title_IT.png"))));
		else if(ConstantValues.langCode==3)
			titleSprite = new Sprite(new TextureRegion(new Texture(Gdx.files.internal("ingame/title_ES.png"))));
		else
			titleSprite = new Sprite(MyGdxGame.uiAtlas.findRegion("title"));

		titleSprite.setScale(0.7f);
		titleSprite.setPosition(ConstantValues.CAMERA_WIDTH/2-titleSprite.getWidth()/2, ConstantValues.CAMERA_HEIGHT/3+50);

		batch1 = new SpriteBatch();
		
		uiAtlas = new TextureAtlas("packers/ui/ui.pack");
		try {
			backRegn[0] = uiAtlas.findRegion("back_off");
			backRegn[1] = uiAtlas.findRegion("back_on");
		
			
        	loadMenuImages();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleInput() {
		// TODO Auto-generated method stub
	 	if (button_initializ) {
			for (int i = 0; i < button.length; i++) {

				if (button[i].isClicked() && btnName.equals("")) {
					if (i == 0) {
						SoundManager.playClick();
						btnName = "menu";
						button[0].buttonTouched = true;					
					}				
			}
		}
	 	
	 	if (MyInput.isDown(0)) {
			down_X = MyInput.Down_x;
			down_Y = ConstantValues.CAMERA_HEIGHT - MyInput.Down_y;		
		}
		if (MyInput.isUp(0)) {
			up_X = MyInput.Up_x;
			up_Y = ConstantValues.CAMERA_HEIGHT - MyInput.Up_y;
			
			handleTheGame();
		}
	 	}
	 	if (MyInputProcessor.isKeyDown )
		{			
			ChangeScreen(GameStateManager.MENU);
			MyInputProcessor.isKeyDown=false;
		}	
	}
	
	
	
	public void handleTheGame() {
		// TODO Auto-generated method stub
		if (button_initializ) {
			for (int j = 0; j < button.length; j++) {
				button[j].buttonTouched = false;
			}
		}	
		if (btnName.equals("menu")) {
			ChangeScreen(GameStateManager.MENU);
		}
		btnName="";
	}

	@Override
	public void render() {
		// TODO Auto-generated method stub
    	cam.update();
    	Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
    	
    	
    	batch.setProjectionMatrix(cam.combined); 
        batch.begin();
        bgSprite.draw(batch);
        titleSprite.draw(batch);

    	/*MyGdxGame.getMediumFont().draw(batch, LocalizedStrings.APP_NAME,
    			ConstantValues.CAMERA_WIDTH/2 - fontObj.getStringWidth(MyGdxGame.getMediumFont(), LocalizedStrings.APP_NAME), ConstantValues.CAMERA_HEIGHT - 50);
*/
    	MyGdxGame.getMediumFont().draw(batch,   LocalizedStrings.aboutDesc, ConstantValues.CAMERA_WIDTH/2 -230,
    			ConstantValues.CAMERA_HEIGHT/2 +140, 500, Align.center, true);
    			
        
        if (button_initializ) {
			if (button[0].buttonTouched) {
				button[0].render(batch, backRegn[1]);			
			} else {
				button[0].render(batch, backRegn[0]);		
			}
    	}
    	if (MyGdxGame.demobool) {
			MyGdxGame.demoSprite.draw(batch);
		}
        batch.end();
	}

	@Override
	public void update(float f) {
		// TODO Auto-generated method stub
		if (button_initializ) {
			for (int i = 0; i < button.length; i++) {
				button[i].update(Gdx.graphics.getDeltaTime());
			}
		}
		handleInput();
	}

	  private void loadMenuImages() {
			// TODO Auto-generated method stub
	  
	    	button[0] = new GameButton(backRegn[0],ConstantValues.CAMERA_WIDTH-backRegn[0].getRegionWidth()*0.8f-ConstantValues.xAdjPos,  backRegn[0].getRegionHeight()/2,MyGdxGame.bgCamera,0);
	  
	    	MyInput.Down_x = 0;
			MyInput.Down_y = 0;
			MyInput.Up_x = 0;
			MyInput.Up_y = 0;
			MyInput.Drag_x = 0;
			MyInput.Drag_y = 0;
	    	
			button_initializ = true;
		}
}
