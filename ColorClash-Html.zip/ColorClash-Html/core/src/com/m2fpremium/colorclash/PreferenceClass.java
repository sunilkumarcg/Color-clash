package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;

public class PreferenceClass {

	static Preferences myPrefs;
	
	public static final String coinkey="totcoins";
	public static final String scrkey="highscr";
	public static final String scrkeyclassic="highscrclassic";
	public static final String scrkeyspin="highscrspin";
	public static final String scrkeytap="highscrtap";
	public static final String scrkeydash="highscrdash";
	public static final String tutkeyclassic="tutkeyclassic";
	public static final String tutkeyspin="tutkeyspin";
	public static final String tutkeytap="tutkeytap";
	public static final String musickey="musicval";
	public static final String soundkey="soundval";
	public static final String ratekey="rateus";
	
	public PreferenceClass() {
		// TODO Auto-generated constructor stub
		if (myPrefs==null) {
			myPrefs = Gdx.app.getPreferences("colorswitchprem");
		}
	}

	public static int readRateKey()
	{
		return myPrefs.getInteger(ratekey, 0);
	}
	public static void setRateKey(int scr)
	{
		myPrefs.putInteger(ratekey, scr);
		myPrefs.flush();
	}


	public static void saveMusicval(int scr) {
		// TODO Auto-generated method stub
		myPrefs.putInteger(musickey, scr);	
		myPrefs.flush();
	}
	public static  int readMusicVal() {
		// TODO Auto-generated method stub
		return myPrefs.getInteger(musickey, 0);
	}
	
	public static void saveSoundval(int scr) {
		// TODO Auto-generated method stub
		myPrefs.putInteger(soundkey, scr);	
		myPrefs.flush();
	}
	public static  int readSoundVal() {
		// TODO Auto-generated method stub
		return myPrefs.getInteger(soundkey, 0);
	}
	
	public static void saveBestScore(int scr) {
		// TODO Auto-generated method stub
		myPrefs.putInteger(scrkey, scr);	
		myPrefs.flush();
	}
	public static  int readBestScore() {
		// TODO Auto-generated method stub
		return myPrefs.getInteger(scrkey, 0);
	}
	
	public static void saveBestScoreClassic(int scr) {
		// TODO Auto-generated method stub
		myPrefs.putInteger(scrkeyclassic, scr);	
		myPrefs.flush();
	}
	public static int readBestScoreClassic() {
		// TODO Auto-generated method stub
		return myPrefs.getInteger(scrkeyclassic, 0);
	}
	public static void saveBestScoreSpin(int scr) {
		// TODO Auto-generated method stub
		myPrefs.putInteger(scrkeyspin, scr);	
		myPrefs.flush();
	}
	public static int readBestScoreSpin() {
		// TODO Auto-generated method stub
		return myPrefs.getInteger(scrkeyspin, 0);
	}
	public static void saveBestScoreTap(int scr) {
		// TODO Auto-generated method stub
		myPrefs.putInteger(scrkeytap, scr);	
		myPrefs.flush();
	}
	public static int readBestScoreTap() {
		// TODO Auto-generated method stub
		return myPrefs.getInteger(scrkeytap, 0);
	}
	public static void saveBestScoreDash(int scr) {
		// TODO Auto-generated method stub
		myPrefs.putInteger(scrkeydash, scr);	
		myPrefs.flush();
	}
	public static int readBestScoreDash() {
		// TODO Auto-generated method stub
		return myPrefs.getInteger(scrkeydash, 0);
	}
	
	public static void saveClassicTut(int scr) {
		// TODO Auto-generated method stub
		myPrefs.putInteger(tutkeyclassic, scr);	
		myPrefs.flush();
	}
	public static int readClassicTut() {
		// TODO Auto-generated method stub
		return myPrefs.getInteger(tutkeyclassic, 0);
	}
	
	public static void saveSpinTut(int scr) {
		// TODO Auto-generated method stub
		myPrefs.putInteger(tutkeyspin, scr);	
		myPrefs.flush();
	}
	public static int readSpinTut() {
		// TODO Auto-generated method stub
		return myPrefs.getInteger(tutkeyspin, 0);
	}
	public static void saveTaptapTut(int scr) {
		// TODO Auto-generated method stub
		myPrefs.putInteger(tutkeytap, scr);	
		myPrefs.flush();
	}
	public static int readTaptapTut() {
		// TODO Auto-generated method stub
		return myPrefs.getInteger(tutkeytap, 0);
	}
	
}
