package com.m2fpremium.colorclash;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.input.GestureDetector;
import com.badlogic.gdx.input.GestureDetector.GestureListener;
import com.badlogic.gdx.math.Vector2;


import constants.ConstantValues;

public class MyInputProcessor extends InputAdapter implements InputProcessor,GestureListener {

	public static boolean isTouchDown=false;
	public static boolean isTouchUp=false;
	public static boolean isTap=false;
	public static boolean isLongPress=false;
	public static boolean isFling=false;
	public static boolean isSwipeDown=false;
	public static boolean isSwipeUp=false;
	public static boolean isSwipeLeft=false;
	public static boolean isSwipeRight=false;
	public static boolean isKeyDown=false;
	public static String downKey="";

	public static boolean isZoomed=false;
	public static float zoomInitDist=0;
	public static float zoomDist=0;

	public static boolean isTapLeft=false;
	public static boolean isTapRight=false;



	public MyInputProcessor() {
		// TODO Auto-generated constructor stub
		// System.out.println("My Input Processor Created..");
	}

	public InputMultiplexer returnInput() {
		// TODO Auto-generated method stub
		InputMultiplexer im = new InputMultiplexer();
		GestureDetector gd = new GestureDetector(this);
		im.addProcessor(gd);
		im.addProcessor(this);

		return im;
	}


	@Override
	public boolean tap(float x, float y, int count, int button) {
		// TODO Auto-generated method stub

		if (DashPlay.gameState.equals("run") || EndlessPlay.gameState.equals("run") || GamePlay.gameState.equals("run") || SpinPlay.gameState.equals("run")) {

			if (x< ConstantValues.inputX) {
				isTapLeft = true;
				isTapRight=false;
			}
			else
			{
				isTapLeft = false;
				isTapRight=true;
			}
		}
		x = (x * ConstantValues.CAMERA_WIDTH) / Gdx.graphics.getWidth();
		y = (y * ConstantValues.CAMERA_HEIGHT) / Gdx.graphics.getHeight();
		if (MyInput.touch) {
			MyInput.Up_x = x;
			MyInput.Up_y = y;
			MyInput.setKey(MyInput.BUTTON1, false);
		}
		/*else
		{*/

		/*}*/


		return false;
	}

	@Override
	public boolean longPress(float x, float y) {
		// TODO Auto-generated method stub

		return false;
	}

	@Override
	public boolean fling(float velocityX, float velocityY, int button) {
		// TODO Auto-generated method stub
		if(Math.abs(velocityX)>Math.abs(velocityY)){
			if(velocityX>0){
				this.isSwipeRight=true;
			}else{
				this.isSwipeLeft=true;
			}
		}else{
			//System.out.println(velocityY+"velo");
			if(velocityY>ConstantValues.CAMERA_HEIGHT/2){
				this.isSwipeDown=true;
			}else if(velocityY < 0){
				this.isSwipeUp=true;
			}
		}

		return false;
	}

	@Override
	public boolean pan(float x, float y, float deltaX, float deltaY) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean panStop(float x, float y, int pointer, int button) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean zoom(float initialDistance, float distance) {
		// TODO Auto-generated method stub
		this.isZoomed=true;
		this.zoomInitDist=initialDistance;
		this.zoomDist=distance;
		return false;
	}

	@Override
	public boolean pinch(Vector2 initialPointer1, Vector2 initialPointer2, Vector2 pointer1, Vector2 pointer2) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void pinchStop() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean keyDown(int keycode) {
		// TODO Auto-generated method stub

		//System.out.println("keycode"+keycode);

		if(ConstantValues.isAndroidDevice && keycode == Keys.BACK)
		{
			this.isKeyDown=true;
		}
		else if (!ConstantValues.isAndroidDevice) {
			this.isKeyDown=true;
		}
		return false;
	}

	@Override
	public boolean keyUp(int keycode) {
		// TODO Auto-generated method stub

		return false;
	}

	@Override
	public boolean keyTyped(char character) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		// TODO Auto-generated method stub
		//System.out.println("Down===1");
		this.isLongPress=true;
		SpinPlay.spinTime=0;

		screenX =(screenX * ConstantValues.CAMERA_WIDTH) / Gdx.graphics.getWidth();
		screenY = (screenY * ConstantValues.CAMERA_HEIGHT) / Gdx.graphics.getHeight();
		if (MyInput.touch) {
			MyInput.Down_x = screenX;
			MyInput.Down_y = screenY;
			MyInput.setKey(MyInput.BUTTON1,true);
		}

		//  System.out.println("down");
		// SpinSquareBlock.spinTimeTotVal=5;
		return false;
	}


	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean scrolled(int amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchDown(float x, float y, int pointer, int button) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchUp(int x, int y, int pointer, int button) {
		// TODO Auto-generated method stub
		//System.out.println("up");
		x = (x * ConstantValues.CAMERA_WIDTH) / Gdx.graphics.getWidth();
		y = (y * ConstantValues.CAMERA_HEIGHT) / Gdx.graphics.getHeight();
		if (MyInput.touch) {
			MyInput.Up_x = x;
			MyInput.Up_y = y;
			MyInput.setKey(MyInput.BUTTON1, false);
		}
		this.isLongPress=false;
		return false;
	}
}
