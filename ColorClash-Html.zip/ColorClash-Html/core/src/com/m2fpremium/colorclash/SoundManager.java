package com.m2fpremium.colorclash;


public class SoundManager {
	public static int sndNo=1;
	public static boolean sndRevBool=false;
	public static float volLevel=1.0f;
	
	public static final  void playClick() {
		// TODO Auto-generated method stub
		if (constants.ConstantValues.isSoundEnabled) {
			MyGdxGame.res.getSound("click").play(0.8f);
		}
	}
	
	public static final  void playTrans() {
		// TODO Auto-generated method stub
		if (constants.ConstantValues.isSoundEnabled) {
			MyGdxGame.res.getSound("transblock").play();
		}
	}
	
	public static final  void playFall() {
		// TODO Auto-generated method stub
		if (constants.ConstantValues.isSoundEnabled) {
			MyGdxGame.res.getSound("fall").play();
		}
	}
	
	public static final  void playSpin() {
		// TODO Auto-generated method stub
		if (constants.ConstantValues.isSoundEnabled && !MyGdxGame.res.getMusic("spinMusic").isPlaying()) {
			if(!MyGdxGame.res.getMusic("spinMusic").isLooping())
			{
				MyGdxGame.res.getMusic("spinMusic").setLooping(true);
			}
			MyGdxGame.res.getMusic("spinMusic").play();
		}
	}
	
	public static final  void stopSpin() {
		// TODO Auto-generated method stub
		if (MyGdxGame.res.getMusic("spinMusic").isPlaying()) {
			MyGdxGame.res.getMusic("spinMusic").stop();
		}
	}
	
	public static final  void playModes() {
		// TODO Auto-generated method stub
		if (constants.ConstantValues.isSoundEnabled) {
			MyGdxGame.res.getSound("modes").play();
			playMenuMusic();

		}
	}
	
	public static final  void playMatch() { 
		// TODO Auto-generated method stub
		if (constants.ConstantValues.isSoundEnabled) {
			sndNo++;
			 	if (sndNo > 12) {
			 		sndNo=1;
				}
				MyGdxGame.res.getSound(Integer.toString(sndNo)).play();
				/*if (!sndRevBool) {
					sndNo++;
					if ((sndNo > 7) ) {
						sndNo=1;
						sndRevBool=true;
					}
					MyGdxGame.res.getSound(Integer.toString(sndNo)).play();
					if (sndRevBool) {
						sndNo=7;
					}
				}
				else
				{
					sndNo--;
					if ((sndNo < 1) ) {
						sndNo=1;
						sndRevBool=false;
					}
					MyGdxGame.res.getSound(Integer.toString(sndNo)).play();
				}	*/
		}
	}
	public static final  void playGameOver() {
		// TODO Auto-generated method stub
		if (constants.ConstantValues.isSoundEnabled) {
			MyGdxGame.res.getSound("gameover").play();
		}
	}
	
	
	public static final void playBgMusic() {
		// TODO Auto-generated method stub
		//MyGdxGame.res.getMusic("bgMusic").setVolume(0.3f);
		/*constants.ConstantValues.isBSuspend=false;
		if (constants.ConstantValues.isMusicEnabled && !MyGdxGame.res.getMusic("bgMusic").isPlaying()) {
			if(!MyGdxGame.res.getMusic("bgMusic").isLooping())
			{
				MyGdxGame.res.getMusic("bgMusic").setLooping(true);
			}
			
			MyGdxGame.res.getMusic("bgMusic").play();
			
		}*/
	}
	public static final void stopBgMusic() {
		// TODO Auto-generated method stub
		constants.ConstantValues.isBSuspend=true;
		if (MyGdxGame.res.getMusic("bgMusic").isPlaying()) {
			MyGdxGame.res.getMusic("bgMusic").stop();
		}
	}
	
	public static final void playMenuMusic() {
		// TODO Auto-generated method stub
		//MyGdxGame.res.getMusic("bgMusic").setVolume(1.0f);

		/*if (constants.ConstantValues.isMusicEnabled && !MyGdxGame.res.getMusic("bgMusic").isPlaying()) {
			if(!MyGdxGame.res.getMusic("bgMusic").isLooping())
			{
				MyGdxGame.res.getMusic("bgMusic").setLooping(true);
			}
			MyGdxGame.res.getMusic("bgMusic").play();
			
		}*/
	}
	public static final void stopMenuMusic() {
		// TODO Auto-generated method stub
		if (MyGdxGame.res.getMusic("bgMusic").isPlaying()) {
			MyGdxGame.res.getMusic("bgMusic").stop();
		}
	}
	
	public static final void stopAll()
	{
		stopMenuMusic();
		stopBgMusic();
		stopSpin();
	}
	
}
