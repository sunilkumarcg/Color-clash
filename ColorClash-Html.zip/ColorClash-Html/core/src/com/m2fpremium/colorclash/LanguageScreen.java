package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import constants.ConstantValues;

/**
 * Created by Nirosha on 29-03-2018.
 */

public class LanguageScreen extends GameState {
    SpriteBatch batch;
    Sprite bgSprite;

    private float down_X;
    private float down_Y;
    private float up_X;
    private float up_Y;
    String btnName="";

    public static boolean button_initializ = false;
    GameButton button[];

    TextureRegion[] engRegn=new TextureRegion[2];
    TextureRegion[] italianRegn=new TextureRegion[2];
    TextureRegion[] spanishRegn=new TextureRegion[2];

    public LanguageScreen(GameStateManager gsm) {
        super(gsm);
        button=new GameButton[3];
        batch = new SpriteBatch();
        bgSprite = new Sprite(MyGdxGame.langAtlas.findRegion("bg1"));
        bgSprite.setSize(ConstantValues.CAMERA_WIDTH,ConstantValues.CAMERA_HEIGHT);
        bgSprite.setPosition(ConstantValues.CAMERA_WIDTH/2-bgSprite.getWidth()/2,ConstantValues.CAMERA_HEIGHT/2-bgSprite.getHeight()/2);

        engRegn[0]= MyGdxGame.langAtlas.findRegion("english_off");
        engRegn[1]= MyGdxGame.langAtlas.findRegion("english_on");

        italianRegn[0]= MyGdxGame.langAtlas.findRegion("italian_off");
        italianRegn[1]= MyGdxGame.langAtlas.findRegion("italian_on");

        spanishRegn[0]= MyGdxGame.langAtlas.findRegion("spanish_off");
        spanishRegn[1]= MyGdxGame.langAtlas.findRegion("spanish_on");

        loadLangImaes();
    }

    private void loadLangImaes() {
        // TODO Auto-generated method stub

        button[0] = new GameButton(engRegn[0],ConstantValues.CAMERA_WIDTH/2,    ConstantValues.CAMERA_HEIGHT/2+engRegn[0].getRegionHeight()*1.4f, cam,0);
        button[1] = new GameButton(italianRegn[0], ConstantValues.CAMERA_WIDTH/2,    ConstantValues.CAMERA_HEIGHT/2, cam,1);
        button[2] = new GameButton(spanishRegn[0],ConstantValues.CAMERA_WIDTH/2,    ConstantValues.CAMERA_HEIGHT/2-engRegn[0].getRegionHeight()*1.4f, cam,2);

        MyInput.Down_x = 0;
        MyInput.Down_y = 0;
        MyInput.Up_x = 0;
        MyInput.Up_y = 0;
        MyInput.Drag_x = 0;
        MyInput.Drag_y = 0;

        button_initializ = true;
    }

    @Override
    public void dispose() {

    }

    @Override
    public void handleInput() {
        if (button_initializ) {
            for (int i = 0; i < button.length; i++) {

                if (button[i].isClicked() && btnName.equals("")) {
                   // SoundManager.playClick();
                    if (i == 0) {
                        btnName = "1";
                        ConstantValues.langCode=1;
                        button[0].buttonTouched = true;
                    }
                    if (i == 1) {
                        btnName = "1";
                        ConstantValues.langCode=2;
                        button[1].buttonTouched = true;
                    }
                    if (i == 2) {
                        btnName = "1";
                        ConstantValues.langCode=3;
                        button[2].buttonTouched = true;
                    }
                }
            }
        }
        if (MyInput.isDown(0)) {
            down_X = MyInput.Down_x;
            down_Y = ConstantValues.CAMERA_HEIGHT - MyInput.Down_y;
        }
        if (MyInput.isUp(0)) {
            up_X = MyInput.Up_x;
            up_Y = ConstantValues.CAMERA_HEIGHT - MyInput.Up_y;

            handleTheGame();
        }
    }

    public void handleTheGame() {
        // TODO Auto-generated method stub
        if (button_initializ) {
            for (int j = 0; j < button.length; j++) {
                button[j].buttonTouched = false;
            }
        }

        if (btnName.equals("1")) {
            ChangeScreen(GameStateManager.LOGO);
        }

        btnName="";
    }

    @Override
    public void render() {
        cam.update();
        Gdx.gl.glClearColor(255, 255, 255, 0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.setProjectionMatrix(cam.combined);
        batch.begin();
        bgSprite.draw(batch);
        if (button_initializ) {
            if (button[0].buttonTouched)
                button[0].render(batch, engRegn[1]);
            else
                button[0].render(batch, engRegn[0]);

            if (button[1].buttonTouched)
                button[1].render(batch, italianRegn[1]);
            else
                button[1].render(batch, italianRegn[0]);

            if (button[2].buttonTouched)
                button[2].render(batch, spanishRegn[1]);
            else
                button[2].render(batch, spanishRegn[0]);
        }
        batch.end();

    }

    @Override
    public void update(float f) {
        if (button_initializ) {
            for (int i = 0; i < button.length; i++) {
                button[i].update(Gdx.graphics.getDeltaTime());
            }
        }
        handleInput();
    }
}
