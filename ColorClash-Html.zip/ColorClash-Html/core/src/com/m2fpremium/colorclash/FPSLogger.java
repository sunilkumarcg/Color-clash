package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.TimeUtils;

public class FPSLogger {

	long startTime;

	public FPSLogger () {
		startTime = TimeUtils.nanoTime();
	}

	/** Logs the current frames per second to the console. */
	public void log () {
		if (TimeUtils.nanoTime() - startTime > 1000000000) /* 1,000,000,000ns == one second */{
			Gdx.app.log("FPSLogger", "fps: " + Gdx.graphics.getFramesPerSecond());
			startTime = TimeUtils.nanoTime();
		}
	}

}
