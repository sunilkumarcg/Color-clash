package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.ParticleEffect;
import com.badlogic.gdx.graphics.g2d.ParticleEmitter;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Array;

import java.util.Random;

public class ParticleEffectsClass {

	ParticleEffect effect,effect1;
	static int emitterIndex=1;
	ParticleEmitter emitter;
	static Array<ParticleEmitter> emitters;
	static Array<ParticleEmitter> emitters1;

	int width=0;
	int height=0;
	Rectangle rect;
	Pixmap pixmap;
	Texture pixmapTexture;
	
	int widthInc= constants.ConstantValues.CAMERA_WIDTH/30;
	int hgtInc= constants.ConstantValues.CAMERA_HEIGHT/30;

	public static float[][]  colors= {{0.047f,0.6f,0.66f},{0.494f,0.266f,0.831f},{0.05f,0.423f,0.741f},{0.047f,0.66f,0.321f}};
	 
	Random rand = new Random();
	public static int rndno ;
	
	public ParticleEffectsClass() {
		// TODO Auto-generated constructor stub
	
		effect = new ParticleEffect();
		effect.load(Gdx.files.internal("particles/CollisionParticles_11July2017"), Gdx.files.internal("particles"));
		
	/*	effect1 = new ParticleEffect();
		effect1.load(Gdx.files.internal("particles/CollisionParticles_11July2017"), Gdx.files.internal("particles"));		
	*/	
		emitters = new Array(effect.getEmitters());
	//	emitters1 = new Array(effect1.getEmitters());
	//effect.getEmitters().add(emitters.get(0));
		
		if (constants.ConstantValues.pattern == 'r') {
				emitterIndex=0;
		}
		else if (constants.ConstantValues.pattern == 'd')
		{
			    emitterIndex=1;
		}
		else if (constants.ConstantValues.pattern == 'o')
		{
				emitterIndex=2;
		}
		else if (constants.ConstantValues.pattern == 'c')
		{
				emitterIndex=3;
		}
		emitters.get(emitterIndex).setPosition(-1000, -1000);
		emitters.get(emitterIndex).addParticles(500);
		
	/*	emitters1.get(emitterIndex).setPosition(-1000, -1000);
		emitters1.get(emitterIndex).addParticles(500);
		*/
		effect.scaleEffect(3.3f);
		effect.setPosition(-1000, -1000);
		
		/*effect1.scaleEffect(2.3f);
		effect1.setPosition(-1000, -1000);
		*/
		rect = new Rectangle(0, 0, width, height);
		
		pixmap = new Pixmap(256,256,Pixmap.Format.RGBA8888);
		pixmap.setColor((float)(12/255), (float)(156/255), (float)(169/255), 1);

		pixmapTexture = new Texture(pixmap);
	}
	
	public static void setPosition(float x,float y,String dir) {
		// TODO Auto-generated method stub
		//emitters.get(emitterIndex).addParticles(count);
	
		switch (Levels.mode) {
		case "mixup":
			if (dir.equals("up")) {
				emitters.get(emitterIndex).setFlip(false, true);
				emitters.get(emitterIndex).setPosition(x+Smiley.SmileySprites[0].getWidth()/2,y/*+Smiley.SmileySprites[0].getHeight()*1.5f*/);
			//	emitters1.get(emitterIndex).setPosition(x+Smiley.SmileySprites[0].getWidth()/2,y/*+Smiley.SmileySprites[0].getHeight()*1.5f*/);				
			}
			else
			{
				emitters.get(emitterIndex).setFlip(false, false);
			emitters.get(emitterIndex).setPosition(x+Smiley.SmileySprites[0].getWidth()/2,y+Smiley.SmileySprites[0].getHeight()*1.5f);
			//emitters1.get(emitterIndex).setPosition(x+Smiley.SmileySprites[0].getWidth()/2,y+Smiley.SmileySprites[0].getHeight()*1.5f);
			}
			break;
		case "dash":
			if (dir.equals("up")) {		
			emitters.get(emitterIndex).setPosition(x+DashSmiley.SmileySprites[0].getWidth()/2,y+DashSmiley.SmileySprites[0].getHeight()*1.5f);
		//	emitters1.get(emitterIndex).setPosition(x+DashSmiley.SmileySprites[0].getWidth()/2,y+DashSmiley.SmileySprites[0].getHeight()*1.5f);
			}
			else
			{
				emitters.get(emitterIndex).setFlip(false, false);
				emitters.get(emitterIndex).setPosition(x+DashSmiley.SmileySprites[0].getWidth()/2,y+DashSmiley.SmileySprites[0].getHeight()*1.5f);
				//emitters1.get(emitterIndex).setPosition(x+DashSmiley.SmileySprites[0].getWidth()/2,y+DashSmiley.SmileySprites[0].getHeight()*1.5f);
				
			}
			break;
		case "spin":
			if (dir.equals("up")) {		
			emitters.get(emitterIndex).setPosition(x+SpinSmiley.SmileySprites[0].getWidth()/2,y+SpinSmiley.SmileySprites[0].getHeight()*1.5f);
			//emitters1.get(emitterIndex).setPosition(x+SpinSmiley.SmileySprites[0].getWidth()/2,y+SpinSmiley.SmileySprites[0].getHeight()*1.5f);
			}
			else
			{
				emitters.get(emitterIndex).setFlip(false, false);
				emitters.get(emitterIndex).setPosition(x+SpinSmiley.SmileySprites[0].getWidth()/2,y+SpinSmiley.SmileySprites[0].getHeight()*1.5f);
			//	emitters1.get(emitterIndex).setPosition(x+SpinSmiley.SmileySprites[0].getWidth()/2,y+SpinSmiley.SmileySprites[0].getHeight()*1.5f);
				
			}
			break;
		case "endless":
			if (dir.equals("up")) {		
			emitters.get(emitterIndex).setPosition(x+EndlessSmiley.SmileySprites[0].getWidth()/2,y+EndlessSmiley.SmileySprites[0].getHeight()*1.5f);
			//emitters1.get(emitterIndex).setPosition(x+EndlessSmiley.SmileySprites[0].getWidth()/2,y+EndlessSmiley.SmileySprites[0].getHeight()*1.5f);
			}
			else
			{
				emitters.get(emitterIndex).setFlip(false, false);
				emitters.get(emitterIndex).setPosition(x+EndlessSmiley.SmileySprites[0].getWidth()/2,y+EndlessSmiley.SmileySprites[0].getHeight()*1.5f);
			//	emitters1.get(emitterIndex).setPosition(x+EndlessSmiley.SmileySprites[0].getWidth()/2,y+EndlessSmiley.SmileySprites[0].getHeight()*1.5f);
				
			}
			break;
		default:
			break;
		}
		

	}
	
	public void update(float f) {
		// TODO Auto-generated method stub
		emitters.get(emitterIndex).update(f);
		//emitters1.get(emitterIndex).update(f);
		if (emitters.get(emitterIndex).isComplete() && 
				(GamePlay.gameState.equals("gameoveranim") ||
				 EndlessPlay.gameState.equals("gameoveranim") ||
				 SpinPlay.gameState.equals("gameoveranim") ||
				 DashPlay.gameState.equals("gameoveranim") )) {
			width=0;
			height=0;
			rndno=Math.abs(rand.nextInt()%4);

			switch (Levels.mode) {
			case "mixup":
				GamePlay.gameState = "gameoverfill";
				break;
			case "dash":
				DashPlay.gameState = "gameoverfill";
				break;
			case "spin":
				SpinPlay.gameState = "gameoverfill";
				break;
			case "endless":
				EndlessPlay.gameState = "gameoverfill";
				break;
			default:
				break;
			}
			
		}
		
	}
	
	public static void startEmitter() {
		// TODO Auto-generated method stub
		ParticleEffectsClass.emitters.get(emitterIndex).start();
		//ParticleEffectsClass.emitters1.get(emitterIndex).start();
	}
	
	public void renderParticle(SpriteBatch batch) {
		// TODO Auto-generated method stub		
		switch (Levels.mode) {
		case "mixup":
			if (GamePlay.gameState.equals("gameoveranim")) {
				//System.out.println("drawing");		
				emitters.get(emitterIndex).draw(batch);	
				//emitters1.get(emitterIndex).draw(batch);	
			}	
			if (GamePlay.gameState.equals("gameoverfill")) {
				drawRect();
				batch.draw(pixmapTexture, constants.ConstantValues.CAMERA_WIDTH/2-width/2, constants.ConstantValues.CAMERA_HEIGHT/2-height/2,
						width,height);
			}
			break;
		case "dash":
			if (DashPlay.gameState.equals("gameoveranim")) {
				//System.out.println("drawing");		
				emitters.get(emitterIndex).draw(batch);	
				//emitters1.get(emitterIndex).draw(batch);	
			}	
			if (DashPlay.gameState.equals("gameoverfill")) {
				drawRect();
				batch.draw(pixmapTexture, constants.ConstantValues.CAMERA_WIDTH/2-width/2, constants.ConstantValues.CAMERA_HEIGHT/2-height/2,
						width,height);
			}
			break;
		case "spin":
			if (SpinPlay.gameState.equals("gameoveranim")) {
				//System.out.println("drawing");		
				emitters.get(emitterIndex).draw(batch);	
				//emitters1.get(emitterIndex).draw(batch);	
			}	
			if (SpinPlay.gameState.equals("gameoverfill")) {
				drawRect();
				batch.draw(pixmapTexture, constants.ConstantValues.CAMERA_WIDTH/2-width/2, constants.ConstantValues.CAMERA_HEIGHT/2-height/2,
						width,height);
			}
			break;
		case "endless":
			if (EndlessPlay.gameState.equals("gameoveranim")) {
				//System.out.println("drawing");		
				emitters.get(emitterIndex).draw(batch);	
				//emitters1.get(emitterIndex).draw(batch);	
			}	
			if (EndlessPlay.gameState.equals("gameoverfill")) {
				drawRect();
				batch.draw(pixmapTexture, constants.ConstantValues.CAMERA_WIDTH/2-width/2, constants.ConstantValues.CAMERA_HEIGHT/2-height/2,
						width,height);
			}
			break;
		default:
			break;
		}
	
	}
	
	  public void drawRect(){
		  if (width< constants.ConstantValues.CAMERA_WIDTH) {
			  width = width + widthInc;
			  height= height + hgtInc;
			
		      pixmap.fillRectangle(0, 0, width, height);
		      pixmap.setColor(colors[rndno][0],colors[rndno][1],colors[rndno][2],1);

		      pixmapTexture.draw(pixmap, 0, 0);
		      pixmapTexture.bind();
		}
		  else if (width >= constants.ConstantValues.CAMERA_WIDTH ) {
			  //GamePlay.gameState="gameover";
			  switch (Levels.mode) {
				case "mixup":
					GamePlay.gameState = "gameover";
					if(MyGdxGame.htmlInterface!=null) {
						MyGdxGame.htmlInterface.showAds();
					}
					break;
				case "dash":
					DashPlay.gameState = "gameover";
					if(MyGdxGame.htmlInterface!=null) {
						MyGdxGame.htmlInterface.showAds();
					}
					break;
				case "spin":
					SpinPlay.gameState = "gameover";
					if(MyGdxGame.htmlInterface!=null) {
						MyGdxGame.htmlInterface.showAds();
					}
					break;
				case "endless":
					EndlessPlay.gameState = "gameover";
					if(MyGdxGame.htmlInterface!=null) {
						MyGdxGame.htmlInterface.showAds();
					}
					break;
				default:
					break;
				}
			  width=0;
			  GameOver.isGameOver=false;
		}
		
	   }
	
}
