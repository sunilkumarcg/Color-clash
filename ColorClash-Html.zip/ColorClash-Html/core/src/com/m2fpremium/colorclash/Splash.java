package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import constants.ConstantValues;

public class Splash extends GameState {
    private int count;
    TextureAtlas loading_atlas;
    public Texture logoImg, demo;
    private AssetManager manager;
	private static boolean managerBool_update;
	private boolean textureLoaded;
	private SpriteBatch batch; 
	public static boolean gameRunState = false;
	
	 Sprite bgSprite,titleSprite,colorBoxSprite;
	

    public Splash(GameStateManager gsm) {
        super(gsm);
        
        batch = new SpriteBatch();
		bgSprite= new Sprite(MyGdxGame.uiAtlas.findRegion("Menu-bg"));

        if(ConstantValues.langCode==2)
            titleSprite = new Sprite(new TextureRegion(new Texture(Gdx.files.internal("ingame/title_IT.png"))));
        else if(ConstantValues.langCode==3)
            titleSprite = new Sprite(new TextureRegion(new Texture(Gdx.files.internal("ingame/title_ES.png"))));
        else
		    titleSprite = new Sprite(MyGdxGame.uiAtlas.findRegion("title"));

		colorBoxSprite = new Sprite(MyGdxGame.uiAtlas.findRegion("4box"));
		titleSprite.setPosition(ConstantValues.CAMERA_WIDTH/2-titleSprite.getWidth()/2, ConstantValues.CAMERA_HEIGHT/4);
		colorBoxSprite.setPosition(ConstantValues.CAMERA_WIDTH/2-colorBoxSprite.getWidth()/2, colorBoxSprite.getY());
		count = 0;
		
		bgSprite.setSize(ConstantValues.CAMERA_WIDTH, ConstantValues.CAMERA_HEIGHT);

		if(MyGdxGame.htmlInterface!=null) {
           // MyGdxGame.htmlInterface.scrollWindow();
            MyGdxGame.htmlInterface.showAds();
        }
    }

    public void handleInput() {
    }

    public void update(float dt) {
    }

    public void render() {
    
    	cam.update();
        Gdx.gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    	Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
    	
    	batch.setProjectionMatrix(cam.combined); 
    	
        batch.begin();
        bgSprite.draw(batch);  
        titleSprite.draw(batch);
        colorBoxSprite.draw(batch);
        if (MyGdxGame.demobool) {
			MyGdxGame.demoSprite.draw(batch);
		}
        batch.end();
        
         cam.update();
         count++;
       
         if ( count >= 150) {
			count = 0;
			ChangeScreen(GameStateManager.MENU);//replace menu
		}
    }

    public void dispose() {
    }
}
