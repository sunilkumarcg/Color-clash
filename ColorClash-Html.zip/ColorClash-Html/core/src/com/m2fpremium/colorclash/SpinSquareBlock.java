package com.m2fpremium.colorclash;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;

import java.util.Random;

public class SpinSquareBlock {

   	public static Sprite roundSprite;
   	public static Sprite[] emoSymbols= new Sprite[4];
   	
   	public static TextureRegion[] emoRegions= new TextureRegion[4];
   	
   	public static Sprite[] backTiles= new Sprite[4];
	public static Rectangle[] collisionRectangles= new Rectangle[4];
	public static int[] symSequence=new int[4];
	
	public static int[][] rotIndexes= {{0,1,2,3},{1,2,3,0},{2,3,0,1},{3,0,1,2}};
	int rotVal=0;
	int spinTimeVal=0;
	public static int spinTimeTotVal=5;
	public static int rotIndex=0;
	public static int transSpeed=10;
	public static float angle =0;
	
	public static float destX=0;
	public static float destY=0;
	public static String movedir="down";
	
	public static int[] emoSymbolNos= new int[4];

	static int[] rotations={0,90,180,270};

	public static float xypos[][] = new float[4][4];
	
	Stage stage;
	static Group group;
	Image img;
	public static Image[] emoSymbolsImg = new Image[emoSymbols.length];
	
	public static float angleHaltVal;
	public static float angleVal;

	public SpinSquareBlock() {
		// TODO Auto-generated constructor stub
		 angle =0;
		 angleHaltVal=0.5f;
		 angleVal=5.0f;
		 
		stage= new Stage();
			//	new Stage(MyGdxGame.viewport);
		if (group!=null) {
			group.clear();
			group=null;
		}
		group = new Group();
		stage.addActor(group);
		
		roundSprite = new Sprite( MyGdxGame.gameAtlas.findRegion("tile"));
		img = new Image(MyGdxGame.gameAtlas.findRegion("tile"));
		
		if (group!=null) {
		group.addActor(img);
		}
		
		for (int i = 0; i < backTiles.length; i++) {
			backTiles[i]= new Sprite( MyGdxGame.gameAtlas.findRegion("tile"));
			collisionRectangles[i] = new Rectangle(backTiles[i].getX(), backTiles[i].getY(), backTiles[i].getWidth()/2, backTiles[i].getHeight()/4);
		}
		
		for (int i = 0; i < symSequence.length; i++) {
			symSequence[i] = i;
		}
		ShuffleLogic.shuffleArray(symSequence);
		//ShuffleLogic.resetIndexes(); 
		
		
		for (int i = 0; i < emoSymbols.length; i++) {
			emoRegions[i]= MyGdxGame.gameAtlas.findRegion(SpinPlay.getPattern()+(symSequence[i]+1)+"rect");
			emoSymbols[i]= new Sprite(emoRegions[i]);
			
		}
		for (int i = 0; i < emoSymbolNos.length; i++) {
			emoSymbolNos[i] = 0;
		}
		Random rnd = new Random();
		int rndNo=Math.abs(rnd.nextInt()%4);
		if (Levels.features[Levels.levelNo].equals("zigzaghide")) {
			emoSymbolNos[rndNo] =1;
		}
		for (int i = 0; i < emoSymbols.length; i++) {
			emoSymbolsImg[i]=new Image( MyGdxGame.gameAtlas.findRegion(SpinPlay.getPattern()+(symSequence[i]+1)+"rect"));
			emoSymbolsImg[i].setName(SpinPlay.getPattern()+(symSequence[i]+1)+"rect");
			if (group!=null) {
			group.addActor(emoSymbolsImg[i]);	
			}
		}

	}
	
	public void resetGame() {
		// TODO Auto-generated method stub
		roundSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2-roundSprite.getWidth()/2, SpinPlay.down_y);
		if (Levels.features[Levels.levelNo].equals("midright")) 
		{
			roundSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH-roundSprite.getWidth()*1.5f, SpinPlay.mid_y);
		}
		else if (Levels.features[Levels.levelNo].equals("downleft")) {		
				roundSprite.setPosition(0+roundSprite.getWidth()/2, SpinPlay.down_y);
		}
		resetTilesPosition();
		img.setPosition(roundSprite.getX(), roundSprite.getY());
		for (int j = 0; j < backTiles.length; j++) {
			emoSymbolsImg[j].setPosition(emoSymbols[j].getX(), emoSymbols[j].getY());
		}
		if (group!=null) {
		group.setOrigin(roundSprite.getX()+roundSprite.getWidth()/2, roundSprite.getY()+roundSprite.getHeight()/2);
		}
	}

	public static void resetTilesPosition() {
		// TODO Auto-generated method stub
		float adjx=8;
		float adjy=8;
		
		xypos[0][0] = roundSprite.getX()-emoSymbols[0].getWidth()/4 + adjx;
		xypos[0][1] = roundSprite.getY()+emoSymbols[0].getHeight()-adjy;
		xypos[1][0] = roundSprite.getX()+emoSymbols[0].getWidth()/2+emoSymbols[0].getWidth()/4 + adjx*3;
		xypos[1][1] = roundSprite.getY()+emoSymbols[0].getHeight()-adjy;
		xypos[2][0] = roundSprite.getX()+emoSymbols[0].getWidth()/2+emoSymbols[0].getWidth()/4+adjx*3;
		xypos[2][1] = roundSprite.getY()-emoSymbols[0].getHeight()/4 +adjy/3;
		xypos[3][0] = roundSprite.getX()-emoSymbols[0].getWidth()/4+adjx;
		xypos[3][1] = roundSprite.getY()-emoSymbols[0].getHeight()/4 +adjy/3;	
	
		for (int i = 0; i < emoSymbols.length; i++) {
			int no = rotIndexes[rotIndex][i];
			backTiles[i].setPosition(xypos[no][0], xypos[no][1]);
			if (emoSymbols[i].getScaleX() > 1.0f) {
        		emoSymbols[i].setScale(1.0f);
    		}
			emoSymbols[i].setPosition(xypos[no][0], xypos[no][1]);
			collisionRectangles[i].setPosition(xypos[i][0],xypos[i][1]);
		}
	}
	
	
	boolean rotbool=false,changebool=false;
	
	public void moveSquareBlock(float et) {
		// TODO Auto-generated method stub
		if (group!=null) {
			group.act(et);
		}
	}
	
	int angRot=330;
	public void renderSquareBlock(SpriteBatch batch) {
		// TODO Auto-generated method stub
 
		if (SpinPlay.gameState.equals("run")) {
			
    	
    	if (!rotbool) {
			if (angle >= angRot && angle <= (angRot+10)) {
				if (!changebool) {
					rotbool=true;
					changebool=true;
				}
			}
			if (angle >= (angRot-100) && angle <= (angRot-90)) {
				if (!changebool) {
					rotbool=true;
					changebool=true;
				}
			}
			if (angle >= (angRot-190) && angle <= (angRot-180)) {
				if (!changebool) {
					rotbool=true;
					changebool=true;
				}
			}
			if (angle >= (angRot-280) && angle <= (angRot-270)) {
				if (!changebool) {			
					rotbool=true;
					changebool=true;
				}
			}
		}
    	else if (rotbool) {
    		if (angle > 350 && angle<360) {
				rotbool=false;
			}
    		if (angle > 260 && angle<270) {
				rotbool=false;
			} 
    		if (angle > 170 && angle<180) {
				rotbool=false;
			}
    		if (angle > 80 && angle<90 ) {
				rotbool=false;
			}
		}
    	
    	if (changebool) {
    		changebool=false;
    		rotIndex++;
			if (rotIndex>3) {
				rotIndex=0;
			}		
			ShuffleLogic.resetSquareSymbols("right");			
		}    	
    	if (!constants.ConstantValues.isSpinTutorial && !TapandholdTut.showTut)
    	{
    		MyInputProcessor.isLongPress=false;
    	}
    	
    	if (MyInputProcessor.isLongPress) {
    		if (!constants.ConstantValues.isSpinTutorial) {
    			if (TapandholdTut.showTut) {
    				 angle=angle+angleHaltVal;	     
				}
			}
    		else
	        angle=angle+angleHaltVal;	     
		}
		else
		{
			angle = angle + angleVal;
		}
	

    	//group.
    	if (group!=null) {
    	group.setRotation(-angle);
    	}
    	if (angle>=360) {
    		angle=0;
		}
		}
		//group.act(Gdx.graphics.getDeltaTime());
		if (group!=null) {
        group.draw(batch, 1);
		}
        
	}
	
public static void disposeImage() {
	// TODO Auto-generated method stub
	if (group!=null) {
		group.clear();
		group=null;
	}

}
	
}
