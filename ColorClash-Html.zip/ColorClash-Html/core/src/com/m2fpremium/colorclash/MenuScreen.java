package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import java.util.Random;

import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenManager;
import aurelienribon.tweenengine.primitives.MutableFloat;
import constants.ConstantValues;


public class MenuScreen extends GameState {

	AndroidOnlyInterface gameinterface;


	SpriteBatch batch,batch1;
	Sprite bgSprite,titleSprite,blinkSprite;
	Texture blinkTexture;
	boolean blinkbool=false;

	GameButton button[];
	String btnName="";
	public static boolean button_initializ = false;

	TextureRegion[] playRegn = new TextureRegion[2];
	TextureRegion[] helpRegn = new TextureRegion[2];
	TextureRegion[] aboutRegn = new TextureRegion[2];
	TextureRegion[] musicRegn = new TextureRegion[2];
	TextureRegion[] soundRegn = new TextureRegion[2];

	private float down_X;
	private float down_Y;
	private float up_X;
	private float up_Y;
	private int backval=0;

	TextureRegion[] tapModeRegn = new TextureRegion[2];
	TextureRegion[] endlessRegn = new TextureRegion[2];
	TextureRegion[] spinPlayRegn = new TextureRegion[2];
	TextureRegion[] classicModeRegn = new TextureRegion[2];


	boolean tweenbool=false;
	private final TweenManager tweenManager = new TweenManager();
	private MutableFloat textX = new MutableFloat(0);
	private MutableFloat textY  = new MutableFloat(constants.ConstantValues.CAMERA_HEIGHT);
	private MutableFloat textX1 = new MutableFloat(0);
	private MutableFloat textY1  = new MutableFloat(constants.ConstantValues.CAMERA_HEIGHT);

	int gap = (constants.ConstantValues.CAMERA_HEIGHT) - (constants.ConstantValues.CAMERA_HEIGHT/2 + 50);

	int scaleTime=0;
	int totScaleTime=0;
	int scaleImgNo=0;
	boolean isScaling=false;
	int scaleEnableTime=0;
	Random rand;

	FontObj fontObj;

	public MenuScreen(GameStateManager gsm) {
		super(gsm);

		rand = new Random();
		scaleTime=0;
		totScaleTime=300;
		scaleImgNo=0;
		isScaling=false;
		scaleEnableTime=0;

		fontObj=new FontObj();
		backval=0;
		MyInputProcessor myInputProcessor = new MyInputProcessor();
		InputMultiplexer im = myInputProcessor.returnInput();
		Gdx.input.setInputProcessor(im);

		constants.ConstantValues.classicSteps = PreferenceClass.readClassicTut();
		constants.ConstantValues.taptapSteps = PreferenceClass.readTaptapTut();
		constants.ConstantValues.spinSteps = PreferenceClass.readSpinTut();

		if (constants.ConstantValues.classicSteps >=  constants.ConstantValues.classicTotSteps) {
			constants.ConstantValues.isClassicTutorial=true;
		}
		if (constants.ConstantValues.taptapSteps >=  constants.ConstantValues.taptapTotSteps) {
			constants.ConstantValues.isTapTapTutorial=true;
		}
		if (constants.ConstantValues.spinSteps >=  constants.ConstantValues.spinTotSteps) {
			constants.ConstantValues.isSpinTutorial=true;
		}

		button = new GameButton[8];

		batch = new SpriteBatch();
		bgSprite= new Sprite(MyGdxGame.uiAtlas.findRegion("Menu-bg"));
		bgSprite.setSize(constants.ConstantValues.CAMERA_WIDTH, constants.ConstantValues.CAMERA_HEIGHT);
		//bgSprite.setRegionWidth(ConstantValues.CAMERA_WIDTH);

		blinkTexture = new Texture("ingame/f.png");
		blinkSprite = new Sprite(blinkTexture);

		if(ConstantValues.langCode==2)
			titleSprite = new Sprite(new TextureRegion(new Texture(Gdx.files.internal("ingame/title_IT.png"))));
		else if(ConstantValues.langCode==3)
			titleSprite = new Sprite(new TextureRegion(new Texture(Gdx.files.internal("ingame/title_ES.png"))));
		else
			titleSprite = new Sprite(MyGdxGame.uiAtlas.findRegion("title"));

		titleSprite.setScale(0.7f);
		titleSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2-titleSprite.getWidth()/2, ConstantValues.CAMERA_HEIGHT/3+50);

		batch1 = new SpriteBatch();

		try {

			playRegn[0] = MyGdxGame.uiAtlas.findRegion("play_off");
			playRegn[1] = MyGdxGame.uiAtlas.findRegion("play_on");

			helpRegn[0] = MyGdxGame.uiAtlas.findRegion("help_off");
			helpRegn[1] = MyGdxGame.uiAtlas.findRegion("help_on");
			aboutRegn[0] = MyGdxGame.uiAtlas.findRegion("about_off");
			aboutRegn[1] = MyGdxGame.uiAtlas.findRegion("about_on");
			musicRegn[0] = MyGdxGame.uiAtlas.findRegion("music_off");
			musicRegn[1] = MyGdxGame.uiAtlas.findRegion("music_on");
			soundRegn[0] = MyGdxGame.uiAtlas.findRegion("sound_off");
			soundRegn[1] = MyGdxGame.uiAtlas.findRegion("sound_on");

			if(ConstantValues.langCode==3) {
				tapModeRegn[0] =new TextureRegion(new Texture(Gdx.files.internal("ingame/taptap_ES.png")));
				tapModeRegn[1] =new TextureRegion(new Texture(Gdx.files.internal("ingame/taptap_ES.png")));

				endlessRegn[0] = new TextureRegion(new Texture(Gdx.files.internal("ingame/dash_ES.png")));
				endlessRegn[1] =new TextureRegion(new Texture(Gdx.files.internal("ingame/dash_ES.png")));

				spinPlayRegn[0] = new TextureRegion(new Texture(Gdx.files.internal("ingame/spin_ES.png")));
				spinPlayRegn[1] = new TextureRegion(new Texture(Gdx.files.internal("ingame/spin_ES.png")));

				classicModeRegn[0] = new TextureRegion(new Texture(Gdx.files.internal("ingame/classic_ES.png")));
				classicModeRegn[1] = new TextureRegion(new Texture(Gdx.files.internal("ingame/classic_ES.png")));
			}else if(ConstantValues.langCode==2) {
				tapModeRegn[0] =new TextureRegion(new Texture(Gdx.files.internal("ingame/taptap_IT.png")));
				tapModeRegn[1] =new TextureRegion(new Texture(Gdx.files.internal("ingame/taptap_IT.png")));

				endlessRegn[0] = new TextureRegion(new Texture(Gdx.files.internal("ingame/dash_IT.png")));
				endlessRegn[1] =new TextureRegion(new Texture(Gdx.files.internal("ingame/dash_IT.png")));

				spinPlayRegn[0] = new TextureRegion(new Texture(Gdx.files.internal("ingame/spin_IT.png")));
				spinPlayRegn[1] = new TextureRegion(new Texture(Gdx.files.internal("ingame/spin_IT.png")));

				classicModeRegn[0] = new TextureRegion(new Texture(Gdx.files.internal("ingame/classic_IT.png")));
				classicModeRegn[1] = new TextureRegion(new Texture(Gdx.files.internal("ingame/classic_IT.png")));
			}
			else {
				tapModeRegn[0] = MyGdxGame.uiAtlas.findRegion("taptap");
				tapModeRegn[1] = MyGdxGame.uiAtlas.findRegion("taptap");

				endlessRegn[0] = MyGdxGame.uiAtlas.findRegion("dash");
				endlessRegn[1] = MyGdxGame.uiAtlas.findRegion("dash");

				spinPlayRegn[0] = MyGdxGame.uiAtlas.findRegion("spin");
				spinPlayRegn[1] = MyGdxGame.uiAtlas.findRegion("spin");

				classicModeRegn[0] = MyGdxGame.uiAtlas.findRegion("classic");
				classicModeRegn[1] = MyGdxGame.uiAtlas.findRegion("classic");

			}

		/*	shareRegn[0]= MyGdxGame.psAtlas.findRegion("share_off");
			shareRegn[1]= MyGdxGame.psAtlas.findRegion("share_on");

			likeviewRegn[0]= MyGdxGame.psAtlas.findRegion("like_off");
			likeviewRegn[1]= MyGdxGame.psAtlas.findRegion("like_on");
*/
			loadMenuImages();

			SoundManager.stopAll();
			SoundManager.playModes();

		} catch (Exception e) {
			// TODO: handle exception
		}
		textX = new MutableFloat( (constants.ConstantValues.CAMERA_WIDTH/2 - classicModeRegn[0].getRegionWidth()*0.6f) - gap);
		textX1= new MutableFloat( ( constants.ConstantValues.CAMERA_WIDTH/2 + spinPlayRegn[0].getRegionWidth()*0.6f) + gap);
		textY1= new MutableFloat( (constants.ConstantValues.CAMERA_HEIGHT/4 +tapModeRegn[0].getRegionHeight()*0.1f) - gap);

		Tween.to(textY, 0, 1.0f).target(textY.floatValue() - gap).start(tweenManager);
		Tween.to(textX, 0, 1.0f).target(textX.floatValue() + gap).start(tweenManager);
		Tween.to(textX1, 0, 1.0f).target(textX1.floatValue() - gap).start(tweenManager);
		Tween.to(textY1, 0, 1.0f).target(textY1.floatValue() + gap).start(tweenManager);
		SoundManager.playMenuMusic();
	}



	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public void handleInput() {
		// TODO Auto-generated method stub
		if (button_initializ) {
			for (int i = 0; i < button.length; i++) {

				if (button[i].isClicked() && btnName.equals("")) {

					if (i == 1) {
						SoundManager.stopAll();
						SoundManager.playClick();
						btnName = "help";
						button[1].buttonTouched = true;
					}
					else if (i == 2) {
						SoundManager.stopAll();
						SoundManager.playClick();
						btnName = "about";
						button[2].buttonTouched = true;
					}
					else if (i == 3) {
						btnName = "music";
					//	SoundManager.playClick();
						if (constants.ConstantValues.isMusicEnabled)
						{
							constants.ConstantValues.isMusicEnabled=false;
							PreferenceClass.saveMusicval(1);
						}
						else
						{
							constants.ConstantValues.isMusicEnabled = true;
							PreferenceClass.saveMusicval(0);
						}
						SoundManager.stopAll();
						SoundManager.playMenuMusic();
						button[3].buttonTouched = true;
					}
					else if (i == 4) {
						btnName = "sound";
						//SoundManager.playClick();
						if (constants.ConstantValues.isSoundEnabled)
						{
							constants.ConstantValues.isSoundEnabled=false;
							PreferenceClass.saveSoundval(1);
						}
						else
						{
							constants.ConstantValues.isSoundEnabled = true;
							PreferenceClass.saveSoundval(0);
						}
						button[4].buttonTouched = true;
					}
					else if (i == 7) {
						SoundManager.playClick();
						btnName = "play";
						button[0].buttonTouched = true;
					}
					else if (i == 5) {
						SoundManager.playClick();
						btnName = "dash";
						button[5].buttonTouched = true;
					}
					else if (i == 6) {
						SoundManager.playClick();
						btnName = "spin";
						button[6].buttonTouched = true;
					}
					else if (i == 0) {
						SoundManager.playClick();
						btnName = "taptap";
						button[7].buttonTouched = true;
					}
				
					/*else if (i == 9) {
						SoundManager.playClick();
						btnName = "share";
						button[9].buttonTouched = true;
					}
					else if (i == 10) {
						SoundManager.playClick();
						btnName = "more";
						button[10].buttonTouched = true;
					}*/

				}
			}
		}

		if (MyInput.isDown(0)) {
			down_X = MyInput.Down_x;
			down_Y = constants.ConstantValues.CAMERA_HEIGHT - MyInput.Down_y;
		}
		if (MyInput.isUp(0)) {
			up_X = MyInput.Up_x;
			up_Y = constants.ConstantValues.CAMERA_HEIGHT - MyInput.Up_y;

			handleTheGame();
		}

		if (MyInputProcessor.isKeyDown && (GameStateManager.MENU == constants.ConstantValues.stateNo) && tweenbool)
		{
			backval++;
			MyInputProcessor.isKeyDown=false;
			if (backval >= 2) {
				System.exit(0);
			}
			else
			{
				if(constants.ConstantValues.isAndroidDevice) {
					MyGdxGame.aoi.showToast(LocalizedStrings.backalert);
				}
			}
		}

		MyInputProcessor.isKeyDown=false;


	}


	public void handleTheGame() {
		// TODO Auto-generated method stub
		if (button_initializ) {
			for (int j = 0; j < button.length; j++) {
				button[j].buttonTouched = false;
			}
		}

		if (btnName.equals("help")) {
			ChangeScreen(GameStateManager.HELP);
		/*	for (int i = 0; i < Levels.totlevels; i++) {
				Levels.directions[i] = Levels.mode1directions[i];
				Levels.features[i] = Levels.mode1features[i];
			}
			Levels.mode="mixup";
			Levels.classicNo=1;
			ChangeScreen(GameStateManager.GAMEPLAY);*/
		}
		else if (btnName.equals("about")) {
			ChangeScreen(GameStateManager.ABOUT);
		}

		else if (btnName.equals("play")) {
			for (int i = 0; i < Levels.totlevels; i++) {
				Levels.directions[i] = Levels.mode1directions[i];
				Levels.features[i] = Levels.mode1features[i];
			}
			Levels.classicNo=0;
			Levels.mode="mixup";
			ChangeScreen(GameStateManager.GAMEPLAY);
		}
		else if (btnName.equals("dash")) {
			for (int j = 0; j < Levels.totlevels; j++) {
				Levels.directions[j] = Levels.mode1directions[j];
				Levels.features[j] = Levels.mode1features[j];
			}
			Levels.mode="endless";
			ChangeScreen(GameStateManager.ENDLESSPLAY);
		}
		else if (btnName.equals("spin")) {
			for (int j = 0; j < Levels.totlevels; j++) {
				Levels.directions[j] = Levels.mode1directions[j];
				Levels.features[j] = Levels.mode1features[j];
			}
			Levels.mode="spin";
			ChangeScreen(GameStateManager.SPINPLAY);
		}
		else if (btnName.equals("taptap")) {
			for (int j = 0; j < Levels.totlevels; j++) {
				Levels.directions[j] = Levels.mode1directions[j];
				Levels.features[j] = Levels.mode1features[j];
			}
			Levels.mode="dash";
			ChangeScreen(GameStateManager.DASHPLAY);
		}
	

		btnName="";
	}

	@Override
	public void render() {
		// TODO Auto-generated method stub

		tweenManager.update(Gdx.graphics.getDeltaTime());
		if (!tweenbool) {
			if (tweenManager.containsTarget(textX)) {
			}
			else
			{
				tweenbool=true;
				scaleEnableTime = (Math.abs(rand.nextInt()%5)+1)*70;
			}
		}
		cam.update();
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		batch.setProjectionMatrix(cam.combined);
		batch.begin();
		bgSprite.draw(batch);
		titleSprite.draw(batch);


   if (button_initializ) {

			if (button[1].buttonTouched) {
				button[1].render(batch, helpRegn[1]);
			} else {
				button[1].render(batch, helpRegn[0]);
			}

			if (button[2].buttonTouched) {
				button[2].render(batch, aboutRegn[1]);
			} else {
				button[2].render(batch, aboutRegn[0]);
			}


			if (constants.ConstantValues.isMusicEnabled)
			{
				button[3].render(batch, musicRegn[1]);
			}else{
				button[3].render(batch, musicRegn[0]);
			}


			if (constants.ConstantValues.isSoundEnabled) {
				button[4].render(batch, soundRegn[1] );
			} else {
				button[4].render(batch, soundRegn[0]);
			}

			/*if (button[8].buttonTouched) {
				button[8].render(batch, likeviewRegn[1]);
			} else {
				button[8].render(batch, likeviewRegn[0]);
			}
			if (button[9].buttonTouched) {
				button[9].render(batch, shareRegn[1]);
			} else {
				button[9].render(batch, shareRegn[0]);
			}*/
		

			if (isScaling && scaleTime<totScaleTime) {
				scaleTime++;
				if (scaleTime >= totScaleTime) {
					scaleTime=0;
					isScaling=false;
					scaleEnableTime = (Math.abs(rand.nextInt()%5)+1)*100;
				}
				if (scaleTime%30==0) {
					blinkbool = !blinkbool;
				}
			}


			if (isScaling) {
				switch (scaleImgNo) {
					case 0:
						blinkSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2 -  tapModeRegn[0].getRegionWidth()*1.19f ,textY.floatValue()-tapModeRegn[0].getRegionHeight()*0.5715f);
						break;
					case 1:
						blinkSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2 /*+  tapModeRegn[0].getRegionWidth()*0.15f*/ ,textY.floatValue()-tapModeRegn[0].getRegionHeight()*0.5715f);
						break;
					case 2:
						blinkSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2 -  tapModeRegn[0].getRegionWidth()*1.19f ,textY1.floatValue()-tapModeRegn[0].getRegionHeight()*0.5715f);
						break;
					case 3:
						blinkSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2 /*+  tapModeRegn[0].getRegionWidth()*1.15f*/ ,textY1.floatValue()-tapModeRegn[0].getRegionHeight()*0.5715f);
						break;
					default:
						break;
				}
				if (blinkbool) {
					blinkSprite.draw(batch);
				}
			}

			if (button[0].buttonTouched) {
				button[0].render(batch, tapModeRegn[1], constants.ConstantValues.CAMERA_WIDTH/2 -  tapModeRegn[0].getRegionWidth()*0.6f ,textY.floatValue()/*,0*/);
			} else {
				button[0].render(batch, tapModeRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 -  tapModeRegn[0].getRegionWidth()*0.6f ,textY.floatValue()/*,0*/);
			}

			if (button[5].buttonTouched) {
				button[5].render(batch, endlessRegn[1], constants.ConstantValues.CAMERA_WIDTH/2 + endlessRegn[0].getRegionWidth() *0.6f,textY1.floatValue()/*,0*/);
			} else {
				button[5].render(batch, endlessRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 + endlessRegn[0].getRegionWidth() *0.6f,textY1.floatValue()/*,0*/);
			}
			if (button[6].buttonTouched) {
				button[6].render(batch, spinPlayRegn[1],textX1.floatValue(), constants.ConstantValues.CAMERA_HEIGHT/2 + 50/*,0*/);
			} else {
				button[6].render(batch, spinPlayRegn[0],textX1.floatValue(), constants.ConstantValues.CAMERA_HEIGHT/2 +50/*,0*/);
			}

			if (button[7].buttonTouched) {
				button[7].render(batch, classicModeRegn[1],textX.floatValue(), constants.ConstantValues.CAMERA_HEIGHT/4 + tapModeRegn[0].getRegionHeight()*0.1f/*,0*/);
			} else {
				button[7].render(batch, classicModeRegn[0],textX.floatValue(), constants.ConstantValues.CAMERA_HEIGHT/4 + tapModeRegn[0].getRegionHeight()*0.1f/*,0*/);
			}

			if (MyGdxGame.demobool) {
				MyGdxGame.demoSprite.draw(batch);
			}
		}
		if (tweenbool) {
			//working
			MyGdxGame.getMediumFont().draw(batch,""+PreferenceClass.readBestScoreTap(),textX.floatValue()-25,textY.floatValue()-tapModeRegn[0].getRegionHeight()/3 +5);
			MyGdxGame.getMediumFont().draw(batch,""+PreferenceClass.readBestScoreSpin(),textX1.floatValue()-25,textY.floatValue()-tapModeRegn[0].getRegionHeight()/3 +5);
			MyGdxGame.getMediumFont().draw(batch,""+PreferenceClass.readBestScoreClassic(),textX.floatValue()-25,textY1.floatValue()-tapModeRegn[0].getRegionHeight()/3 +5);
			MyGdxGame.getMediumFont().draw(batch,""+PreferenceClass.readBestScoreDash(),textX1.floatValue()-25,textY1.floatValue()-tapModeRegn[0].getRegionHeight()/3 +5);
		}

		MyGdxGame.getMediumFont().draw(batch, LocalizedStrings.widthText,
				ConstantValues.CAMERA_WIDTH/2 - fontObj.getStringWidth(MyGdxGame.getMediumFont(), LocalizedStrings.widthText),ConstantValues.CAMERA_HEIGHT/2);



		batch.end();
	}

	@Override
	public void update(float f) {
		// TODO Auto-generated method stub
		if (button_initializ) {
			for (int i = 0; i < button.length; i++) {
				button[i].update(Gdx.graphics.getDeltaTime());
			}
		}

		if (scaleEnableTime > 0) {
			scaleEnableTime--;
			if (scaleEnableTime==0) {
				scaleImgNo = Math.abs(rand.nextInt()%4);
				isScaling=true;
				scaleTime=0;
			}
		}

		handleInput();
	}

	private void loadMenuImages() {
		// TODO Auto-generated method stub
		int adjx=30;

		  float gap = constants.ConstantValues.CAMERA_WIDTH- helpRegn[0].getRegionWidth()*1.5f;
		  float gap1 = helpRegn[0].getRegionWidth()*2.1f ;
		  float gap2 = 140;//(gap-gap1)/3;

	/*	if (constants.ConstantValues.CAMERA_WIDTH > 800) {
			gap1 = gap1+90;
			gap2 = 130;
		}*/

		button[1] = new GameButton(helpRegn[0],gap1+(gap2),    helpRegn[0].getRegionHeight()/1.5f, MyGdxGame.bgCamera,1);
		button[2] = new GameButton(aboutRegn[0], gap1+(2*gap2),    helpRegn[0].getRegionHeight()/1.5f, MyGdxGame.bgCamera,2);
		button[3] = new GameButton(musicRegn[1],-1200,   helpRegn[0].getRegionHeight()/1.5f, MyGdxGame.bgCamera,2);
		button[4] = new GameButton(soundRegn[1], gap1 ,   helpRegn[0].getRegionHeight()/1.5f,MyGdxGame.bgCamera,2);
/*
		button[8] = new GameButton(likeviewRegn[0], gap1+(4*gap2),    helpRegn[0].getRegionHeight()/1.5f, cam,2);
		button[9] = new GameButton(shareRegn[1],gap1+(5*gap2),   helpRegn[0].getRegionHeight()/1.5f, cam,2);*/


		button[0] = new GameButton(tapModeRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 -  tapModeRegn[0].getRegionWidth()*0.6f  , constants.ConstantValues.CAMERA_HEIGHT,MyGdxGame.bgCamera,new ScaleAnimation(0.5f, 0.5f, 0.9f, 0.9f, 0.0f, 0.0f));
		button[5] = new GameButton(endlessRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 + endlessRegn[0].getRegionWidth() *0.6f ,  constants.ConstantValues.CAMERA_HEIGHT/4 -tapModeRegn[0].getRegionHeight()*0.3f,MyGdxGame.bgCamera,new ScaleAnimation(0.5f, 0.5f, 0.9f, 0.9f, 0.0f, 0.0f));
		button[6] = new GameButton(spinPlayRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 + spinPlayRegn[0].getRegionWidth()*0.6f ,  constants.ConstantValues.CAMERA_HEIGHT/2 -tapModeRegn[0].getRegionHeight()*0.25f,MyGdxGame.bgCamera,new ScaleAnimation(0.5f, 0.5f, 0.9f, 0.9f, 0.0f, 0.0f));
		button[7] = new GameButton(classicModeRegn[0], constants.ConstantValues.CAMERA_WIDTH/2 - classicModeRegn[0].getRegionWidth()*0.6f ,  constants.ConstantValues.CAMERA_HEIGHT/4 -tapModeRegn[0].getRegionHeight()*0.3f,MyGdxGame.bgCamera,new ScaleAnimation(0.5f, 0.5f, 0.9f, 0.9f, 0.0f, 0.0f));

		MyInput.Down_x = 0;
		MyInput.Down_y = 0;
		MyInput.Up_x = 0;
		MyInput.Up_y = 0;
		MyInput.Drag_x = 0;
		MyInput.Drag_y = 0;

		button_initializ = true;
	}
}
