package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

/**
 * Created by nirosha on 13-05-2016.
 */
public class AnimationClass {

     public static Animation getAnimation(String filename,int FRAME_COLS,int FRAME_ROWS,float fd) {
         Animation anim;
        Texture animTexture = new Texture(Gdx.files.internal(filename));
        TextureRegion[][] textureRegions = TextureRegion.split(animTexture, animTexture.getWidth() / FRAME_COLS, animTexture.getHeight() / FRAME_ROWS);
        TextureRegion[] explosionFrames = new TextureRegion[FRAME_COLS * FRAME_ROWS];
        int index = 0;
        for (int i = 0; i < FRAME_ROWS; i++) {
            for (int j = 0; j < FRAME_COLS; j++) {
                explosionFrames[index++] = textureRegions[i][j];
            }
        }
         anim = new Animation(fd,explosionFrames);
        return anim;
    }

    public static TextureRegion getCurrentTextureRegion(Animation anim,float et,boolean loop)
    {
        TextureRegion animReg = anim.getKeyFrame(et,true);
        return animReg;
    }

}
