package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;

import constants.ConstantValues;

public class Logo extends GameState {
    private int count;
    TextureAtlas loading_atlas;
    public Texture logoImg, demo;
    private AssetManager manager;
	private static boolean managerBool_update;
	private boolean textureLoaded;
	private SpriteBatch batch;
	public static boolean gameRunState = false;
	Sprite logoSprite;

    public Logo(GameStateManager gsm) {
        super(gsm);
        
        batch = new SpriteBatch();
         
        count = 0;

         manager = MyGdxGame.res.manager;
         textureLoaded = false;
         
         logoImg = new Texture("ingame/logo.png");
         logoSprite=new Sprite(logoImg);
                 
         MyGdxGame.loadAssets();
         MyGdxGame.loadTexturePacker();
         MyGdxGame.loadSounds();
    }

    public void handleInput() {
    }

    public void update(float dt) {
    }

    public void render() {
        Gdx.gl.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.setProjectionMatrix(cam.combined);
        batch.begin();
        logoSprite.draw(batch);
        logoSprite.setPosition(ConstantValues.CAMERA_WIDTH/2-logoSprite.getWidth()/2, ConstantValues.CAMERA_HEIGHT/2-logoSprite.getHeight()/2);
       // logoSprite.setSize(ConstantValues.CAMERA_WIDTH, ConstantValues.CAMERA_HEIGHT);

     //   batch.draw(logoImg, 0, 0,  Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
    	if (MyGdxGame.demobool) {
			MyGdxGame.demoSprite.draw(batch);
		}
        batch.end();
        
         cam.update();
         count++;
        if (manager.update() && !managerBool_update) {
           //System.out.println("Manager updated");
           MyGdxGame.res.GetAssets();
           MyGdxGame.res.ClearList();
           managerBool_update = true;
           textureLoaded = true;     
        }
        if (textureLoaded && count >= 100) {
			count = 0;
			ChangeScreen(GameStateManager.SPLASH);
		}
    }

    public void dispose() 
    {
    	
    }
}
