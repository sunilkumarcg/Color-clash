package com.m2fpremium.colorclash;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public abstract class GameState {
    public static boolean backPress;
    protected OrthographicCamera cam;
    protected OrthographicCamera cam1;
    protected OrthographicCamera cam2;
    protected com.m2fpremium.colorclash.MyGdxGame game;
    protected GameStateManager gsm;
    protected SpriteBatch sb;

    public abstract void dispose();

    public abstract void handleInput();

    public abstract void render();

    public abstract void update(float f);

    protected GameState(GameStateManager gsm) {
        this.gsm = gsm;
        this.game = gsm.game();
        this.sb = this.game.getSpriteBatch();
        this.cam = this.game.getCamera();
        this.cam1 = this.game.getRotCamera();
        this.cam2 = this.game.getbgCamera();
        
      //  Gdx.input.setCatchBackKey(true);
       // Gdx.input.setInputProcessor(new MyInputProcessor());
    }

    public void ChangeScreen(int i) {
        backPress = false;
        this.gsm.setState(i);
    }

    public void handleInput(float dt) {
    	
    }
}
