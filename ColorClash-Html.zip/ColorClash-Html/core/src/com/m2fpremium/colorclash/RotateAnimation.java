package com.m2fpremium.colorclash;

public class RotateAnimation {
    private boolean Update;
    public float Xangle; 
    private boolean moveLeft=false;
    
    private int leftAngleLimit= 30; 
    private int rightAngleLimit= -30; 

    private float xSpeed=0.25f;
    
    public boolean isUpdate() {
        return this.Update;
    }

    public void setUpdate(boolean update) {
        this.Update = update;
    }

    public RotateAnimation(int angle) {
      this.Xangle = angle;
  
      if (angle > 0) {
    	  this.moveLeft=false;
      }
      else 
      {
    	  this.moveLeft=true;
      }
      
      Initilize(angle);
    }

    public void Initilize(int x) {
 
        setRotX(x);
    }

    public void update() {
    	RotX();
    }

    public void update(boolean b) {
        if (b) {
        	RotX();
        }
    }

    private void setRotX(int x) {
		// TODO Auto-generated method stub
    	Xangle=x;
	}
    
    private void RotX() {
		// TODO Auto-generated method stub
    	if (moveLeft) {
    		Xangle=Xangle+0.5f;
		}
    	else
    	{
    		Xangle=Xangle-0.5f;
    	}
    	
    	 if (Xangle > leftAngleLimit ) {
       	  this.moveLeft=false;
         }
         else if(Xangle < rightAngleLimit)
         {
       	  this.moveLeft=true;
         }
	}

}
