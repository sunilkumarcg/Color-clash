package com.m2fpremium.colorclash;

public class GameHandler {

	GamePause gamePause;
	GameOver gameOver;
	
	public GameHandler() {
		// TODO Auto-generated constructor stub
		gamePause=new GamePause();
		gameOver = new GameOver();
	}
	
	
	
}
