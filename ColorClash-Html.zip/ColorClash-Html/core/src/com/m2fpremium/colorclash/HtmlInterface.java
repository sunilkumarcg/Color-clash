package com.m2fpremium.colorclash;

/**
 * Created by Nirosha on 16-08-2018.
 */

public interface HtmlInterface {

    public void scrollWindow();

    public void showAds();

    public void updateGame();
}
