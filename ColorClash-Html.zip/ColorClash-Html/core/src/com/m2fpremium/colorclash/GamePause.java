package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import constants.ConstantValues;

public class GamePause {
	
    static Sprite bgSprite;    
    GameButton button[];
   public static String btnName="";
    public static boolean button_initializ = false;
        
    TextureRegion[] resumeRegn = new TextureRegion[2];
    TextureRegion[] restartRegn = new TextureRegion[2];
    TextureRegion[] menuRegn = new TextureRegion[2];
    TextureAtlas uiAtlas;
    
    FontObj fontObj;
    
    
    
    public GamePause() {
		// TODO Auto-generated method stub
    	ConstantValues.isBSuspend=true;
    	fontObj=new FontObj();
    	
    	button = new GameButton[3];
    	uiAtlas = new TextureAtlas("packers/ui/ui.pack");
    	try {
    		resumeRegn[0] = uiAtlas.findRegion("resume_off");
        	resumeRegn[1] = uiAtlas.findRegion("resume_on");
        	restartRegn[0] = uiAtlas.findRegion("restart_off");
        	restartRegn[1] = uiAtlas.findRegion("restart_on");
        	menuRegn[0] = uiAtlas.findRegion("menu_off");
        	menuRegn[1] = uiAtlas.findRegion("menu_on");
        	loadGamePause();
		} catch (Exception e) {
			// TODO: handle exception
		}
    	
	}
    
    private void loadGamePause() {
		// TODO Auto-generated method stub
    	bgSprite = new Sprite(MyGdxGame.uiAtlas.findRegion("Menu-bg"));
    	bgSprite.setPosition(0,0);
    	bgSprite.setSize(ConstantValues.CAMERA_WIDTH, ConstantValues.CAMERA_HEIGHT);
    	
    	button[0] = new GameButton(resumeRegn[0], ConstantValues.CAMERA_WIDTH/2,  ConstantValues.CAMERA_HEIGHT/2, MyGdxGame.bgCamera,0);
    	button[1] = new GameButton(restartRegn[0], ConstantValues.CAMERA_WIDTH/4,  ConstantValues.CAMERA_HEIGHT/2, MyGdxGame.bgCamera,1);
    	button[2] = new GameButton(menuRegn[0], ConstantValues.CAMERA_WIDTH/2+ConstantValues.CAMERA_WIDTH/4,  ConstantValues.CAMERA_HEIGHT/2, MyGdxGame.bgCamera,2);
    	
    	MyInput.Down_x = 0;
		MyInput.Down_y = 0;
		MyInput.Up_x = 0;
		MyInput.Up_y = 0;
		MyInput.Drag_x = 0;
		MyInput.Drag_y = 0;
    	
		button_initializ = true;
	}
    
    
    public void drawGamePause(SpriteBatch sb) {
		// TODO Auto-generated method stub
    	  
    	bgSprite.draw(sb);
    	/*MyGdxGame.getMediumFont().draw(sb, LocalizedStrings.gamepause,
    			ConstantValues.CAMERA_WIDTH/2 - fontObj.getStringWidth(MyGdxGame.getMediumFont(), LocalizedStrings.gamepause), ConstantValues.CAMERA_HEIGHT - 50);
*/
    	
    	if (button_initializ) {
			if (button[0].buttonTouched) {
				button[0].render(sb, resumeRegn[1]);			
			} else {
				button[0].render(sb, resumeRegn[0]);		
			}
			
			if (button[1].buttonTouched) {
				button[1].render(sb, restartRegn[1]);
			} else {
				button[1].render(sb, restartRegn[0]);
			}
			
			if (button[2].buttonTouched) {
				button[2].render(sb, menuRegn[1]);
			} else {
				button[2].render(sb, menuRegn[0]);
			}
    	}
	}
    
    
    public void handleInput() {
		// TODO Auto-generated method stub
    	if (button_initializ) {
    		//System.out.println("hannn");
			for (int i = 0; i < button.length; i++) {

				if (button[i].isClicked() && btnName.equals("")) {
					//System.out.println("g"+i);
					if (i == 0) {
						SoundManager.playClick();
						btnName = "resume";
						button[0].buttonTouched = true;					
					}
					if (i == 1) {
						SoundManager.playClick();
						btnName = "retry";
						button[1].buttonTouched = true;
					}
					if (i == 2) {
						SoundManager.playClick();
						btnName = "menu";
						button[2].buttonTouched = true;
					}			
				}
			}
		}

	}
    
    public void updateUI() {
		// TODO Auto-generated method stub
    	if (button_initializ) {
			for (int i = 0; i < button.length; i++) {
				button[i].update(Gdx.graphics.getDeltaTime());
			}
		}
	}

}
