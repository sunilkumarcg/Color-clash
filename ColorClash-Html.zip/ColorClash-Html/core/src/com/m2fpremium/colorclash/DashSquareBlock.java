package com.m2fpremium.colorclash;

import java.util.Random;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;


public class DashSquareBlock {

   	public static Sprite[] emoSymbols= new Sprite[4];
   	public static Sprite[] backTiles= new Sprite[4];
	public static Rectangle[] collisionRectangles= new Rectangle[4];
	public static int[] symSequence=new int[4];
	
	public static int[][] rotIndexes= {{0,1,2,3},{1,2,3,0},{2,3,0,1},{3,0,1,2}};
	int rotVal=0;
	public static int rotIndex=0;
	public static int transSpeed=10;
	
	public static float destX=0;
	public static float destY=0;
	public static String movedir="down";
	
	public static int[] emoSymbolNos= new int[4];

	static int[] rotations={0,90,180,270};

	public static float xypos[][] = new float[4][4];

	public DashSquareBlock() {
		// TODO Auto-generated constructor stub

		
		for (int i = 0; i < backTiles.length; i++) {
			backTiles[i]= new Sprite( MyGdxGame.gameAtlas.findRegion("tile"));
			collisionRectangles[i] = new Rectangle(backTiles[i].getX(), backTiles[i].getY(), backTiles[i].getWidth()/2, backTiles[i].getHeight()/2);
		}
		
		for (int i = 0; i < symSequence.length; i++) {
			symSequence[i] = i;
		}
		ShuffleLogic.shuffleArray(symSequence);
		//ShuffleLogic.resetIndexes(); 
		
		
		for (int i = 0; i < emoSymbols.length; i++) {
			emoSymbols[i]= new Sprite( MyGdxGame.gameAtlas.findRegion(DashPlay.getPattern()+(symSequence[i]+1)+"rect"));
		}
		for (int i = 0; i < emoSymbolNos.length; i++) {
			emoSymbolNos[i] = 0;
		}
		Random rnd = new Random();
		int rndNo=Math.abs(rnd.nextInt()%4);
		if (Levels.features[Levels.levelNo].equals("zigzaghide")) {
			emoSymbolNos[rndNo] =1;
		}
	
	}
	
	public void resetGame() {
		// TODO Auto-generated method stub
		
		resetTilesPosition();
		
	}

	public static void resetTilesPosition() {
		// TODO Auto-generated method stub
		float width= (int) (constants.ConstantValues.CAMERA_WIDTH/7.27);

		xypos[0][0] = (width/2)+10+ constants.ConstantValues.xAdjPos;
		xypos[0][1] = emoSymbols[0].getHeight()/4;
		xypos[3][0] = constants.ConstantValues.CAMERA_WIDTH-(width+xypos[0][0]);//xypos[2][0]+width1;
		xypos[3][1] = xypos[0][1];
		
		int gap =(int) (( xypos[3][0]-xypos[0][0])/3);

		xypos[1][0] = xypos[0][0]+gap;
		xypos[1][1] = xypos[0][1];
		xypos[2][0] = xypos[1][0]+gap;
		xypos[2][1] = xypos[0][1];
		
	
		for (int i = 0; i < emoSymbols.length; i++) {
			int no = rotIndexes[rotIndex][i];
			backTiles[i].setPosition(xypos[no][0], xypos[no][1]);
			if (emoSymbols[i].getScaleX() > 1.0f) {
        		emoSymbols[i].setScale(1.0f);
    		}
			emoSymbols[i].setPosition(xypos[no][0], xypos[no][1]);
			collisionRectangles[i].setPosition(xypos[i][0],xypos[i][1]);
		}
	}
	

	
	
	public void moveSquareBlock() {
		// TODO Auto-generated method stub

		for (int i = 0; i <emoSymbols.length; i++) {
			if (emoSymbols[i].getScaleX() > 1.3f) {
        		emoSymbols[i].setScale(1.0f);
    		}
			else if (emoSymbols[i].getScaleX() >= 1.15f) {
        		emoSymbols[i].setScale(emoSymbols[i].getScaleX()+0.025f);
    		}
        	backTiles[i].setPosition(emoSymbols[i].getX(), emoSymbols[i].getY());
        	
		}
	
	}
	
	public void renderSquareBlock(SpriteBatch batch) {
		// TODO Auto-generated method stub
        for (int i = 0; i <emoSymbols.length; i++) {
        	//backTiles[i].draw(batch);
        	if (emoSymbolNos[i] == 0) {
                emoSymbols[i].draw(batch);       
			}
		}
	}
	
	
	
}
