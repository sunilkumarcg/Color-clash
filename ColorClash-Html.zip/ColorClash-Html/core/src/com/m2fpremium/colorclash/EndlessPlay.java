package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import java.util.Random;

import constants.ConstantValues;

public class EndlessPlay extends GameState {


	SpriteBatch batch;
    Sprite bgSprite,titleSprite,bgSprite2,bgSprite3,saveMeTimerSprite;
	public static int savemeTime=0;
    
    public static String gameState="static";
   
    GameButton button[];
    String btnName="";
    public static boolean button_initializ = false;    
    
    TextureRegion[] pauseRegn = new TextureRegion[2];
 
    TextureAtlas uiAtlas,atlas;
    
    private float down_X;
   	private float down_Y;
   	private float up_X;
   	private float up_Y;
   	

   	private float sprAlpha=0f;
   	private int sprTime=1;
	private String sprAlphaDir="inc";
	
	public static int rotDir=0;
	
	
	public static float up_y,mid_y,down_y;
	static String direction="down";
   	
	public static boolean startRot=false;

	
   	FontObj fontObj;
   	EndlessSmiley smiley;
    GamePause gamePause;
    GameOver gameOver;
    Score scoreobj;
    Levels levels;
    EndlessSquareBlock squareBlock;
    Sprite scoreSprite;
    
    static Random random;
    SpeedLines speedLines;
    ParticleEffectsClass pec;
    BestscoreImg bestscoreImg;
	TapandholdTut tutClass;

    
	public EndlessPlay(GameStateManager gsm) {
		super(gsm);
		constants.ConstantValues.isAdsLoaded = false;
		MyGdxGame.resetInputControls();
		if (constants.ConstantValues.classicCnt <2 && !constants.ConstantValues.isClassicTut) {
			constants.ConstantValues.isClassicTutorial=false;
			constants.ConstantValues.isClassicLeft=false;
			constants.ConstantValues.isClassicRight=false;
			System.out.println("cnt"+ constants.ConstantValues.classicCnt);
		}
		random = new Random();
		changePattern();
		
		fontObj=new FontObj();
		smiley = new EndlessSmiley();
		gamePause =  new GamePause();
		gameOver = new GameOver();
		scoreobj=new Score();
		levels=new Levels();
		squareBlock = new EndlessSquareBlock();
		speedLines = new SpeedLines();
		pec = new ParticleEffectsClass();
		bestscoreImg = new BestscoreImg();
		tutClass = new TapandholdTut();
		tutClass.showTut=false;
		constants.ConstantValues.isClassicLeft=false;
		constants.ConstantValues.isClassicRight=false;
		constants.ConstantValues.classicSteps=0;
		
		MyInputProcessor myInputProcessor = new MyInputProcessor();
	    InputMultiplexer im = myInputProcessor.returnInput();
		Gdx.input.setInputProcessor(im);  		
		
		button = new GameButton[1];
        
		batch = new SpriteBatch();
		//bgSprite= new Sprite( MyGdxGame.gameAtlas.findRegion("gamebg"));
		if (Math.abs(random.nextInt()%2)==0) {
			bgSprite2= new Sprite( MyGdxGame.gameAtlas.findRegion("gamebg1"));
			bgSprite3= new Sprite( MyGdxGame.gameAtlas.findRegion("glow"));
		}
		else
		{
		bgSprite2= new Sprite( MyGdxGame.gameAtlas.findRegion("gamebg2"));
		bgSprite3= new Sprite( MyGdxGame.gameAtlas.findRegion("glow2"));
		}
		saveMeTimerSprite = new Sprite( MyGdxGame.psAtlas.findRegion("1"));
		scoreSprite= new Sprite( MyGdxGame.uiAtlas.findRegion("ingamescore"));
		scoreSprite.setPosition(scoreSprite.getWidth()/2+ constants.ConstantValues.xAdjPos, constants.ConstantValues.CAMERA_HEIGHT-scoreSprite.getHeight()*1.6f);
		//bgSprite2.setSize(ConstantValues.CAMERA_WIDTH, ConstantValues.CAMERA_HEIGHT);
		//bgSprite3.setSize(ConstantValues.CAMERA_WIDTH, ConstantValues.CAMERA_HEIGHT);
		try {
			pauseRegn[0] = MyGdxGame.uiAtlas.findRegion("pause_off");
			pauseRegn[1] = MyGdxGame.uiAtlas.findRegion("pasue_on");
			loadMenuImages();
		} catch (Exception e) {
			// TODO: handle exception
		}
		savemeTime=0;

		initVariables();
		squareBlock.resetGame();
		SoundManager.stopAll();
		SoundManager.playBgMusic();
	}
	  
	private void changePattern() {
		// TODO Auto-generated method stub
		
		int no = Math.abs(random.nextInt()%3)+1;
		constants.ConstantValues.setno =no; //no;
		//ConstantValues.pattern='r';
		
		int no1 = Math.abs(random.nextInt()%12);
		if (no1<2) {
			constants.ConstantValues.pattern='r';
		}
		else if (no1<5) {
			constants.ConstantValues.pattern='o';
		}
		else if (no1<8) {
			constants.ConstantValues.pattern='d';
		}
		else {
			constants.ConstantValues.pattern='c';
		}
		
	}
	
	public static String getPattern()
	{
		
		return ""+ constants.ConstantValues.pattern+"s"+ constants.ConstantValues.setno+"c";
	}
	
	private void initVariables() {
		// TODO Auto-generated method stub
		  gameState="run";
		  down_y=squareBlock.roundSprite.getHeight()/4;
		  up_y = ConstantValues.CAMERA_HEIGHT- squareBlock.roundSprite.getHeight()*1.2f;
		  mid_y = ConstantValues.CAMERA_HEIGHT/2- squareBlock.roundSprite.getHeight()/2;
		  direction="down";
		  squareBlock.rotIndex=0;
		  rotDir=-1;
		  startRot=true;
		  Levels.swapbool=false;
		  EndlessSmiley.smileyTime =50;
		  /*if (Levels.mode.equals("dash"))		  
		  {
		  Levels.minSpeed=8;
		  }
		  else 
		  {
			  Levels.minSpeed=5;
		  }
*/		  
		  sprAlpha=0f;
		  sprTime=1;
		  sprAlphaDir="inc";
		  
		  int[][] rotin = {{0,1,2,3},{1,2,3,0},{2,3,0,1},{3,0,1,2}};
		  for (int i = 0; i < rotin.length; i++) {
			  for (int j = 0; j < rotin.length; j++) {
				  squareBlock.rotIndexes[i][j] = rotin[i][j] ; 
			  }
		  }
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleInput() {
		// TODO Auto-generated method stub
		if (button_initializ) {
			for (int i = 0; i < button.length; i++) {
				button[i].update(Gdx.graphics.getDeltaTime());
			}
		}
		if (gameState.equals("run")) {
			if (button_initializ) {
				if (button[0].isClicked() && btnName.equals("")) {
						btnName = "pause";
						System.out.println("pause");
						button[0].buttonTouched = true;							
				}	
			}
			if (!Levels.transState.equals("move") && btnName.equals("")) {
			
				if (constants.ConstantValues.isClassicTutorial) {
				if (MyInputProcessor.isTapLeft || MyInputProcessor.isSwipeLeft) {
					if (startRot) {
						startRot=false;
						rotDir=0;
					}
				}
				if (MyInputProcessor.isTapRight || MyInputProcessor.isSwipeRight) {
					if (startRot) {
						startRot=false;
						rotDir=-1;
					}
				}
				}
				else if(constants.ConstantValues.classicCnt==0)
				{
					if (constants.ConstantValues.classicSteps==0 && tutClass.showTut) {
						if (MyInputProcessor.isTapLeft && Levels.emoCnt==1) {
							if (startRot) {
								startRot=false;
								rotDir=0;
								if (!constants.ConstantValues.isClassicLeft) {
									constants.ConstantValues.isClassicLeft=true;
									tutClass.showTut=false;
									constants.ConstantValues.classicSteps++;
								}
							}
						}			
					}
					else if (constants.ConstantValues.classicSteps==1 && tutClass.showTut) {
						if (MyInputProcessor.isTapRight && Levels.emoCnt==2) {
							if (startRot) {
								startRot=false;
								rotDir=-1;
								if (!constants.ConstantValues.isClassicRight) {
									constants.ConstantValues.isClassicRight=true;
									tutClass.showTut=false;
									constants.ConstantValues.classicSteps++;
								}
							}
						}
					}
					
				}
				else
				{
					if (constants.ConstantValues.classicSteps==0 && tutClass.showTut) {
						
						if (MyInputProcessor.isSwipeLeft ) {
							if (startRot) {
								startRot=false;
								rotDir=0;
								if (!constants.ConstantValues.isClassicLeft) {
									constants.ConstantValues.isClassicLeft=true;
									tutClass.showTut=false;
									constants.ConstantValues.classicSteps++;
								}
							}
						}
					}
					else if (constants.ConstantValues.classicSteps==1 && tutClass.showTut) {
						if ( MyInputProcessor.isSwipeRight) {
							if (startRot) {
								startRot=false;
								rotDir=-1;
								if (!constants.ConstantValues.isClassicRight) {
									constants.ConstantValues.isClassicRight=true;
									tutClass.showTut=false;
									constants.ConstantValues.classicSteps++;
									constants.ConstantValues.isClassicTutorial=true;
									constants.ConstantValues.classicCnt=2;
									PreferenceClass.saveClassicTut(2);
								}
							}
						}
					}
				}
				if (MyInputProcessor.isSwipeDown) {
					int index=0;
					float num=-1;
					if (!constants.ConstantValues.isClassicTutorial && (!constants.ConstantValues.isClassicLeft || !constants.ConstantValues.isClassicRight)) {
						
					}
					else if(constants.ConstantValues.isClassicTutorial || (tutClass.showTut && constants.ConstantValues.classicSteps==2))
					{
						constants.ConstantValues.classicSteps++;
						tutClass.showTut=false;
						if (!constants.ConstantValues.isClassicTutorial)
						{
						constants.ConstantValues.isClassicTutorial=true;
						constants.ConstantValues.isClassicTut=true;
						constants.ConstantValues.classicCnt=1;
						PreferenceClass.saveClassicTut(1);
						}
					if (EndlessSmiley.smileyDash==-1) {
						
					
					for (int i = 0; i < EndlessSmiley.SmileySprites.length; i++) {
						if (EndlessSmiley.smileyVisible[i]==1 )
						{
							 if(num==-1 || num >= EndlessSmiley.SmileySprites[i].getY()) 
								{
									num=EndlessSmiley.SmileySprites[i].getY();
									index=i;
								}	
						}
						if (i == EndlessSmiley.SmileySprites.length-1) {
							EndlessSmiley.smileyDash=index;
					
								SoundManager.playFall();
						
							//System.out.println("swipedownNo:"+EndlessSmiley.smileyDash);
						}
					}
					}
					}
				
				}
			}
			
		}
		else if (gameState.equals("pause")) {
			SoundManager.stopAll();
			gamePause.handleInput();
			}
		else if (gameState.equals("gameover")) {
			SoundManager.stopAll();
				gameOver.handleInput();
		}
		if (MyInput.isDown(0)) {
			down_X = MyInput.Down_x;
			down_Y = constants.ConstantValues.CAMERA_HEIGHT - MyInput.Down_y;
		}
		if (MyInput.isUp(0)) {
			up_X = MyInput.Up_x;
			up_Y = constants.ConstantValues.CAMERA_HEIGHT - MyInput.Up_y;
			
			handleTheGame();
		}
		MyInputProcessor.isSwipeDown=false;
		MyInputProcessor.isTapLeft=false;
		MyInputProcessor.isTapRight=false;
		MyInputProcessor.isSwipeLeft=false;
		MyInputProcessor.isSwipeRight=false;
		changeState();

	}
	
	public void changeState() {
		// TODO Auto-generated method stub 
		if (MyInputProcessor.isKeyDown && gameState.equals("run")) 
		{
			SoundManager.stopAll();
				gameState="pause";
				MyInputProcessor.isKeyDown=false;
		}
		else if (MyInputProcessor.isKeyDown && gameState.equals("pause"))
		{			
			SoundManager.stopAll();
			SoundManager.playBgMusic();
				gameState="run";
				MyInputProcessor.isKeyDown=false;
		}	
		else if (MyInputProcessor.isKeyDown && gameState.equals("gameover"))
		{			
			ChangeScreen(GameStateManager.MENU);
			MyInputProcessor.isKeyDown=false;
		}	
	}
	
	public void handleTheGame() {
		// TODO Auto-generated method stub
		if (button_initializ) {
			for (int j = 0; j < button.length; j++) {
				button[j].buttonTouched = false;
			}
		}
		if (btnName.equals("pause") && !gameState.contains("over")&& !gameState.contains("save")) {
			gameState="pause";
		}
		if (gamePause.button_initializ) {
			for (int j = 0; j < gamePause.button.length; j++) {
				gamePause.button[j].buttonTouched = false;
			}
		}	
		if (gameOver.button_initializ) {
			for (int j = 0; j < gameOver.button.length; j++) {
				gameOver.button[j].buttonTouched = false;
			}
		}
		//System.out.println(gamePause.btnName);
		if (gamePause.btnName.equals("resume")) {
			gameState = "run";
			SoundManager.playBgMusic();

		}
		if (gameOver.btnName.equals("retry") || gamePause.btnName.equals("retry")) {
			gameState = "run";
			ChangeScreen(gsm.RESET);
		}
		if (gamePause.btnName.equals("menu") || gameOver.btnName.equals("menu")) {
			ChangeScreen(GameStateManager.MENU);
		}
	
		gamePause.btnName = "";		
		gameOver.btnName="";
		btnName="";
	}

	@Override
	public void render() {
		// TODO Auto-generated method stub

    	cam.update(true);
    	Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
	    	
    	batch.setProjectionMatrix(cam.combined); 
        batch.begin();
       // bgSprite.setColor(85/255, 42/255, 1, 1);
      //  bgSprite.draw(batch);
        bgSprite2.setAlpha(sprAlpha);
        bgSprite2.draw(batch);
        bgSprite3.setAlpha(sprAlpha);
        bgSprite3.draw(batch);
        // squareBlock.renderSquareBlock(batch);
        scoreSprite.draw(batch);
        speedLines.renderSpeedLines(batch);
        bestscoreImg.render(batch);
        smiley.renderSmileys(batch);
        squareBlock.renderSquareBlock(batch);
        pec.renderParticle(batch);
        if (!constants.ConstantValues.isClassicTutorial) {
	    	if (!constants.ConstantValues.isClassicLeft && constants.ConstantValues.classicCnt==0) {
				tutClass.tutSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2-300, constants.ConstantValues.CAMERA_HEIGHT/2- constants.ConstantValues.CAMERA_HEIGHT/4);
				tutClass.render(batch);
			}
	    	else if (!constants.ConstantValues.isClassicRight &&  constants.ConstantValues.classicCnt==0) {
	    		tutClass.tutSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2+200, constants.ConstantValues.CAMERA_HEIGHT/2- constants.ConstantValues.CAMERA_HEIGHT/4);
				tutClass.render(batch);
			}
	    	else if (constants.ConstantValues.isClassicLeft && constants.ConstantValues.isClassicRight) {
	    		tutClass.render(batch);
			}
    	}
    	
    	tutClass.render(batch);
    	
    	MyGdxGame.getMediumFont().draw(batch,": "+scoreobj.score,scoreSprite.getX()+scoreSprite.getWidth(),scoreSprite.getY()+scoreSprite.getHeight()/2);
    	 if (button_initializ) { 
  			
  			if (button[0].buttonTouched) {
  				button[0].render(batch, pauseRegn[1]);
  			} else {
  				button[0].render(batch, pauseRegn[0]);
  			}
     	 }
    	if (gameState.equals("pause")) {
            
         	gamePause.drawGamePause(batch);
 		}
         else if (gameState.equals("gameover")) { 
           
         	gameOver.drawGameOver(batch);     	
 		}   
    	if (MyGdxGame.demobool) {
			MyGdxGame.demoSprite.draw(batch);
		}
		if (gameState.equals("savemetimer"))
		{
			if(savemeTime==0) {
				saveMeTimerSprite=null;
				saveMeTimerSprite = new Sprite( MyGdxGame.psAtlas.findRegion("3"));
				saveMeTimerSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2-saveMeTimerSprite.getWidth(), constants.ConstantValues.CAMERA_HEIGHT/2-saveMeTimerSprite.getHeight()/2);
				saveMeTimerSprite.setScale(1.0f);
			}
			else if(savemeTime==50)
			{
				saveMeTimerSprite=null;
				saveMeTimerSprite = new Sprite( MyGdxGame.psAtlas.findRegion("2"));
				saveMeTimerSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2-saveMeTimerSprite.getWidth(), constants.ConstantValues.CAMERA_HEIGHT/2-saveMeTimerSprite.getHeight()/2);
				saveMeTimerSprite.setScale(1.0f);
			}
			else if(savemeTime==100)
			{

				saveMeTimerSprite=null;
				saveMeTimerSprite = new Sprite( MyGdxGame.psAtlas.findRegion("1"));
				saveMeTimerSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2-saveMeTimerSprite.getWidth(), constants.ConstantValues.CAMERA_HEIGHT/2-saveMeTimerSprite.getHeight()/2);
				saveMeTimerSprite.setScale(1.0f);
			}
			else
			{
				saveMeTimerSprite.setScale(saveMeTimerSprite.getScaleX()+0.03f);
			}
			savemeTime++;
			saveMeTimerSprite.draw(batch);
			if(savemeTime >=150)
			{
				gameState="run";
			}

		}
		if(MyGdxGame.htmlInterface!=null)
			MyGdxGame.htmlInterface.updateGame();

		batch.end();
	}

	@Override
	public void update(float f) {
		// TODO Auto-generated method stub

		if (f > 0.1f) f = 0.1f;

		//elapsedTime += f;
		handleInput();
		pec.update(f);
		tutClass.update(f);
		bestscoreImg.update(f);
		if (gameState.equals("run")) {		
			sprTime++;
			if (sprTime%20 == 0) {
				sprTime=1;
				switch (sprAlphaDir) {
				case "inc":
					sprAlpha=sprAlpha+0.01f;
					if (sprAlpha >= 0.6f) {
						//sprAlpha=1;
						sprAlphaDir="dec";
					}
					break;

				case "dec": 
					sprAlpha=sprAlpha-0.01f;
					if (sprAlpha <=0.01f) {
						sprAlphaDir="inc";
					}
					break;
				default:
					break;
				}
				
			}
			
				squareBlock.moveSquareBlock();
				if (constants.ConstantValues.isClassicTutorial) {
			    	smiley.moveSmileys();
				}
				else 
				{
					if (!tutClass.showTut) {
						smiley.moveSmileys();
					}
				}
		    	speedLines.updateSpeedLines(f);
			levels.updateLevel();
		}
		else if (gameState.equals("pause")) 
		{
				gamePause.updateUI();
		}
		else if (gameState.equals("gameover")) {
				gameOver.updateUI();
		}

		
	}

	private void loadMenuImages() {
			// TODO Auto-generated method stub
	  
    	button[0] = new GameButton(pauseRegn[0], constants.ConstantValues.CAMERA_WIDTH-pauseRegn[0].getRegionWidth()*0.8f- constants.ConstantValues.xAdjPos,  constants.ConstantValues.CAMERA_HEIGHT-pauseRegn[0].getRegionHeight()*0.7f,MyGdxGame.bgCamera,0);
	  
	    	MyInput.Down_x = 0;
			MyInput.Down_y = 0;
			MyInput.Up_x = 0;
			MyInput.Up_y = 0;
			MyInput.Drag_x = 0;
			MyInput.Drag_y = 0;
	    	
			button_initializ = true;
	}
	
	
	
}
