package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Align;

import constants.ConstantValues;

public class GameOver {
	
    static Sprite bgSprite,scoreSprite,bestscoreSprite;    
    public GameButton button[];
    public String btnName="";
    public boolean button_initializ = false;
        
    TextureRegion[] restartRegn = new TextureRegion[2];
    TextureRegion[] menuRegn = new TextureRegion[2];


	FontObj fontObj;
    static Pixmap pixmap;
	static Texture pixmapTexture;
    
    public GameOver() {
		// TODO Auto-generated method stub
    	ConstantValues.isBSuspend=true;
    	fontObj=new FontObj();
    	button = new GameButton[2];
    	try {

        	restartRegn[0] = MyGdxGame.uiAtlas.findRegion("restart_off");
        	restartRegn[1] = MyGdxGame.uiAtlas.findRegion("restart_on");
        	menuRegn[0] = MyGdxGame.uiAtlas.findRegion("menu_off");
        	menuRegn[1] = MyGdxGame.uiAtlas.findRegion("menu_on");

        	loadGameOver();
		} catch (Exception e) {
			// TODO: handle exception
		}
    	
    	scoreSprite = new Sprite(MyGdxGame.uiAtlas.findRegion("score"));
    	bestscoreSprite = new Sprite(MyGdxGame.uiAtlas.findRegion("bestscore"));
    	
    	pixmap = new Pixmap(256,256,Pixmap.Format.RGBA8888);
		pixmap.setColor((float)(12/255), (float)(156/255), (float)(169/255), 1);

		pixmapTexture = new Texture(pixmap);
    	
	}
    
    public static void drawRect(){
		
		      pixmap.fillRectangle(0, 0, ConstantValues.CAMERA_WIDTH, ConstantValues.CAMERA_HEIGHT);
		      pixmap.setColor(ParticleEffectsClass.colors[ParticleEffectsClass.rndno][0],ParticleEffectsClass.colors[ParticleEffectsClass.rndno][1],ParticleEffectsClass.colors[ParticleEffectsClass.rndno][2],1);

		      pixmapTexture.draw(pixmap, 0, 0);
		      pixmapTexture.bind();
		}
    
    private void loadGameOver() {
		// TODO Auto-generated method stub
		
    	bgSprite = new Sprite(MyGdxGame.uiAtlas.findRegion("Menu-bg"));
		bgSprite.setPosition(0, 0);
    	
    	button[0] = new GameButton(menuRegn[0], ConstantValues.CAMERA_WIDTH/2 -menuRegn[0].getRegionWidth()*0.7f ,  ConstantValues.CAMERA_HEIGHT*0.38f, MyGdxGame.bgCamera,0);
    	button[1] = new GameButton(restartRegn[0], ConstantValues.CAMERA_WIDTH/2 + restartRegn[0].getRegionWidth()*0.7f,  ConstantValues.CAMERA_HEIGHT*0.38f, MyGdxGame.bgCamera,1);
	
    	MyInput.Down_x = 0;
		MyInput.Down_y = 0;
		MyInput.Up_x = 0;
		MyInput.Up_y = 0;
		MyInput.Drag_x = 0;
		MyInput.Drag_y = 0;
    	
		button_initializ = true;

	} 
    
  
   public static boolean isGameOver=false;
    
    public void drawGameOver(SpriteBatch sb) {
		// TODO Auto-generated method stub
    	
    	//bgSprite.draw(sb);
    	drawRect();
    	sb.draw(pixmapTexture,0, 0,ConstantValues.CAMERA_WIDTH,ConstantValues.CAMERA_HEIGHT);
    /*	MyGdxGame.getMediumFont().draw(sb, LocalizedStrings.gameover,
    			ConstantValues.CAMERA_WIDTH/2 - fontObj.getStringWidth(MyGdxGame.getMediumFont(), LocalizedStrings.gameover), ConstantValues.CAMERA_HEIGHT - 50);
*/
    	scoreSprite.setPosition(ConstantValues.CAMERA_WIDTH/2 - scoreSprite.getWidth()/2, ConstantValues.CAMERA_HEIGHT/2+150);
    	bestscoreSprite.setPosition(ConstantValues.CAMERA_WIDTH/2 - bestscoreSprite.getWidth()/2,  ConstantValues.CAMERA_HEIGHT/2);
    	scoreSprite.draw(sb);
    	bestscoreSprite.draw(sb);
    	
    	if (button_initializ) {
			if (button[0].buttonTouched) {
				button[0].render(sb, menuRegn[1]);			
			} else {
				button[0].render(sb, menuRegn[0]);		
			}
			
			if (button[1].buttonTouched) {
				button[1].render(sb, restartRegn[1]);
			} else {
				button[1].render(sb, restartRegn[0]);
			}

			
    	}


    	MyGdxGame.getLargeFont().draw(sb,/*LocalizedStrings.score+*/""+Score.score, scoreSprite.getX() - scoreSprite.getWidth()/4 ,
    			scoreSprite.getY() + scoreSprite.getHeight()/2 + 11, 500, Align.center, true);
    	switch (Levels.mode) {
		case "mixup":
			MyGdxGame.getLargeFont().draw(sb,/*LocalizedStrings.bestScore+*/""+Score.bestscoreclassic, bestscoreSprite.getX() - bestscoreSprite.getWidth()/4,
					bestscoreSprite.getY() + bestscoreSprite.getHeight()/2 +11, 500, Align.center, true);
			break;
		case "spin":
			MyGdxGame.getLargeFont().draw(sb,/*LocalizedStrings.bestScore+*/""+Score.bestscorespin, bestscoreSprite.getX() - bestscoreSprite.getWidth()/4,
					bestscoreSprite.getY() + bestscoreSprite.getHeight()/2 +11, 500, Align.center, true);
			break;
		case "dash":
			MyGdxGame.getLargeFont().draw(sb,/*LocalizedStrings.bestScore+*/""+Score.bestscoretap, bestscoreSprite.getX() - bestscoreSprite.getWidth()/4,
					bestscoreSprite.getY() + bestscoreSprite.getHeight()/2 +11, 500, Align.center, true);
			break;
		case "endless":
			MyGdxGame.getLargeFont().draw(sb,/*LocalizedStrings.bestScore+*/""+Score.bestscoredash, bestscoreSprite.getX() - bestscoreSprite.getWidth()/4,
					bestscoreSprite.getY() + bestscoreSprite.getHeight()/2 +11, 500, Align.center, true);
			break;
		default:
			break;
		}

		
	}
    
    
    public void handleInput() {
		// TODO Auto-generated method stub
    	if (button_initializ) {
			for (int i = 0; i < button.length; i++) {
				if (button[i].isClicked() && btnName.equals("")) {
					if (i == 0) {
						SoundManager.playClick();
						btnName = "menu";
						button[0].buttonTouched = true;					
					}
					if (i == 1) {
						SoundManager.playClick();
						btnName = "retry";
						button[1].buttonTouched = true;
					}
					
				}
			}
		}
	}
    
    public void updateUI() {
		// TODO Auto-generated method stub
    	if (button_initializ) {
			for (int i = 0; i < button.length; i++) {
				button[i].update(Gdx.graphics.getDeltaTime());
			}
		}
	}


}
