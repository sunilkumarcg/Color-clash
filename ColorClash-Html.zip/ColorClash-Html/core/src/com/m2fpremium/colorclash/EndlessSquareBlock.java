package com.m2fpremium.colorclash;

import java.util.Random;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;


public class EndlessSquareBlock {

   	public static Sprite roundSprite;
   	public static Sprite[] emoSymbols= new Sprite[4];
   	public static Sprite[] backTiles= new Sprite[4];
	public static Rectangle[] collisionRectangles= new Rectangle[4];
	public static int[] symSequence=new int[4];
	
	public static int[][] rotIndexes= {{0,1,2,3},{1,2,3,0},{2,3,0,1},{3,0,1,2}};
	int rotVal=0;
	public static int rotIndex=0;
	public static int transSpeed=10;
	
	public static float destX=0;
	public static float destY=0;
	public static String movedir="down";
	
	public static int[] emoSymbolNos= new int[4];

	static int[] rotations={0,90,180,270};

	public static float xypos[][] = new float[4][4];

	public EndlessSquareBlock() {
		// TODO Auto-generated constructor stub

		roundSprite = new Sprite( MyGdxGame.gameAtlas.findRegion("tile"));
		
		for (int i = 0; i < backTiles.length; i++) {
			backTiles[i]= new Sprite( MyGdxGame.gameAtlas.findRegion("tile"));
			collisionRectangles[i] = new Rectangle(backTiles[i].getX(), backTiles[i].getY(), backTiles[i].getWidth()/2, backTiles[i].getHeight()/2);
		}
		
		for (int i = 0; i < symSequence.length; i++) {
			symSequence[i] = i;
		}
		ShuffleLogic.shuffleArray(symSequence);
		//ShuffleLogic.resetIndexes(); 
		
		
		for (int i = 0; i < emoSymbols.length; i++) {
			emoSymbols[i]= new Sprite( MyGdxGame.gameAtlas.findRegion(EndlessPlay.getPattern()+(symSequence[i]+1)+"rect"));
		}
		for (int i = 0; i < emoSymbolNos.length; i++) {
			emoSymbolNos[i] = 0;
		}
		Random rnd = new Random();
		int rndNo=Math.abs(rnd.nextInt()%4);
		if (Levels.features[Levels.levelNo].equals("zigzaghide")) {
			emoSymbolNos[rndNo] =1;
		}
	
	}
	
	public void resetGame() {
		// TODO Auto-generated method stub
		roundSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2-roundSprite.getWidth()/2, EndlessPlay.down_y);
		if (Levels.features[Levels.levelNo].equals("midright")) 
		{
			roundSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH-roundSprite.getWidth()*1.5f, EndlessPlay.mid_y);
		}
		else if (Levels.features[Levels.levelNo].equals("downleft")) {		
				roundSprite.setPosition(0+roundSprite.getWidth()/2, EndlessPlay.down_y);
		}
		resetTilesPosition();
		
	}

	public static void resetTilesPosition() {
		// TODO Auto-generated method stub
		float adjx=8;
		float adjy=8;
		
		xypos[0][0] = roundSprite.getX()-emoSymbols[0].getWidth()/4 + adjx;
		xypos[0][1] = roundSprite.getY()+emoSymbols[0].getHeight()-adjy;
		xypos[1][0] = roundSprite.getX()+emoSymbols[0].getWidth()/2+emoSymbols[0].getWidth()/4 + adjx*3;
		xypos[1][1] = roundSprite.getY()+emoSymbols[0].getHeight()-adjy;
		xypos[2][0] = roundSprite.getX()+emoSymbols[0].getWidth()/2+emoSymbols[0].getWidth()/4+adjx*3;
		xypos[2][1] = roundSprite.getY()-emoSymbols[0].getHeight()/4 +adjy/3;
		xypos[3][0] = roundSprite.getX()-emoSymbols[0].getWidth()/4+adjx;
		xypos[3][1] = roundSprite.getY()-emoSymbols[0].getHeight()/4 +adjy/3;		
	
		for (int i = 0; i < emoSymbols.length; i++) {
			int no = rotIndexes[rotIndex][i];
			backTiles[i].setPosition(xypos[no][0], xypos[no][1]);
			if (emoSymbols[i].getScaleX() > 1.0f) {
        		emoSymbols[i].setScale(1.0f);
    		}
			emoSymbols[i].setPosition(xypos[no][0], xypos[no][1]);
			collisionRectangles[i].setPosition(xypos[i][0],xypos[i][1]);
		}
	}
	

	private void changeBackTilePosition(int a,int rotation) {
		// TODO Auto-generated method stub
		
		int b =0;
		float directionX=0;
		float directionY =0;
		int targetno = rotIndexes[rotIndex][a];
		
		switch (rotation) {
		case -1:
			if (targetno < 3) {
				b= targetno+1;
			}
			else
			{
				b=0;
			}
			break;

		default:
			if (targetno > 0 ) {
				b= targetno-1;
			}
			else
			{
				b=3;
			}
			break;
		}
		
	//	System.out.println("target"+targetno);

		if (rotVal<=90) {
			if (rotation==-1) {
				backTiles[a].setRotation(backTiles[a].getRotation()-rotVal);
			}
			else
			{
				backTiles[a].setRotation(backTiles[a].getRotation()+rotVal);
			}
		}
		if(rotation<0)
		{
			directionX = xypos[b][0]-emoSymbols[a].getX();
			directionY = xypos[b][1]-emoSymbols[a].getY();
		}
		else
		{
			directionX = emoSymbols[a].getX()-xypos[b][0];
			directionY = emoSymbols[a].getY()-xypos[b][1] ;
		}
		
		float arrow_angle = (float) Math.toDegrees(Math.atan2(
				directionY, directionX));

		double dirRadians = Math.toRadians(arrow_angle);

		float cX = (float) Math.cos(dirRadians);
		float cY = (float) Math.sin(dirRadians);
		
		switch (rotation) 
		{
			case -1:
					switch (b) {
					case 1:
						emoSymbols[a].setPosition(emoSymbols[a].getX()
								+ cX * 14, emoSymbols[a].getY() + cY * 14);
						break;
					case 2:
						emoSymbols[a].setPosition(emoSymbols[a].getX()
								, emoSymbols[a].getY() + cY * 14);
						break;
					case 3:
						emoSymbols[a].setPosition(emoSymbols[a].getX()
								+ cX * 14, emoSymbols[a].getY() );
						break;
					default:
						emoSymbols[a].setPosition(emoSymbols[a].getX()
								, emoSymbols[a].getY()  + cY * 14);
						break;
					}
				break;

			default:
				switch (b) {
				case 1:
					emoSymbols[a].setPosition(emoSymbols[a].getX()
							/*+ cX * 14*/, emoSymbols[a].getY() - cY * 14);
					break;
				case 2:
					emoSymbols[a].setPosition(emoSymbols[a].getX()- cX * 14
							, emoSymbols[a].getY() /*+ cY * 14*/);
					break;
				case 3:
					emoSymbols[a].setPosition(emoSymbols[a].getX()
						/*	+ cX * 14*/, emoSymbols[a].getY() - cY * 14);
					break;
				default:
					emoSymbols[a].setPosition(emoSymbols[a].getX()- cX * 14
							, emoSymbols[a].getY()  /*+ cY * 14*/);
					break;
				}
				break;
		}
		
		if (a==emoSymbols.length-1 && rotVal==90) {
			EndlessPlay.startRot=true;
			if (rotation==-1) {
				rotIndex++;
				if (rotIndex>3) {
					rotIndex=0;
				}
				ShuffleLogic.resetEndlessSquareSymbols("right");
			}
			else
			{
				rotIndex--;
				if (rotIndex<0) {
					rotIndex=3;
				}
				ShuffleLogic.resetEndlessSquareSymbols("left");
			}
			
			rotVal=0;
			for (int i = 0; i < emoSymbols.length; i++) {
				int no = rotIndexes[rotIndex][i];
				backTiles[i].setRotation(-rotations[no]);
				emoSymbols[i].setPosition(xypos[no][0], xypos[no][1]); 
			}
			
		}
	}
	
	
	public void moveSquareBlock() {
		// TODO Auto-generated method stub

        if (!EndlessPlay.startRot) {
    		rotVal=rotVal+30;
        }
		for (int i = 0; i <emoSymbols.length; i++) {
        	
        	if (emoSymbols[i].getScaleX() > 1.3f) {
        		emoSymbols[i].setScale(1.0f);
    		}
			else if (emoSymbols[i].getScaleX() >= 1.15f) {
        		emoSymbols[i].setScale(emoSymbols[i].getScaleX()+0.025f);
    		}
        	if (!EndlessPlay.startRot ) {
                changeBackTilePosition(i,EndlessPlay.rotDir);
			}
        	backTiles[i].setPosition(emoSymbols[i].getX(), emoSymbols[i].getY());
        	
		}
	
	}
	
	public void renderSquareBlock(SpriteBatch batch) {
		// TODO Auto-generated method stub
        roundSprite.draw(batch);
        for (int i = 0; i <emoSymbols.length; i++) {
        	//backTiles[i].draw(batch);
        	if (emoSymbolNos[i] == 0) {
                emoSymbols[i].draw(batch);       
			}
		}
	}
	
	public void startTransition() {
		// TODO Auto-generated method stub
		float roundX = constants.ConstantValues.CAMERA_WIDTH/2-roundSprite.getWidth()/2;
		
		if (Levels.transState.equals("move")) {
			switch (movedir) {
			case "up":
				if (roundSprite.getY() <= destY) {
					roundSprite.setPosition(roundX, roundSprite.getY()+transSpeed);
					resetTilesPosition();
				}
				else
				{
					switch (Levels.blockPlace) {
					case "up":
						roundSprite.setPosition(roundX, EndlessPlay.up_y);
						break;
					case "down":
						roundSprite.setPosition(roundX, EndlessPlay.down_y);
						if (Levels.features[Levels.levelNo].equals("downleft")) 
						{
							roundSprite.setPosition(0+roundSprite.getWidth()/2, EndlessPlay.down_y);
						}
						break;
					case "mid":
						roundSprite.setPosition(roundX, EndlessPlay.mid_y);
						if (Levels.features[Levels.levelNo].equals("midright")) 
						{
							roundSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH-roundSprite.getWidth()*1.5f, EndlessPlay.mid_y);
						}
						break;
					default:
						break;
					}
					resetTilesPosition();
					Levels.emoCnt=0;
					Levels.emoCollisionCnt=0;
					Levels.transState="none";
					for (int i = 0; i < emoSymbolNos.length; i++) {
						emoSymbolNos[i] = 0;
					}
					Random rnd = new Random();
					int rndNo=Math.abs(rnd.nextInt()%4);
					if (Levels.features[Levels.levelNo].equals("zigzaghide")) {
						emoSymbolNos[rndNo] =1;
					}
				}
				break;
				
			case "down":
				if (roundSprite.getY() >= destY) {
					roundSprite.setPosition(roundX, roundSprite.getY()-transSpeed);
					resetTilesPosition();
				}
				else
				{
					switch (Levels.blockPlace) {
					case "up":
						roundSprite.setPosition(roundX, EndlessPlay.up_y);
						break;
					case "down":
						roundSprite.setPosition(roundX, EndlessPlay.down_y);
						if (Levels.features[Levels.levelNo].equals("downleft")) 
						{
							roundSprite.setPosition(0+roundSprite.getWidth()/2, EndlessPlay.down_y);
						}
						break;
					case "mid":
						roundSprite.setPosition(roundX, EndlessPlay.mid_y);
						if (Levels.features[Levels.levelNo].equals("midright")) {
							roundSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH-roundSprite.getWidth()*1.5f, EndlessPlay.mid_y);
							}
						break;
					default:
						break;
					}		
					resetTilesPosition();
					Levels.emoCnt=0;
					Levels.emoCollisionCnt=0;
					Levels.transState="none";
					for (int i = 0; i < emoSymbolNos.length; i++) {
						emoSymbolNos[i] = 0;
					}
					Random rnd = new Random();
					int rndNo=Math.abs(rnd.nextInt()%4);
					if (Levels.features[Levels.levelNo].equals("zigzaghide")) {
						emoSymbolNos[rndNo] =1;
					}
				}
				break;
				
			default:
				break;
			}
		}
	}
	
	
	
}
