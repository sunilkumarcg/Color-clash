package com.m2fpremium.colorclash;

import java.util.ArrayList;
import java.util.HashMap;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;

public class loadResources {

	private HashMap<String, Texture> textures;
	private HashMap<String, Music> music;
	private HashMap<String, Sound> sounds;
	private HashMap<String, TextureAtlas> Atlas;
	
	public  AssetManager manager;
	
//	private TextureAtlas levelAtlas;
	
	private ArrayList<String> TexturePathArrayList;
	private ArrayList<String> TextureKeyArrayList;
	
	private ArrayList<String> TexturePackerArrayList;
	private ArrayList<String> TexturePackerKeyArrayList;
	
	private ArrayList<String> SoundPathArrayList;
	private ArrayList<String> SoundKeyArrayList;
	
	private ArrayList<String> MusicPathArrayList;
	private ArrayList<String> MusicKeyArrayList;
	 public loadResources() {
		textures=new HashMap<String, Texture>();
		music = new HashMap<String, Music>();
		sounds = new HashMap<String, Sound>();
		Atlas = new HashMap<String, TextureAtlas>();
		TexturePathArrayList=new ArrayList<String>();
		TextureKeyArrayList=new ArrayList<String>();
		TexturePackerArrayList=new ArrayList<String>();
		TexturePackerKeyArrayList=new ArrayList<String>();
		SoundPathArrayList=new ArrayList<String>();
		SoundKeyArrayList=new ArrayList<String>();
		MusicPathArrayList=new ArrayList<String>();
		MusicKeyArrayList=new ArrayList<String>();
		manager=new AssetManager();
	}
	
	 public void GetAssets() 
	 {
			getTextureFromManager();
			gettexturepackerfrommanger();
			getMusicFromManager();
			GetSoundFromManager();
	 }
	 
	public void loadTexture(String path,String key)
	{
		manager.load(path, Texture.class);
		TexturePathArrayList.add(path);
		TextureKeyArrayList.add(key);
		
		
	}
	
	
	private void getTextureFromManager() {
		
		for (int i = 0; i < TexturePathArrayList.size(); i++) {
			
			textures.put(TextureKeyArrayList.get(i), manager.get(TexturePathArrayList.get(i), Texture.class));
		}
		
	}
	public Texture getTexture(String key)
	{
		textures.get(key).setFilter(TextureFilter.Linear, TextureFilter.Linear);
		return textures.get(key);
	}
	
	public void disposeTexures(String key) {
		Texture tex=textures.get(key);
		if (tex!=null) {
			tex.dispose();
		}
	}
	public void loadMusic(String path) {
		int slashIndex = path.lastIndexOf('/');
		String key;
		if(slashIndex == -1) {
			key = path.substring(0, path.lastIndexOf('.'));
		}
		else {
			key = path.substring(slashIndex + 1, path.lastIndexOf('.'));
		}
		loadMusic(path, key);
	}
	public void loadMusic(String path, String key) 
	{
		manager.load(path,Music.class);
		MusicPathArrayList.add(path);
		MusicKeyArrayList.add(key);
	}
	
	public void loadTexturePacker(String path, String key) 
	{
		manager.load(path, TextureAtlas.class);
		TexturePackerArrayList.add(path);
		TexturePackerKeyArrayList.add(key);
	}
	
	public TextureAtlas getTexturePacker(String key)
	{
		return Atlas.get(key);
	}
	
	
	private void  gettexturepackerfrommanger() {
		 for (int i = 0; i < TexturePackerArrayList.size(); i++) {
				
        	 Atlas.put(TexturePackerKeyArrayList.get(i), manager.get(TexturePackerArrayList.get(i), TextureAtlas.class));
		}
	}
	
	
	private void getMusicFromManager() {
         for (int i = 0; i < MusicPathArrayList.size(); i++) {
			
        	 music.put(MusicKeyArrayList.get(i), manager.get(MusicPathArrayList.get(i), Music.class));
		}
	}
	public Music getMusic(String key) {
		return music.get(key);
	}
	public void removeMusic(String key) {
		Music m = music.get(key);
		if(m != null) {
			music.remove(key);
			m.dispose();
		}
	}
	
	/*******/
	/* SFX */
	/*******/
	
	public void loadSound(String path) {
		int slashIndex = path.lastIndexOf('/');
		String key;
		if(slashIndex == -1) {
			key = path.substring(0, path.lastIndexOf('.'));
		}
		else {
			key = path.substring(slashIndex + 1, path.lastIndexOf('.'));
		}
		loadSound(path, key);
	}
	public void loadSound(String path, String key) {
		
		manager.load(path,Sound.class);
		SoundPathArrayList.add(path);
		SoundKeyArrayList.add(key);
		
		
		
	}
	
	private void GetSoundFromManager() {
		 for (int i = 0; i < SoundPathArrayList.size(); i++) {
				
			 sounds.put(SoundKeyArrayList.get(i), manager.get(SoundPathArrayList.get(i), Sound.class));
		}
	}
	public Sound getSound(String key) {
		return sounds.get(key);
	}
	public void removeSound(String key) {
		Sound sound = sounds.get(key);
		if(sound != null) {
			sounds.remove(key);
			sound.dispose();
		}
	}

	public void ClearList() {
		TextureKeyArrayList.clear();
		TextureKeyArrayList.clear();
		MusicKeyArrayList.clear();
		MusicPathArrayList.clear();
		SoundKeyArrayList.clear();
		SoundPathArrayList.clear();
		TexturePackerArrayList.clear();
		TexturePackerKeyArrayList.clear();
		
	}
}
