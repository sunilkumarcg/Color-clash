package com.m2fpremium.colorclash;

import com.m2fpremium.colorclash.Levels;
import com.m2fpremium.colorclash.SoundManager;
import com.m2fpremium.colorclash.GameState;
import com.m2fpremium.colorclash.GameStateManager;

public class ResetScreen extends GameState{

	public ResetScreen(GameStateManager gsm) {
		super(gsm);
		// TODO Auto-generated constructor stub
		SoundManager.sndNo=1;
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleInput() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(float f) {
		// TODO Auto-generated method stub
		if (Levels.mode.equals("spin")) {
			ChangeScreen(GameStateManager.SPINPLAY);
		}
		else if (Levels.mode.equals("endless")) {
			ChangeScreen(GameStateManager.ENDLESSPLAY);
		}
		else if (Levels.mode.equals("dash")) {
			ChangeScreen(GameStateManager.DASHPLAY);
		}
		else
		ChangeScreen(GameStateManager.GAMEPLAY);

	}

}
