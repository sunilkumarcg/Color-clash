package com.m2fpremium.colorclash;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;

public class FontObj {
	
	public void font() {
		// TODO Auto-generated method stub

	}

	public static float getStringWidth(BitmapFont mfont,String str) {
		// TODO Auto-generated method stub
    	GlyphLayout layout = new GlyphLayout(); //dont do this every frame! Store it as member
    	layout.setText(mfont,str);
    	float width = layout.width;// contains the width of the current set text
		return width/2; 
	}
	public static float getStringHeight(BitmapFont mfont,String str) {
		// TODO Auto-generated method stub
    	GlyphLayout layout = new GlyphLayout(); //dont do this every frame! Store it as member
    	layout.setText(mfont,str);
    	float height = layout.height;// contains the width of the current set text
		return height/2; 
	}
}
