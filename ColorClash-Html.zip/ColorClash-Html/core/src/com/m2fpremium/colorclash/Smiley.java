package com.m2fpremium.colorclash;

import java.util.ArrayList;
import java.util.Random;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class Smiley {
	
	public static Sprite[] SmileySprites= new Sprite[10];
	public static Sprite[] SmileyBlurSprites= new Sprite[10];
	
	public static int[] smileyVisible = new int[SmileySprites.length];
	public static String[] smileyDir = new String[SmileySprites.length];
	static int[] SmileyIconNos= new int[SmileySprites.length];
	
	Rectangle[] smileyRectangles = new Rectangle[SmileySprites.length];
	
	int[] smileyNo = new int[constants.ConstantValues.totColors];
	public static int smileyTime=0;
	public static int fixedSmileyTime=0;
	public static int smileySpeed=6,smileySpeed1=0;
	public static int smileyDash=-1;
	public static int smileyInd = 0;
	public static int smileyGameOverNo = 0;
	public static int smileyGameOverPartNo = 0;
	public static boolean savemebool=false;

	public static ArrayList<Integer> dashno = new ArrayList<>();

	Random ran;
	
	public Smiley() {
		// TODO Auto-generated constructor stub
		ran = new Random();
		smileyGameOverNo=0;
		smileyGameOverPartNo=0;
		savemebool=false;

		for (int i = 0; i < smileyNo.length; i++) {
			smileyNo[i] = i;
		}
		for (int i = 0; i < smileyVisible.length; i++) {
			smileyVisible[i] = 0;
			smileyDir[i]="down";
			SmileyIconNos[i]=0;
		}
		if (dashno.size()>0) {
			for (int i = 0; i < dashno.size(); i++) {
				dashno.remove(i);
			}
		}
		dashno=null;
		dashno = new ArrayList<>();
		smileyDash=-1;
		createSmileys();
	}
	
	private void createSmileys() {
		// TODO Auto-generated method stub
		for (int i = 0; i < SmileySprites.length; i++) {
			ShuffleLogic.shuffleArray(smileyNo);
			SmileyIconNos[i] = smileyNo[0];
			//System.out.println("pattern:"+GamePlay.getPattern());
			SmileySprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(GamePlay.getPattern()+(SmileyIconNos[i]+1)+"rect"));
			SmileyBlurSprites[i] =  new Sprite( MyGdxGame.gameAtlas.findRegion(GamePlay.getBlurPattern()+(SmileyIconNos[i]+1)+"blur"));
			smileyRectangles[i] = new Rectangle(SmileySprites[i].getX(), SmileySprites[i].getY(), SmileySprites[i].getWidth()/2, SmileySprites[i].getHeight());
		}
	}
	public void moveSmileys() {
		// TODO Auto-generated method stub
			/*if (Levels.mode.equals("mixup")) {
				smileyTime =  smileyTime+(smileySpeed/4);
			}
			else
			{
				smileyTime++;
			}*/
		if(smileySpeed < 7) {
			smileyTime = smileyTime + (smileySpeed / (Levels.minSpeed - 2));
		}
		else {
			smileyTime = smileyTime + (smileySpeed / (Levels.minSpeed) );
		}
			checkCollision();

			if (smileyTime > fixedSmileyTime && Levels.transState.equals("none")) {
				showSmiley();
				smileyTime=0;
			}
			for (int i = 0; i < SmileySprites.length; i++) {
				if (smileyVisible[i]!=0  ) {
					smileySpeed1 = smileySpeed;
					if (smileyDash == i) {
						smileySpeed=smileySpeed*3;
					}
					
					switch (smileyDir[i]) {
					case "down":
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed);
						break;
					case "up":
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()+smileySpeed);
						break;
					case "upsideleft":
						if (SmileySprites[i].getX() < SquareBlock.collisionRectangles[0].getX()) {
							SmileySprites[i].setPosition(SmileySprites[i].getX()+(smileySpeed/2 + 0.5f),SmileySprites[i].getY());
						}
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()+smileySpeed);
						break;
					case "downsideleft":
						if (SmileySprites[i].getX() < SquareBlock.collisionRectangles[0].getX()) {
							SmileySprites[i].setPosition(SmileySprites[i].getX()+(smileySpeed/2 + 0.5f),SmileySprites[i].getY());
						}
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed);
						break;
					case "upsideright":
						if (SmileySprites[i].getX() > SquareBlock.collisionRectangles[1].getX()+SmileySprites[i].getWidth()/2) {
							SmileySprites[i].setPosition(SmileySprites[i].getX()-(smileySpeed/2 + 1),SmileySprites[i].getY());
						}
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()+smileySpeed);
						
						break;
					case "downsideright":
						if (SmileySprites[i].getX() > SquareBlock.collisionRectangles[1].getX()+SmileySprites[i].getWidth()/2) {
							SmileySprites[i].setPosition(SmileySprites[i].getX()-(smileySpeed/2 + 1),SmileySprites[i].getY());
						}
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed);						
						break;
				
					case "diagdownleft":
						SquareBlock.getAngle(0, i, smileyDir[i], smileySpeed);
						break;
					case "diagdownright":
						SquareBlock.getAngle(1, i, smileyDir[i], smileySpeed);
						break;
					case "diagupleft":
						SquareBlock.getAngle(3, i, smileyDir[i], smileySpeed);
						break;
					case "diagupright":
						SquareBlock.getAngle(2, i, smileyDir[i], smileySpeed);
						break;
					case "zigzagdownleft":
						zigZagMovement(i,smileyDir[i],smileySpeed);
					break;
					case "zigzagdownright":
						zigZagMovement(i,smileyDir[i],smileySpeed);
					break;
					case "zigzagupleft":
						zigZagMovement(i,smileyDir[i],smileySpeed);
					break;
					case "zigzagupright":
						zigZagMovement(i,smileyDir[i],smileySpeed);
					break;
					default:
						SmileySprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-smileySpeed);
						break;
					}
					smileyRectangles[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY());
				
					
					if (GamePlay.startRot) {
						if (Levels.features[Levels.levelNo].equals("downswap") && Levels.emoCollisionCnt==0 && !Levels.swapbool) {
							if (SmileySprites[i].getY() < constants.ConstantValues.CAMERA_HEIGHT/2) {
								Levels.swapbool = true;
								SquareBlock.swapFn(0, 1);
							}
						}
						else if (Levels.features[Levels.levelNo].equals("upswap") && Levels.emoCollisionCnt==0 && !Levels.swapbool) {
							if (SmileySprites[i].getY() > constants.ConstantValues.CAMERA_HEIGHT/4) {
								Levels.swapbool = true;
								SquareBlock.swapFn(3, 2);
							}
						}
					}
					if (SmileySprites[i].getY() < -SmileySprites[i].getHeight()) {
						smileyVisible[i]=0 ;
					}
					smileySpeed = smileySpeed1;
					
					if (smileyDir[i].contains("down")) {
						if (SmileyBlurSprites[i].isFlipY()) {
							SmileyBlurSprites[i].flip(false, false);
						}
						SmileyBlurSprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()/*+SmileySprites[i].getHeight()/2*/);
					}
					else
					{
						if (!SmileyBlurSprites[i].isFlipY()) {
						SmileyBlurSprites[i].flip(false, true);
						}
						SmileyBlurSprites[i].setPosition(SmileySprites[i].getX(), SmileySprites[i].getY()-SmileySprites[i].getHeight());
					}
					
					if (!constants.ConstantValues.isClassicTutorial && (SmileySprites[0].getY() <= constants.ConstantValues.CAMERA_HEIGHT/2 + smileySpeed) && (SmileySprites[0].getY() > constants.ConstantValues.CAMERA_HEIGHT/2)  ) {
						TapandholdTut.showTut=true;
					}
					
				}			
			}
			
			if (GamePlay.startRot) {
				if (Levels.features[Levels.levelNo].equals("downfall") )
				{
					SquareBlock.fallFn(0);
				}
				else if (Levels.features[Levels.levelNo].equals("upfall") )
				{
					SquareBlock.fallFn(1);
				}
				else if (Levels.features[Levels.levelNo].equals("downrotate") )
				{
					SquareBlock.rotateFn(0);
				}
				else if (Levels.features[Levels.levelNo].equals("uprotate") )
				{
					SquareBlock.rotateFn(1);
				}
			}
	}
	int scalefac=0;
	public void renderSmileys(SpriteBatch batch) {
		// TODO Auto-generated method stub
		scalefac++;
		if (scalefac > 5) {
			scalefac=0;
		}
		for (int i = 0; i < SmileySprites.length; i++) {
			if (smileyVisible[i] !=0) {
				if (GamePlay.gameState.equals("run")) {
					if (scalefac == 5) {
						if (SmileyBlurSprites[i].getScaleY() == 1.0f) {
							SmileyBlurSprites[i].setScale(1.0f, 0.74f);
						} else if (SmileyBlurSprites[i].getScaleY() == 0.74f) {
							SmileyBlurSprites[i].setScale(1.0f, 0.5f);
						} else if (SmileyBlurSprites[i].getScaleY() == 0.5f) {
							SmileyBlurSprites[i].setScale(1.0f, 0.75f);
						} else if (SmileyBlurSprites[i].getScaleY() == 0.75f) {
							SmileyBlurSprites[i].setScale(1.0f, 1.0f);
						}
					}
					if ((constants.ConstantValues.isClassicTutorial || !TapandholdTut.showTut) && SmileyBlurSprites[i].getScaleY() != 1.0f && constants.ConstantValues.pattern == 'd') {
						if (smileyDir[i].contains("down")) {
							SmileyBlurSprites[i].setPosition(SmileyBlurSprites[i].getX(),
									SmileyBlurSprites[i].getY() - SmileyBlurSprites[i].getHeight() / 8);
						} else {
							SmileyBlurSprites[i].setPosition(SmileyBlurSprites[i].getX(),
									SmileyBlurSprites[i].getY() + SmileyBlurSprites[i].getHeight() / 8);
						}
					} 
				}
				SmileyBlurSprites[i].draw(batch);

				SmileySprites[i].draw(batch);
			}
		}
	}
	
	public void showSmiley() {
		// TODO Auto-generated method stub
		
		if (constants.ConstantValues.isClassicTutorial) {
			for (int i = 0; i < SmileySprites.length; i++) {
				if (smileyVisible[i] == 0) {
					//System.out.println("i is"+i);
					int num = ran.nextInt() % 6;

					if (Levels.blockPlace.equals("down")) {

						if (Levels.features[Levels.levelNo].equals("diag")) {
							if (num < 2) {
								smileyDir[i] = "diagdownleft";
							} else {
								smileyDir[i] = "diagdownright";
							}
						} else if (Levels.features[Levels.levelNo].equals("zigzag")
								|| Levels.features[Levels.levelNo].equals("zigzaghide")) {
							if (num < 2) {
								smileyDir[i] = "zigzagdownleft";
							} else {
								smileyDir[i] = "zigzagdownright";
							}
						} else
							smileyDir[i] = "down";
					} else if (Levels.blockPlace.equals("up")) {
						if (Levels.features[Levels.levelNo].equals("diag")) {
							if (num < 2) {
								smileyDir[i] = "diagupleft";
							} else {
								smileyDir[i] = "diagupright";
							}
						} else if (Levels.features[Levels.levelNo].equals("zigzag")
								|| Levels.features[Levels.levelNo].equals("zigzaghide")) {
							if (num < 2) {
								smileyDir[i] = "zigzagupleft";
							} else {
								smileyDir[i] = "zigzagupright";
							}
						} else
							smileyDir[i] = "up";
					} else if (Levels.blockPlace.equals("mid")) {
						if (Levels.features[Levels.levelNo].equals("side1")) {
							if (num < 2) {
								smileyDir[i] = "upsideleft";
							} else if (num < 4) {
								smileyDir[i] = "downsideleft";
							} else if (num == 4) {
								smileyDir[i] = "up";
							} else {
								smileyDir[i] = "down";
							}
						} else if (Levels.features[Levels.levelNo].equals("side2")) {
							switch (num) {
							case 0:
								smileyDir[i] = "upsideright";
								break;
							case 1:
								smileyDir[i] = "downsideright";
								break;
							case 2:
								smileyDir[i] = "upsideleft";
								break;
							case 3:
								smileyDir[i] = "downsideleft";
								break;
							case 4:
								smileyDir[i] = "up";
								break;
							default:
								smileyDir[i] = "down";
								break;
							}
						} else {
							if (ran.nextInt() % 5 == 0) {
								smileyDir[i] = "up";
							} else {
								smileyDir[i] = "down";
							}
						}

					}

					smileyVisible[i] = 1;

					SmileySprites[i] = null;
					SmileyBlurSprites[i] = null;
					ShuffleLogic.shuffleArray(smileyNo);
					SmileyIconNos[i] = smileyNo[0];
					SmileySprites[i] = new Sprite(
							MyGdxGame.gameAtlas.findRegion(GamePlay.getPattern() + (SmileyIconNos[i] + 1) + "rect"));
					SmileyBlurSprites[i] = new Sprite(MyGdxGame.gameAtlas
							.findRegion(GamePlay.getBlurPattern() + (SmileyIconNos[i] + 1) + "blur"));

					setSmileyPosition(i);
					dashno.add(i);

					Levels.emoCnt++;
					break;
				}
			} 
		}
		else if(constants.ConstantValues.classicCnt==0)
		{
			if (smileyVisible[smileyInd]==0) {
				
				smileyVisible[smileyInd] = 1;				
				SmileySprites[smileyInd] = null;
				SmileyBlurSprites[smileyInd] = null;
				
				if (constants.ConstantValues.classicSteps==0 || constants.ConstantValues.classicSteps==2) {
					SmileyIconNos[smileyInd] = SquareBlock.symSequence[1];
				}
				else
				{
					SmileyIconNos[smileyInd] = SquareBlock.symSequence[0];
				}
				
				SmileySprites[smileyInd] = new Sprite(
						MyGdxGame.gameAtlas.findRegion(GamePlay.getPattern() + (SmileyIconNos[smileyInd] + 1) + "rect"));
				
				SmileyBlurSprites[smileyInd] = new Sprite(MyGdxGame.gameAtlas
						.findRegion(GamePlay.getBlurPattern() + (SmileyIconNos[smileyInd] + 1) + "blur"));

				if (constants.ConstantValues.classicSteps==0) {
				SmileySprites[smileyInd].setPosition(SquareBlock.xypos[0][0], constants.ConstantValues.CAMERA_HEIGHT);
				}
				else
				{
				SmileySprites[smileyInd].setPosition(SquareBlock.xypos[1][0], constants.ConstantValues.CAMERA_HEIGHT);
				}
				
				dashno.add(smileyInd);
				Levels.emoCnt++;
				if (Levels.emoCnt==3) {
					Levels.emoCnt=0;					
				}
			}
		}
		else 
		{
			if (smileyVisible[smileyInd]==0) {
				
				smileyVisible[smileyInd] = 1;				
				SmileySprites[smileyInd] = null;
				SmileyBlurSprites[smileyInd] = null;
				
				if (constants.ConstantValues.classicSteps==0 ) {
					SmileyIconNos[smileyInd] = SquareBlock.symSequence[1];
				}
				else
				{
					SmileyIconNos[smileyInd] = SquareBlock.symSequence[0];
				}
				
				SmileySprites[smileyInd] = new Sprite(
						MyGdxGame.gameAtlas.findRegion(GamePlay.getPattern() + (SmileyIconNos[smileyInd] + 1) + "rect"));
				
				SmileyBlurSprites[smileyInd] = new Sprite(MyGdxGame.gameAtlas
						.findRegion(GamePlay.getBlurPattern() + (SmileyIconNos[smileyInd] + 1) + "blur"));

				if (constants.ConstantValues.classicSteps==0) {
				SmileySprites[smileyInd].setPosition(SquareBlock.xypos[0][0], constants.ConstantValues.CAMERA_HEIGHT);
				}
				else
				{
				SmileySprites[smileyInd].setPosition(SquareBlock.xypos[1][0], constants.ConstantValues.CAMERA_HEIGHT);
				}
				
				dashno.add(smileyInd);
				Levels.emoCnt++;
				if (Levels.emoCnt==2) {
					Levels.emoCnt=0;					
				}
			}
		}
	}
	
	
	private void setSmileyPosition(int i) {
		// TODO Auto-generated method stub
		float smileyX=SquareBlock.xypos[0][0];
		float smileyX1=SquareBlock.xypos[1][0];
		float SmileyY=0;
		switch (smileyDir[i]) {
		case "up":
			SmileyY = 0 - SmileySprites[i].getHeight();
			break;
		case "down":				
			SmileyY = constants.ConstantValues.CAMERA_HEIGHT;
			break;
		case "upsideleft":
			smileyX = 0;
			smileyX1=0;
			SmileyY = 0 - SmileySprites[i].getHeight();
			break;
		case "downsideleft":
			smileyX = 0;
			smileyX1=0;
			SmileyY = constants.ConstantValues.CAMERA_HEIGHT;
			break;
		case "upsideright":
			smileyX = constants.ConstantValues.CAMERA_WIDTH;
			smileyX1= constants.ConstantValues.CAMERA_WIDTH;
			SmileyY = 0 - SmileySprites[i].getHeight();
			break;
		case "downsideright":
			smileyX = constants.ConstantValues.CAMERA_WIDTH;
			smileyX1= constants.ConstantValues.CAMERA_WIDTH;
			SmileyY = constants.ConstantValues.CAMERA_HEIGHT;
			break;
		case "diagdownleft" :
		case "zigzagdownleft":
			smileyX = 0;
			smileyX1=0;
			SmileyY = constants.ConstantValues.CAMERA_HEIGHT;
			break;
		case "diagdownright":
		case "zigzagdownright":
			smileyX = constants.ConstantValues.CAMERA_WIDTH - SmileySprites[0].getWidth();
			smileyX1= constants.ConstantValues.CAMERA_WIDTH - SmileySprites[0].getWidth();
			SmileyY = constants.ConstantValues.CAMERA_HEIGHT;
			break;
		case "diagupleft":
		case "zigzagupleft":
			smileyX = 0;
			smileyX1=0;
			SmileyY = 0- SmileySprites[0].getHeight();
			break;
		case "diagupright":
		case "zigzagupright":
			smileyX = constants.ConstantValues.CAMERA_WIDTH - SmileySprites[0].getWidth();
			smileyX1= constants.ConstantValues.CAMERA_WIDTH - SmileySprites[0].getWidth();
			SmileyY = 0- SmileySprites[0].getHeight();

			break;
		default:
			break;
		}
		
		if (Math.abs(ran.nextInt()%4) < 2) {
			SmileySprites[i].setPosition(smileyX1,SmileyY);
		}
		else
		{
			SmileySprites[i].setPosition(smileyX, SmileyY);
		}
	}
	
	public void checkCollision() {
		// TODO Auto-generated method stub
		for (int i = 0; i < smileyRectangles.length; i++) {
			for (int j = 0; j < SquareBlock.collisionRectangles.length; j++) {
				if (smileyVisible[i]!=0 && smileyRectangles[i].overlaps(SquareBlock.collisionRectangles[j]) && GamePlay.startRot )
				{
					if( SmileyIconNos[i] ==  SquareBlock.symSequence[j])
					{
						//System.out.println("collision no:"+j);
					
						Levels.emoCollisionCnt++;
						Score.updateScore();
						if (constants.ConstantValues.isClassicRight) {
							if (constants.ConstantValues.classicCnt==1 && Score.score >=3) {
								Score.score=0;
								Levels.emoCollisionCnt=0;
								constants.ConstantValues.isClassicRight=false;
								constants.ConstantValues.isClassicLeft=false;
							}
							else if (constants.ConstantValues.classicCnt==2 && Score.score >=2)
							{
								Score.score=0;
								Levels.emoCollisionCnt=0;
								constants.ConstantValues.isClassicRight=false;
								constants.ConstantValues.isClassicLeft=false;
							}												
						}
						
						smileyVisible[i] = 0;
						dashno.remove(0);
						smileyDash=-1;

						//GamePlay.blastAnimation(GamePlay.getPattern()+(SmileyIconNos[i]+1)+"rect", i);
						for (int j2 = 0; j2 < SquareBlock.emoSymbols.length; j2++) {
							if (SquareBlock.emoSymbols[j2].getX() == SquareBlock.xypos[j][0] && 
									SquareBlock.emoSymbols[j2].getY() == SquareBlock.xypos[j][1]) {
								SquareBlock.emoSymbols[j2].setScale(1.15f);
								if (SquareBlock.emoSymbolNos[j2]==1) {
									SquareBlock.emoSymbolNos[j2] = 0;
								}
								break;
							}
						}
						if (Levels.emoCollisionCnt!= Levels.targetScore && GamePlay.startRot) {
							switch (Levels.features[Levels.levelNo]) {
							case "downswap":
								SquareBlock.swapFn(0,1);
								break;
							case "upswap":
								SquareBlock.swapFn(3,2);
								break;					
							default:
								break;
							}
						}
					}
					else
					{

					
							smileyGameOverNo=i;
							smileyGameOverPartNo=j;
							gameOverFn();
						
					}
				}
			}
		}
	}

	public static void gameOverFn()
	{
		int i = smileyGameOverNo;
		int j = smileyGameOverPartNo;
		if(SmileyIconNos[i]>=0) {
			smileyVisible[i] = 0;
			ParticleEffectsClass.startEmitter();
			String direction = "down";
			if (smileyDir[i].contains("up")) {
				direction = "up";
			}
			ParticleEffectsClass.setPosition(SquareBlock.collisionRectangles[j].getX(), SquareBlock.collisionRectangles[j].getY(), direction);
			GamePlay.gameState = "gameoveranim";
			SoundManager.playGameOver();
			Score.compareScores();
			for (int k = 0; k < SmileyIconNos.length; k++) {
				SmileyIconNos[k]=-1;
			}
		}
	}

	private void zigZagMovement(int no,String dir,int speed) {
		// TODO Auto-generated method stub
		float speed1=speed*2.5f;
		float speed2=speed*2.0f;
		if (dir.equals("zigzagdownleft")) {
			if (SmileySprites[no].getY() < constants.ConstantValues.CAMERA_HEIGHT / 2) {
				if (SmileySprites[no].getX() == SquareBlock.xypos[0][0] || (SmileySprites[no].getX() > SquareBlock.xypos[0][0] && SmileySprites[no].getX() <= SquareBlock.xypos[0][0] + (speed * 2))) {
					smileyDir[no] = "down";
					SmileySprites[no].setPosition(SquareBlock.xypos[0][0], SmileySprites[no].getY() - speed);
				} else if (SmileySprites[no].getX() == SquareBlock.xypos[1][0] || (SmileySprites[no].getX() > SquareBlock.xypos[1][0] && SmileySprites[no].getX() <= SquareBlock.xypos[1][0] + (speed * 2))) {
					smileyDir[no] = "down";
					SmileySprites[no].setPosition(SquareBlock.xypos[1][0], SmileySprites[no].getY() - speed);
				} else {
					SmileySprites[no].setPosition(SmileySprites[no].getX() + (speed1), SmileySprites[no].getY() - speed);
				}
			} else {
				SmileySprites[no].setPosition(SmileySprites[no].getX() + (speed1), SmileySprites[no].getY() - speed);
			}
			if (SmileySprites[no].getX() > constants.ConstantValues.CAMERA_WIDTH - SmileySprites[no].getWidth()) {
				smileyDir[no] = "zigzagdownright";
			}

		} else if (dir.equals("zigzagdownright")) {
			if (SmileySprites[no].getY() < constants.ConstantValues.CAMERA_HEIGHT / 2) {
				if (SmileySprites[no].getX() == SquareBlock.xypos[0][0] || (SmileySprites[no].getX() > SquareBlock.xypos[0][0] && SmileySprites[no].getX() <= SquareBlock.xypos[0][0] + (speed * 2))) {
					smileyDir[no] = "down";
					SmileySprites[no].setPosition(SquareBlock.xypos[0][0], SmileySprites[no].getY() - speed);
				} else if (SmileySprites[no].getX() == SquareBlock.xypos[1][0] || (SmileySprites[no].getX() > SquareBlock.xypos[1][0] && SmileySprites[no].getX() <= SquareBlock.xypos[1][0] + (speed * 2))) {
					smileyDir[no] = "down";
					SmileySprites[no].setPosition(SquareBlock.xypos[1][0], SmileySprites[no].getY() - speed);
				} else {
					SmileySprites[no].setPosition(SmileySprites[no].getX() - (speed1), SmileySprites[no].getY() - speed);
				}
			} else {
				SmileySprites[no].setPosition(SmileySprites[no].getX() - (speed1), SmileySprites[no].getY() - speed);
			}
			if (SmileySprites[no].getX() < 0) {
				smileyDir[no] = "zigzagdownleft";
			}

		} else if (dir.equals("zigzagupleft")) {
			if (SmileySprites[no].getY() > constants.ConstantValues.CAMERA_HEIGHT / 2) {
				if (SmileySprites[no].getX() == SquareBlock.xypos[0][0] || (SmileySprites[no].getX() > SquareBlock.xypos[0][0] && SmileySprites[no].getX() <= SquareBlock.xypos[0][0] + (speed * 2))) {
					smileyDir[no] = "up";
					SmileySprites[no].setPosition(SquareBlock.xypos[0][0], SmileySprites[no].getY() + speed);
				} else if (SmileySprites[no].getX() == SquareBlock.xypos[1][0] || (SmileySprites[no].getX() > SquareBlock.xypos[1][0] && SmileySprites[no].getX() <= SquareBlock.xypos[1][0] + (speed * 2))) {
					smileyDir[no] = "up";
					SmileySprites[no].setPosition(SquareBlock.xypos[1][0], SmileySprites[no].getY() + speed);
				} else {
					SmileySprites[no].setPosition(SmileySprites[no].getX() + (speed2), SmileySprites[no].getY() + speed);
				}
			} else {
				SmileySprites[no].setPosition(SmileySprites[no].getX() + (speed2), SmileySprites[no].getY() + speed);
			}
			if (SmileySprites[no].getX() > constants.ConstantValues.CAMERA_WIDTH - SmileySprites[no].getWidth()) {
				smileyDir[no] = "zigzagupright";
			}

		} else if (dir.equals("zigzagupright")) {
			if (SmileySprites[no].getY() > constants.ConstantValues.CAMERA_HEIGHT / 2) {
				if (SmileySprites[no].getX() == SquareBlock.xypos[0][0] || (SmileySprites[no].getX() > SquareBlock.xypos[0][0] && SmileySprites[no].getX() <= SquareBlock.xypos[0][0] + (speed * 2))) {
					smileyDir[no] = "up";
					SmileySprites[no].setPosition(SquareBlock.xypos[0][0], SmileySprites[no].getY() + speed);
				} else if (SmileySprites[no].getX() == SquareBlock.xypos[1][0] || (SmileySprites[no].getX() > SquareBlock.xypos[1][0] && SmileySprites[no].getX() <= SquareBlock.xypos[1][0] + (speed * 2))) {
					smileyDir[no] = "up";
					SmileySprites[no].setPosition(SquareBlock.xypos[1][0], SmileySprites[no].getY() + speed);
				} else {
					SmileySprites[no].setPosition(SmileySprites[no].getX() - (speed2), SmileySprites[no].getY() + speed);
				}
			} else {
				SmileySprites[no].setPosition(SmileySprites[no].getX() - (speed2), SmileySprites[no].getY() + speed);
			}
			if (SmileySprites[no].getX() < 0) {
				smileyDir[no] = "zigzagupleft";
			}

		} else {
		}
	}


}
