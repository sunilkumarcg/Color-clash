package com.m2fpremium.colorclash;

import java.util.Random;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import constants.ConstantValues;

public class SpeedLines {
	int totlines = 7;
	Sprite[] speedLineSpr = new Sprite[totlines];
	//Animation[] speedLineAnim = new Animation[totlines];
	int[] sppedLineVisible = new int[totlines];
	public static float lineAnimSpeed=0.03f;
	public static int movespeed=3;
	
	int gap =20;
	Random random;
	//AnimatedTiledMapTile

	public SpeedLines() {
		// TODO Auto-generated constructor stub
		random=new Random();
		for (int i = 0; i < speedLineSpr.length; i++) {
			sppedLineVisible[i] = 0;
			/*speedLineAnim[i]=new Animation(lineAnimSpeed+(random.nextFloat()%1),MyGdxGame.gameAtlas.findRegions("line"),
	        		Animation.PlayMode.LOOP_PINGPONG);*/
			if (random.nextInt()%2==0) {
				speedLineSpr[i] = new Sprite(MyGdxGame.gameAtlas.findRegion("linea1"));
			}
			else
			speedLineSpr[i] = new Sprite(MyGdxGame.gameAtlas.findRegion("lineb1"));
			setSpeedLinePositions(i);
		}
	}
	
	private void setSpeedLinePositions(int i) {
		// TODO Auto-generated method stub
		int xpos = 0,ypos=0;
			xpos = Math.abs(random.nextInt(100))+((i*gap)+(i*100));
			if (i!=0) {
				ypos = ConstantValues.CAMERA_HEIGHT + (i*100)+ Math.abs(random.nextInt(i*50));
			}
			else 
			{
				ypos = ConstantValues.CAMERA_HEIGHT;
			}
			speedLineSpr[i].setPosition(xpos,ypos);
			/*if (random.nextInt()%3<2) {
				sppedLineVisible[i]= 1;
			}
			else
			{
				sppedLineVisible[i]= 0;
			}*/
			sppedLineVisible[i]= 1;
			if (random.nextInt()%5==1) {
				speedLineSpr[i].setRegion(MyGdxGame.gameAtlas.findRegion("lineb1"));
			}
			else
				speedLineSpr[i].setRegion(MyGdxGame.gameAtlas.findRegion("linea1"));
		
	}
	
	public void updateSpeedLines(float et) {
		// TODO Auto-generated method stub
		ConstantValues.elapsedTime += et;

		for (int i = 0; i < speedLineSpr.length; i++) {
			//speedLineSpr[i].setRegion(speedLineAnim[i].getKeyFrame(ConstantValues.elapsedTime,true));	
			speedLineSpr[i].setPosition(speedLineSpr[i].getX(), speedLineSpr[i].getY()-movespeed);
			if (speedLineSpr[i].getY()<0-speedLineSpr[i].getHeight()/2) {
				//sppedLineVisible[i]=0;
				setSpeedLinePositions(i);
			}
			
		}
	}
	
	public void renderSpeedLines(SpriteBatch batch) {
		// TODO Auto-generated method stub
		for (int i = 0; i < speedLineSpr.length; i++) {
			if (sppedLineVisible[i] !=0) {
			//	System.out.println("drawing"+i);
				speedLineSpr[i].draw(batch);
			}
		}
	
	}
	
}
