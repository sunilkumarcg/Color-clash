package com.m2fpremium.colorclash;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;


public class GameButton {
    private OrthographicCamera cam;
    private boolean clicked;
    private TextureRegion[] font;
    private float height;
    private TextureRegion reg;
    public ScaleAnimation scaleAnimation;
    private Texture tex;
    private String text;
    Vector3 vec;
    private float width;
    public float f87x;
    public float f88y;
    public int number;
    public boolean buttonTouched = false; 
    public boolean scallingBool = false; 
    

    public GameButton(TextureRegion reg, float x, float y, OrthographicCamera cam, ScaleAnimation scaleAnimation) {
        int i;
        this.reg = reg;
        this.f87x = x;
        this.f88y = y;
        this.cam = cam;
        this.scaleAnimation = scaleAnimation;
        this.width = (float) reg.getRegionWidth();
        this.height = (float) reg.getRegionHeight();
        this.vec = new Vector3();
        this.font = new TextureRegion[11];

    }
    
    public GameButton(TextureRegion reg, OrthographicCamera cam, ScaleAnimation scaleAnimation) {
        int i;
        this.reg = reg;

        this.cam = cam;
        this.scaleAnimation = scaleAnimation;
        this.width = (float) reg.getRegionWidth();
        this.height = (float) reg.getRegionHeight();
        this.vec = new Vector3();
        this.font = new TextureRegion[11];

    }

    public GameButton(TextureRegion reg, float x, float y, OrthographicCamera cam, int number) {
        int i;
        this.reg = reg;
        this.f87x = x;
        this.f88y = y;
        this.cam = cam;
        this.width = (float) reg.getRegionWidth();
        this.height = (float) reg.getRegionHeight();
        this.vec = new Vector3();
        this.number = number;
        this.font = new TextureRegion[11];

    }

    public GameButton(TextureRegion reg, OrthographicCamera cam) {
        int i;
        this.reg = reg;
        this.cam = cam;
        this.width = (float) reg.getRegionWidth();
        this.height = (float) reg.getRegionHeight();
        this.vec = new Vector3();

        this.font = new TextureRegion[11];

    }

    public boolean isClicked() {
        return clicked;
    }

    public void setText(String s) {
        this.text = s;
    }

    public void update(float dt) {
    	 float x = Gdx.input.getX();
         float y = Gdx.input.getY();
         float yR = MyGdxGame.viewport.getScreenHeight() / (y - MyGdxGame.viewport.getScreenY()); // the y ratio
         y = constants.ConstantValues.CAMERA_HEIGHT / yR;

         float xR = MyGdxGame.viewport.getScreenWidth() / (x - MyGdxGame.viewport.getScreenX()); // the x ratio
         x = constants.ConstantValues.CAMERA_WIDTH / xR;
    	
        this.vec.set(x, constants.ConstantValues.CAMERA_HEIGHT - y, 0.0f);
        
       // System.out.println(MyInput.isPressed(0)+"vecx"+this.vec.x +"vec y"+this.vec.y+":xval:"+(this.f87x - (this.width / 2.0f)));
        
        
        
        if (!MyInput.isPressed(0) || this.vec.x <= this.f87x - (this.width / 2.0f) || 
        		this.vec.x >= this.f87x + (this.width / 2.0f) || 
        		this.vec.y <= this.f88y - (this.height / 2.0f) || this.vec.y >= this.f88y + (this.height / 2.0f)) {
            clicked = false;
        } else {
            clicked = true;
        }
    }

    public void updatePosition(float posX, float posY) {
        this.f87x = posX;
        this.f88y = posY;
    }

    public void render(SpriteBatch sb) {
        sb.draw(this.reg, this.f87x - (this.width / 2.0f), this.f88y - (this.height / 2.0f));
        if (this.text != null) {
            drawString(sb, this.text, this.f87x, this.f88y);
        }
    }
    
    public void render(SpriteBatch sb, TextureRegion textureRegion) {
        sb.draw(textureRegion, this.f87x - (this.width / 2.0f), this.f88y - (this.height / 2.0f));
        if (this.text != null) {
            drawString(sb, this.text, this.f87x, this.f88y);
        }
    }

    public void render(SpriteBatch sb, float posX, float posY) {
        this.f87x = posX;
        this.f88y = posY;
        sb.setProjectionMatrix(this.cam.combined);
        sb.draw(this.reg, this.f87x - (this.width / 2.0f), this.f88y - (this.height / 2.0f));
//        if (this.text != null) {
//            drawString(sb, this.text, this.f87x, this.f88y);
//        }
    }
    
    public void render(SpriteBatch sb, TextureRegion textureRegion, float posX, float posY) {
        this.f87x = posX;
        this.f88y = posY;
//        scaleAnimation.update();
        sb.setProjectionMatrix(this.cam.combined);
        sb.draw(textureRegion, this.f87x - (this.width / 2.0f), this.f88y - (this.height / 2.0f));
        
//        if (this.text != null) {
//            drawString(sb, this.text, this.f87x, this.f88y);
//        }
    }

    public void render(SpriteBatch sb, TextureRegion textureRegion, float posX, float posY, boolean scalling, float angle) {
    	 this.f87x = posX;
         this.f88y = posY;
    	if (scalling) {
//    		System.out.println("scaling xx "+scaleAnimation.getScaleX());
    		if (scaleAnimation.getScaleX() < 1.0f) {
    			scaleAnimation.update();
			}
		}
        sb.draw(textureRegion, this.f87x - (this.width / 2.0f), this.f88y - (this.height / 2.0f), this.width / 2.0f, this.height / 2.0f, this.width, this.height, this.scaleAnimation.getScaleX(), this.scaleAnimation.getScaleY(), (float) angle);
//        if (this.text != null) {
//            drawString(sb, this.text, this.f87x, this.f88y);
//        }
    }
    
    public void render(SpriteBatch sb, TextureRegion  textureRegion, int angle) {
//        scaleAnimation.update();
    	if (scaleAnimation.getScaleX() >= 1.0f) {
//			scaleAnimation.update();
    		scaleAnimation.setScaleSpeedXX(0.002f);
    		scaleAnimation.setScaleSpeedYY(0.002f);
		}
    	scaleAnimation.update();
        sb.draw(textureRegion, this.f87x - (this.width / 2.0f), this.f88y - (this.height / 2.0f), this.width / 2.0f, this.height / 2.0f, this.width, this.height, this.scaleAnimation.getScaleX(), this.scaleAnimation.getScaleY(), (float) angle);
//        if (this.text != null) {
//            drawString(sb, this.text, this.f87x, this.f88y);
//        }
    }
    
   

    private void drawString(SpriteBatch sb, String s, float x, float y) {
        int len = s.length();
        float xo = (float) ((this.font[0].getRegionWidth() * len) / 2);
        float yo = (float) (this.font[0].getRegionHeight() / 2);
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (c == '/') {
                c = '\n';
            } else {
                if (c >= '0' && c <= '9') {
                    c = (char) (c - 48);
                }
            }
            sb.draw(this.font[c], (((float) (i * 9)) + x) - xo, y - yo);
        }
    }
}
