package com.m2fpremium.colorclash;

public class Score {

	public static int score;
	public static int bestscore,bestscoreclassic,bestscorespin,bestscoretap,bestscoredash;
	static PreferenceClass preferenceClass;
	
	public Score() {
		// TODO Auto-generated constructor stub
		score=0;
		preferenceClass=new PreferenceClass();
		bestscore=PreferenceClass.readBestScore();
		bestscoreclassic=PreferenceClass.readBestScoreClassic();
		bestscorespin=PreferenceClass.readBestScoreSpin();
		bestscoretap=PreferenceClass.readBestScoreTap();
		bestscoredash=PreferenceClass.readBestScoreDash();
	}
	
	public static void updateScore() {
		// TODO Auto-generated method stub
		score++;
		compareBestScores();
		SoundManager.playMatch();
	}
	
	private static void setBestScore(int scr) {
		// TODO Auto-generated method stub
		bestscore= scr;
		preferenceClass.saveBestScore(scr);	
	}
	private static void setBestScoreClassic(int scr) {
		// TODO Auto-generated method stub
		bestscoreclassic= scr;
		preferenceClass.saveBestScoreClassic(scr);
	}
	private static void setBestScoreDash(int scr) {
		// TODO Auto-generated method stub
		bestscoredash= scr;
		preferenceClass.saveBestScoreDash(scr);
	}
	private static void setBestScoreSpin(int scr) {
		// TODO Auto-generated method stub
		bestscorespin= scr;
		preferenceClass.saveBestScoreSpin(scr);	
	}
	private static void setBestScoreTap(int scr) {
		// TODO Auto-generated method stub
		bestscoretap= scr;
		preferenceClass.saveBestScoreTap(scr);	
	}
	public static int getBestscore() {
		return bestscore;
	}
	public static void compareScores() {
		// TODO Auto-generated method stub
		switch (Levels.mode) {
		case "mixup":
			if ((bestscoreclassic < score)) {
				setBestScoreClassic(score);
			}
			break;
		case "endless":
			if (bestscoredash < score) {
				setBestScoreDash(score);
			}
			break;
		case "spin":
			if (bestscorespin < score) {
				setBestScoreSpin(score);
			}
			break;
		case "dash":
			if (bestscoretap < score) {
				setBestScoreTap(score);
			}
			break;
		default:
			break;
		}
		/*if (Levels.mode.equals("mixup")) { //classic
			if (bestscore < score) {
				setBestScore(score);
			}
		}*/
	
	}
	
	public static void compareBestScores() {
		// TODO Auto-generated method stub
		switch (Levels.mode) {
		case "mixup":
			if ( constants.ConstantValues.isClassicTutorial && (bestscoreclassic < score) && bestscoreclassic!=0) {
				BestscoreImg.bestScoreBool=true;
			}
			break;
		case "endless":
			if (bestscoredash < score  && bestscoredash!=0) {
				BestscoreImg.bestScoreBool=true;
			}
			break;
		case "spin":
			if (bestscorespin < score && bestscorespin!=0) {
				BestscoreImg.bestScoreBool=true;
			}
			break;
		case "dash":
			if (bestscoretap < score && bestscoretap!=0) {
				BestscoreImg.bestScoreBool=true;
			}
			break;
		default:
			break;
		}	
	}
}
