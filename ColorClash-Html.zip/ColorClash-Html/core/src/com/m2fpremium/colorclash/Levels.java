package com.m2fpremium.colorclash;

import java.util.ArrayList;
import java.util.Random;

public class Levels {
	
	public static int targetScore=10;
	public static int levelNo=0; 
	public static int totlevels=20;
	public static int extralevels=6;
	public static int minSpeed;
	public static int[] speed =new int[totlevels];
	public static int[] nextSpeed =new int[totlevels];
	public static String mode="";
	
	public static String[] mode1directions={"down","mid","down","mid","up","down","mid","down","up","down",
			"up","down","up","down","up","down","up","down","mid","down"};
	public static String[] mode1features={"none","none","none","none","none","downfall","diag","zigzag","diag","downswap",
			"upfall","downrotate","upfall","downrotate","upswap","zigzaghide","uprotate","downfall","diag","zigzaghide"};
	   
	public static String[] mode2directions={"down","up","down","up","down","up","mid","down","mid","down",
			"up","down","up","down","up","down","up","down","up","down","up"};
	public static String[] mode2features={"zigzaghide","zigzaghide","diag","diag","zigzag","zigzag","side1","downswap","side2","downfall",
			"upswap","downfall","upfall","downrotate","uprotate","downswap","upfall","down","up","downrotate","uprotate"};

	public static String[] directions=new String[totlevels];
	public static String[] features=new String[totlevels];
	
	public static int emoCnt= 0;
	public static int emoCollisionCnt= 0;
	public static String transState="none";
	public static String blockPlace="down";
	public static boolean swapbool = false;
	public static boolean speedbool = false,spinbool=false;
	public static int speedLmt= 10;
	public static int speedLmtFactor= 0;
	public static int scoreLmt= 50;
	public static int classicNo= 0;
	public static int levelCnt= 0;
	Random random;
	
	ArrayList<Integer[]> speedList = new ArrayList<>();
	ArrayList<String[]> dirList = new ArrayList<>();

	public Levels() {
		// TODO Auto-generated constructor stub
		//minSpeed=5;
		random= new Random();
		  if (mode.equals("endless"))		  
		  {
			 minSpeed=8;
		  }
		  else if (mode.equals("spin")) {
			minSpeed=4;
		  }
		  else if (mode.equals("dash"))		  
		  {
			 minSpeed=8;
		  }
		  else 
		  {
			  if (classicNo==1) {
				  minSpeed=7;
			  }
			  else
				  minSpeed=6;
		  }
		  
		 int[] speeds={minSpeed,minSpeed,minSpeed+1,minSpeed+1,minSpeed,
					minSpeed,minSpeed,minSpeed,minSpeed,minSpeed,
					minSpeed,minSpeed,minSpeed+1,minSpeed+1,minSpeed+1,
					minSpeed,minSpeed+1,minSpeed+2,minSpeed+1,minSpeed+1};
		 
		 for (int i = 0; i < speeds.length; i++) {
			speed[i] = speeds[i];
			nextSpeed[i]= speeds[i]+1;
		 }
		 
		 levelNo=0; 
		 emoCnt= 0;
		 emoCollisionCnt= 0;
		 transState="none";
		 Smiley.smileySpeed = speed[levelNo];
		 EndlessSmiley.smileySpeed= speed[levelNo];
		 SpinSmiley.smileySpeed= speed[levelNo];
		 DashSmiley.smileySpeed= speed[levelNo];
		 speedLmtFactor=0;
		 scoreLmt=20;
		 speedLmt=10;
		 blockPlace=directions[levelNo];
			spinbool=false;
		 if (mode.equals("endless")) {
			 EndlessSmiley.fixedSmileyTime = 220 - ( EndlessSmiley.smileySpeed*5);
		 }
		 else
		 {
		 Smiley.fixedSmileyTime = 100 - (Smiley.smileySpeed*15);
		 SpinSmiley.fixedSmileyTime = 200 - (SpinSmiley.smileySpeed*11);
		 DashSmiley.fixedSmileyTime = 100 - (DashSmiley.smileySpeed*5);
		 }
		 EndlessSmiley.fixedSmileyTime = EndlessSmiley.fixedSmileyTime-30;		
	}
	
	public void updateLevel() {
		// TODO Auto-generated method stub
		if (mode.equals("mixup")) {
		
		if (emoCnt==targetScore && transState.equals("none")) {
			emoCnt=0;
			transState="start";
		}
		if (emoCollisionCnt == targetScore && transState.equals("start")) {
			transState="move";
			SoundManager.playTrans();
			levelNo++;
			
			swapbool=false;
			String prevdir=blockPlace;

			if (levelNo>=totlevels) {
				levelCnt++;			
				levelNo=0;			
			}
			if (levelCnt==0) {
				Smiley.smileySpeed = speed[levelNo];	
			}
			else if (levelCnt==1) {
				Smiley.smileySpeed = nextSpeed[levelNo];	
			}
			else
			{
				if (Math.abs(random.nextInt()%2)==0) {
					Smiley.smileySpeed = speed[levelNo];	
				}
				else
				{
					Smiley.smileySpeed = nextSpeed[levelNo];
				}
			}
			blockPlace=directions[levelNo];
			 Smiley.fixedSmileyTime = 100 - (Smiley.smileySpeed*15);
			switch (blockPlace) {
			case "up":
				SquareBlock.movedir="up";
				SquareBlock.destY = GamePlay.up_y;
				break;
			case "mid":
				if (prevdir.equals("down")) {
					SquareBlock.movedir="up";
				}
				else
				{
					SquareBlock.movedir="down";
				}
				SquareBlock.destY = GamePlay.mid_y;
				break;
			case "down":
				SquareBlock.movedir="down";
				SquareBlock.destY = GamePlay.down_y;
				break;
			default:
				break;
			}
			
		}
		if (Levels.mode1directions[Levels.levelNo].contains("fall")|| Levels.mode1directions[Levels.levelNo].contains("rotate")) {
			Smiley.fixedSmileyTime = 100 - ((Smiley.smileySpeed-minSpeed)*10);
		}
		else
		Smiley.fixedSmileyTime = 100 - ((Smiley.smileySpeed-minSpeed)*5);

		}
		else if(mode.equals("endless"))
		{
			//System.out.println("smileyspeed"+Smiley.smileySpeed);
			if ( Score.score%speedLmt==0 && !speedbool) {
				speedbool=true;
				if (Score.score < scoreLmt) {
					speedLmtFactor=0;
					// EndlessSmiley.fixedSmileyTime = EndlessSmiley.fixedSmileyTime-15;		
				}
				else if (Score.score == scoreLmt && speedLmtFactor==0) {
					speedLmtFactor=2;	
					 EndlessSmiley.smileySpeed++;
					scoreLmt=scoreLmt+(speedLmt*speedLmtFactor);
					 EndlessSmiley.fixedSmileyTime = EndlessSmiley.fixedSmileyTime-10;	
				}
				else {
					if ((Score.score)%(scoreLmt+(speedLmt*speedLmtFactor))==0) {
						if (scoreLmt <50) {
							EndlessSmiley.fixedSmileyTime = EndlessSmiley.fixedSmileyTime-10;	
						}
						scoreLmt=scoreLmt+(speedLmt*speedLmtFactor);
						speedLmtFactor++;	
						 EndlessSmiley.smileySpeed++;
					}
				}
				
				if (EndlessSmiley.smileySpeed > 10) {
					
					EndlessSmiley.smileySpeed=10;
				}
				
			}
			
			if(Score.score%speedLmt!=0 && speedbool)
			{
				speedbool=false; 
			}
			
			//Smiley.fixedSmileyTime = 100 - ((Smiley.smileySpeed-minSpeed)*10);
			//System.out.println( Smiley.fixedSmileyTime+"**"+Smiley.smileySpeed+"&&"+minSpeed);
		}
		else if (mode.equals("spin")) {
			if (!spinbool) {
				if (Score.score!=0 && Score.score%10==0 ) {
					spinbool=true;
					if (Score.score%20==0) {
						SpinSmiley.smileySpeed++;
						if (SpinSmiley.smileySpeed > 9) {
							SpinSmiley.smileySpeed=9;
							SpinSmiley.fixedSmileyTime = 200 - (SpinSmiley.smileySpeed*11);
						}
						
						//SpinSquareBlock.angleVal=SpinSquareBlock.angleVal+0.5f;
					}
				}
			}
			else if(Score.score%11==0)
			{
				spinbool=false;
			}
			
		}
		else if (mode.equals("dash")) {
			if (!spinbool) {
				if (Score.score!=0 && Score.score%15==0 ) {
					spinbool=true;
					if (DashSmiley.smileySpeed < 13 ) {
						DashSmiley.smileySpeed++;
						DashSmiley.fixedSmileyTime = 100 - (DashSmiley.smileySpeed*5);
					}
					
				}
			}
			else if(Score.score%16==0)
			{
				spinbool=false;
			}
			
		}
		
	}
	
}
