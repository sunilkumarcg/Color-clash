package com.m2fpremium.colorclash;

public interface AndroidOnlyInterface
{
	public void showToast(String str1);
	
}
