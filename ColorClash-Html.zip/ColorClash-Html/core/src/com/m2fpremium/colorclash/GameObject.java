package com.m2fpremium.colorclash;

public abstract class GameObject {
	private float x;
	private float y;

	private float width = 1f;
	private float height = 1f;
	
	public GameObject() {
	
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	
	}

	public void setX(float x) {
		this.x = x;
	
	}

	public float getWidth() {
		return width;
	}

	public float getHeight() {
		return height;
	}

	public void setPosition(float x, float y) {
		this.x = x;
		this.y = y;
	}

	public void setSize(float width, float height) {
		this.width = width;
		this.height = height;
	}	
}
