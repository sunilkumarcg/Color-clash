package com.m2fpremium.colorclash;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.utils.viewport.FillViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class MyGdxGame extends ApplicationAdapter {
	public static AndroidOnlyInterface aoi;
	public static  HtmlInterface htmlInterface;
	
	public static SpriteBatch batch;
	Texture img,demoImg;
	public static Sprite demoSprite;
	public static boolean demobool=false;
	
	public MyGdxGame() {
		// TODO Auto-generated constructor stub
		
	}
	public MyGdxGame(HtmlInterface htmlI) {
		// TODO Auto-generated constructor stub
		this.htmlInterface = htmlI;
		/*ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("JavaScript");
// read script file
		try
		{
			engine.eval(new FileReader("E:/Graphics/The Jungle Kid/13/hidearrdbar.js"));
			//engine.eval(Files.newBufferedReader(Paths.get("C:/Scripts/Jsfunctions.js"), StandardCharsets.UTF_8));

			Invocable inv = (Invocable) engine;
		// call function from script file
			inv.invokeFunction("yourFunction", "param");
		}
		catch (Exception e)
		{

		}*/

	}
	public MyGdxGame(AndroidOnlyInterface aoim) {
		// TODO Auto-generated constructor stub
		this.aoi = aoim;
	}
	
	
	public static OrthographicCamera camera,rotCamera,bgCamera;
	public static loadResources res;
	
	private GameStateManager gsm;

	public static Viewport viewport;
	
	
	public static BitmapFont mFont,sFont,lFont;
	
	public static TextureAtlas gameAtlas,uiAtlas,tutAtlas,psAtlas,langAtlas;
	
	public boolean toast = false;

	PreferenceClass prefs;

	public static boolean isLoaded=false;
	
	@Override
	public void create () {

		res = new loadResources();
		batch = new SpriteBatch();
		camera = new OrthographicCamera();
		rotCamera= new OrthographicCamera();
		bgCamera=new OrthographicCamera();
		prefs = new PreferenceClass();
		langAtlas= new TextureAtlas("packers/lang/lang.pack");

		constants.ConstantValues.classicCnt = prefs.readClassicTut();
		if (prefs.readClassicTut() > 0) {
			constants.ConstantValues.isClassicTutorial=true;
		}
		if (prefs.readTaptapTut() > 0) {
			constants.ConstantValues.isTapTapTutorial=true;
		}
		if (prefs.readSpinTut() > 0) {
			constants.ConstantValues.isSpinTutorial=true;
		}		
		if (prefs.readMusicVal() > 0) {
			constants.ConstantValues.isMusicEnabled=false;
		}
		if (prefs.readSoundVal() > 0) {
			constants.ConstantValues.isSoundEnabled=false;
		}

		if (prefs.readRateKey() > 0) {
			constants.ConstantValues.isShowRateUs=false;
		}

		viewport =new FillViewport(constants.ConstantValues.CAMERA_WIDTH, constants.ConstantValues.CAMERA_HEIGHT,camera);
		//viewport.setScreenWidth(ConstantValues.CAMERA_WIDTH);
		//viewport.setScreenHeight(ConstantValues.CAMERA_HEIGHT);
		//	viewport.apply();
		
		camera.setToOrtho(true,viewport.getWorldWidth(),viewport.getWorldHeight());
		rotCamera.setToOrtho(true,viewport.getWorldWidth(),viewport.getWorldHeight());
		bgCamera.setToOrtho(true,viewport.getWorldWidth(),viewport.getWorldHeight());
		batch.setProjectionMatrix(camera.combined);
		/*rotCamera.rotate(-10);
		rotCamera.update();*/
		//rotCamera.zoom += 0.2;

		camera.up.set(0, 1, 0);
		camera.direction.set(0, 0, -1);
		
		rotCamera.up.set(0, 1, 0);
		rotCamera.direction.set(0, 0, -1);
		//rotCamera.rotate(-14);
		
		
		bgCamera.up.set(0, 1, 0);
		bgCamera.direction.set(0, 0, -1);
		//bgCamera.rotate(-14);
		MyInput.touch = true;
		gsm = new GameStateManager(this);

		img = new Texture("ingame/logo.png");	
		demoImg = new Texture("ingame/demo.png");
		demoSprite = new Sprite(demoImg);
		
		demoSprite.setPosition( 50, constants.ConstantValues.CAMERA_HEIGHT/2);
		
		Gdx.input.setCatchBackKey(true);
		Gdx.input.setCatchMenuKey(true);
		MyInputProcessor myInputProcessor = new MyInputProcessor();
	    InputMultiplexer im = myInputProcessor.returnInput();
		Gdx.input.setInputProcessor(im);  		
		
		sFont = new BitmapFont(Gdx.files.internal("fonts/score.fnt"), false);
		mFont= new BitmapFont(Gdx.files.internal("fonts/score.fnt"), false);
		lFont= new BitmapFont(Gdx.files.internal("fonts/score.fnt"), false);
		
		mFont.getData().setScale(1.25f);
		lFont.getData().setScale(1.4f);
	/*	FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("fonts/BRLNSDB.TTF"));
		FreeTypeFontParameter parameter = new FreeTypeFontParameter();
		parameter.size = 24;
		sFont = generator.generateFont(parameter); // font size 12 pixels
		parameter.size = 35;
		mFont = generator.generateFont(parameter); // font size 12 pixels
		generator.dispose(); // don't forget to dispose to avoid memory leaks!
*/	
	}



	@Override
	public void render () {
		
		Gdx.graphics.setTitle(constants.ConstantValues.TITLE+Gdx.graphics.getFramesPerSecond());


		/*try
		{
			if(this.htmlInterface!=null)
				this.htmlInterface.scrollWindow();
		}
		catch (Exception e)
		{}*/


		this.gsm.update(Gdx.graphics.getDeltaTime());
		
		MyInput.update();

		camera.update();
		rotCamera.update();
		bgCamera.update(); 
		this.gsm.render();

		if (gsm.MENU == constants.ConstantValues.stateNo) {
			if (SoundManager.volLevel < 1.0f) {
				SoundManager.volLevel = SoundManager.volLevel+0.001f;
			}
		}
		else if (gsm.GAMEPLAY == constants.ConstantValues.stateNo || gsm.ENDLESSPLAY == constants.ConstantValues.stateNo ||
				gsm.SPINPLAY == constants.ConstantValues.stateNo || gsm.DASHPLAY == constants.ConstantValues.stateNo) {
			if (SoundManager.volLevel > 0.2f) {
				SoundManager.volLevel = SoundManager.volLevel-0.001f;
			}
		}
		if (res.getMusic("bgMusic")!=null) {
			res.getMusic("bgMusic").setVolume(SoundManager.volLevel);

		}
//		super.render();
	}
	
	@Override
	public void dispose () {
		gameAtlas.dispose();
		uiAtlas.dispose();
		tutAtlas.dispose();
		psAtlas.dispose();
		langAtlas.dispose();
		
		MyGdxGame.res.getMusic("bgMusic").dispose();
		MyGdxGame.res.getMusic("spinMusic").dispose();
		
		MyGdxGame.res.getSound("transblock").dispose();
		MyGdxGame.res.getSound("click").dispose();
		MyGdxGame.res.getSound("gameover").dispose();
		MyGdxGame.res.getSound("fall").dispose();
		MyGdxGame.res.getSound("1").dispose();
		MyGdxGame.res.getSound("2").dispose();
		MyGdxGame.res.getSound("3").dispose();
		MyGdxGame.res.getSound("4").dispose();
		MyGdxGame.res.getSound("5").dispose();
		MyGdxGame.res.getSound("6").dispose();
		MyGdxGame.res.getSound("7").dispose();
		MyGdxGame.res.getSound("8").dispose();
		MyGdxGame.res.getSound("9").dispose();
		MyGdxGame.res.getSound("10").dispose();
		MyGdxGame.res.getSound("11").dispose();
		MyGdxGame.res.getSound("12").dispose();
		//this.dispose();
	}
	
	public static void loadSounds(){
		//Music
		res.loadMusic("mfx/bg_n.mp3", "bgMusic");
		res.loadMusic("mfx/spin.mp3", "spinMusic");
		
		//sounds
		res.loadSound("sfx/transblock.mp3", "transblock");
		res.loadSound("sfx/click.mp3", "click");
		res.loadSound("sfx/modes.mp3", "modes");
		res.loadSound("sfx/mismatch.mp3", "gameover");
		res.loadSound("sfx/fall.mp3", "fall");
		res.loadSound("sfx/1.mp3", "1");
		res.loadSound("sfx/2.mp3", "2");
		res.loadSound("sfx/3.mp3", "3");
		res.loadSound("sfx/4.mp3", "4");
		res.loadSound("sfx/5.mp3", "5");
		res.loadSound("sfx/6.mp3", "6");
		res.loadSound("sfx/7.mp3", "7");
		res.loadSound("sfx/8.mp3", "8");
		res.loadSound("sfx/9.mp3", "9");
		res.loadSound("sfx/10.mp3", "10");
		res.loadSound("sfx/11.mp3", "11");
		res.loadSound("sfx/12.mp3", "12");
	} 
	
	public static void loadAssets(){
		//res.loadTexture("ingame/Monkey_New.png", "monkeysprit");
		//res.loadTexture("json/slide.png", "slide");
	}
	
	public static void loadTexturePacker(){
		gameAtlas = new TextureAtlas("packers/gameplay/ingame.pack");
		uiAtlas = new TextureAtlas("packers/ui/ui.pack");
		tutAtlas = new TextureAtlas("packers/tutorial/tutorial.pack");
		psAtlas =  new TextureAtlas("packers/playstore/playstore.pack");
	}

	public SpriteBatch getSpriteBatch() {
		return this.batch;
	}

	public OrthographicCamera getCamera() {
		return this.camera;
	}
	
	public OrthographicCamera getRotCamera() {
		return this.rotCamera;
	}
	
	public OrthographicCamera getbgCamera() {
		return this.bgCamera;
	}
	
	public static BitmapFont getMediumFont() {
		return mFont;
	}
	public static BitmapFont getSmallFont() {
		return sFont;
	}
	public static BitmapFont getLargeFont() {
		return lFont;
	}
	
	@Override
	public void resize(int w, int h) {
		// TODO Auto-generated method stub
		viewport.update(w, h, true);
		batch.setProjectionMatrix(camera.combined);
		
		bgCamera.position.set(bgCamera.viewportWidth / 2, bgCamera.viewportHeight / 2, 0);
		bgCamera.update();
		rotCamera.position.set(rotCamera.viewportWidth / 2, rotCamera.viewportHeight / 2, 0);
		rotCamera.update();
		camera.position.set(camera.viewportWidth / 2, camera.viewportHeight / 2, 0);
		camera.update();                                                                                                   
	
	//	super.resize(w, h);
		
	}
	
	public static void resetInputControls() {
		// TODO Auto-generated method stub
		MyInputProcessor.isTapLeft=false;
		MyInputProcessor.isTapRight=false;
		MyInputProcessor.isSwipeLeft=false;
		MyInputProcessor.isSwipeRight=false;
		MyInputProcessor.isSwipeDown=false;
		MyInputProcessor.isSwipeUp=false;
	}
	private void PauseTheGame() {
		// TODO Auto-generated method stub
		if (GameStateManager.GAMEPLAY== constants.ConstantValues.stateNo) {
			if (!GamePlay.gameState.equals("pause") && !GamePlay.gameState.contains("gameover") && !GamePlay.gameState.contains("saveme")) {
				GamePlay.gameState = "pause";
			}
		}
		if (GameStateManager.ENDLESSPLAY== constants.ConstantValues.stateNo) {
			if (!EndlessPlay.gameState.equals("pause") && !EndlessPlay.gameState.contains("gameover")&& !EndlessPlay.gameState.contains("saveme")) {
				EndlessPlay.gameState="pause";
			}
		}
		if (GameStateManager.DASHPLAY== constants.ConstantValues.stateNo) {
			if (!DashPlay.gameState.equals("pause") && !DashPlay.gameState.contains("gameover")&& !DashPlay.gameState.contains("saveme")) {
				DashPlay.gameState="pause";
			}
		}
		if (GameStateManager.SPINPLAY== constants.ConstantValues.stateNo) {
			if (!SpinPlay.gameState.equals("pause") && !SpinPlay.gameState.contains("gameover")&& !SpinPlay.gameState.contains("saveme")) {
				SpinPlay.gameState="pause";
			}
		}
	}

	@Override
	public void pause() {
		SoundManager.stopBgMusic();
		PauseTheGame();
		super.pause();
	}

	@Override
	public void resume() {
		if (GameStateManager.MENU== constants.ConstantValues.stateNo) {
			SoundManager.playMenuMusic();
		}
		super.resume();
	}
}
