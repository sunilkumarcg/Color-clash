package com.m2fpremium.colorclash;

public class Template extends GameObject{
	public Template() {
		// TODO Auto-generated constructor stub	
	}
	
	@Override
	public float getHeight() {
		// TODO Auto-generated method stub
		return super.getHeight();
	}
	@Override
	public float getWidth() {
		// TODO Auto-generated method stub
		return super.getWidth();
	}

	@Override
	public float getX() {
		// TODO Auto-generated method stub
		return super.getX();
	}
	@Override
	public float getY() {
		// TODO Auto-generated method stub
		return super.getY();
	}
	@Override
	public void setX(float x) {
		// TODO Auto-generated method stub
		super.setX(x);
	}
	@Override
	public void setY(float y) {
		// TODO Auto-generated method stub
		super.setY(y);
	}
	@Override
	public void setSize(float width, float height) {
		// TODO Auto-generated method stub
		super.setSize(width, height);
	}
	
	@Override
	public void setPosition(float x, float y) {
		// TODO Auto-generated method stub
		super.setPosition(x, y);
	}

}
