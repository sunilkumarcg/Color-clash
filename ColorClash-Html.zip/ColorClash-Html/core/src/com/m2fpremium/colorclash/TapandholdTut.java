package com.m2fpremium.colorclash;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import constants.ConstantValues;

public class TapandholdTut {

	public static Sprite tutSprite;
	static Animation tutAnimation,tutTapAnimation;
	public static float tutAnimSpeed=0.6f;
	public static boolean showTut = false;
	
	public static int swipeDownLmt = ConstantValues.CAMERA_HEIGHT/4;
	public static int swipeUpLmt = ConstantValues.CAMERA_HEIGHT/2+100;
	
	public static int swipeLeftLmt = ConstantValues.CAMERA_WIDTH/2 - 250;
	public static int swipeInt = ConstantValues.CAMERA_WIDTH/2;
	public static int swipeRgtLmt = ConstantValues.CAMERA_WIDTH/2 + 250;
	
	public TapandholdTut() {
		// TODO Auto-generated constructor stub
		showTut=false;
		tutAnimation = new Animation(tutAnimSpeed, MyGdxGame.tutAtlas.findRegions("hand"),Animation.PlayMode.LOOP);
		tutTapAnimation = new Animation(tutAnimSpeed, MyGdxGame.tutAtlas.findRegions("tap"),Animation.PlayMode.LOOP);
		tutSprite = new Sprite(MyGdxGame.tutAtlas.findRegion("hand",1));
		tutSprite.setPosition(ConstantValues.CAMERA_WIDTH/2, ConstantValues.CAMERA_HEIGHT/2);
	}
	
	public static void update(float f) {
		// TODO Auto-generated method stub
		ConstantValues.elapsedTime += f;
		
		if (!ConstantValues.isSpinTutorial && GameStateManager.SPINPLAY==ConstantValues.stateNo) {
			tutSprite.setRegion(tutAnimation.getKeyFrame(ConstantValues.elapsedTime,true));	
		}
		else
		{
			tutSprite.setRegion(tutTapAnimation.getKeyFrame(ConstantValues.elapsedTime,true));	
		}
		if (!ConstantValues.isClassicTutorial && (GameStateManager.GAMEPLAY==ConstantValues.stateNo || GameStateManager.ENDLESSPLAY==ConstantValues.stateNo)) {
			if (ConstantValues.classicCnt==0 && ConstantValues.isClassicLeft && ConstantValues.isClassicRight) {
				tutSprite.setPosition(ConstantValues.CAMERA_WIDTH/2+200, tutSprite.getY()-8);
				if (tutSprite.getY() < swipeDownLmt) {
					tutSprite.setPosition(ConstantValues.CAMERA_WIDTH/2+200, swipeUpLmt);
				}
			}
			else if (ConstantValues.classicCnt==1 && !ConstantValues.isClassicLeft) {
				tutSprite.setPosition(tutSprite.getX()-4,  ConstantValues.CAMERA_HEIGHT/2-ConstantValues.CAMERA_HEIGHT/4);
				if (tutSprite.getX() < swipeLeftLmt) {
					tutSprite.setPosition(swipeInt, ConstantValues.CAMERA_HEIGHT/2-ConstantValues.CAMERA_HEIGHT/4);
				}
			}
			else if (ConstantValues.classicCnt==1 && !ConstantValues.isClassicRight) {
				tutSprite.setPosition(tutSprite.getX()+4,  ConstantValues.CAMERA_HEIGHT/2-ConstantValues.CAMERA_HEIGHT/4);
				if (tutSprite.getX() > swipeRgtLmt) {
					tutSprite.setPosition(swipeInt, ConstantValues.CAMERA_HEIGHT/2-ConstantValues.CAMERA_HEIGHT/4);
				}
			}
		//	System.out.println(""+ConstantValues.classicCnt+ConstantValues.isClassicLeft);
		}	
	
	}
	
	public static void render(SpriteBatch batch) {
		// TODO Auto-generated method stub
		if(showTut)
		{
			if (!ConstantValues.isSpinTutorial && GameStateManager.SPINPLAY==ConstantValues.stateNo) {
				tutSprite.draw(batch);
			}
			if (!ConstantValues.isTapTapTutorial && GameStateManager.DASHPLAY==ConstantValues.stateNo) {	
				tutSprite.draw(batch);
			}
			if (!ConstantValues.isClassicTutorial && GameStateManager.GAMEPLAY==ConstantValues.stateNo) {	
				tutSprite.draw(batch);
			}
			if (!ConstantValues.isClassicTutorial && GameStateManager.ENDLESSPLAY==ConstantValues.stateNo) {	
				tutSprite.draw(batch);
			}
		}
	}
}
