package com.m2fpremium.colorclash;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class BestscoreImg {

	Sprite bestscoreSprite;
	public static float sprZoom=0.0f;
	public static boolean bestScoreBool=false;
	
	public BestscoreImg() {
		// TODO Auto-generated constructor stub
		sprZoom=0.0f;
		bestScoreBool=false;
		bestscoreSprite = new Sprite(MyGdxGame.uiAtlas.findRegion("bestach"));
		bestscoreSprite.setPosition(constants.ConstantValues.CAMERA_WIDTH/2-bestscoreSprite.getWidth()/2, -1000);
	}
	
	public void update(float f) {
		// TODO Auto-generated method stub
		if (bestScoreBool && sprZoom <1.5f) {
			sprZoom=sprZoom+0.025f;
			bestscoreSprite.setPosition(bestscoreSprite.getX(), constants.ConstantValues.CAMERA_HEIGHT/2-bestscoreSprite.getHeight()/2);
			if (Levels.mode.equals("mixup")) {
				if (Levels.blockPlace.equals("mid")) {
					bestscoreSprite.setPosition(bestscoreSprite.getX(), constants.ConstantValues.CAMERA_HEIGHT/2+200);
				}
				else
				{
					bestscoreSprite.setPosition(bestscoreSprite.getX(), constants.ConstantValues.CAMERA_HEIGHT/2-bestscoreSprite.getHeight()/2);
				}
			}

			bestscoreSprite.setScale(sprZoom);
		}	
	}
	
	public void render(SpriteBatch batch) {
		// TODO Auto-generated method stub
		if (bestScoreBool  && sprZoom <1.5f) {
			bestscoreSprite.draw(batch);
		}
	}
	
}
