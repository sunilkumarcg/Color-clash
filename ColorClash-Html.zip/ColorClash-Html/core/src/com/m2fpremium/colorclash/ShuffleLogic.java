package com.m2fpremium.colorclash;

import java.util.Random;

public class ShuffleLogic {

	public static void shuffleArray(int[] ar) {
		// TODO Auto-generated method stub
		Random rnd = new Random();

		for (int i = ar.length - 1; i > 0; i--) {
			int index = rnd.nextInt(i + 1);
			// Simple swap
			int a = ar[index];
			ar[index] = ar[i];
			ar[i] = a;
		}
	}
	
	public static void resetSymbols(String dir) {
		// TODO Auto-generated method stub
		
		int[] seqArray= new int[4];
		for (int i = 0; i < SquareBlock.symSequence.length; i++) {
			seqArray[i]=SquareBlock.symSequence[i];
		}
		if (dir.equals("left")) {
			SquareBlock.symSequence[0] = seqArray[1];
			SquareBlock.symSequence[1] = seqArray[2];
			SquareBlock.symSequence[2] = seqArray[3];
			SquareBlock.symSequence[3] = seqArray[0];
		}
		else
		{
			SquareBlock.symSequence[0] = seqArray[3];
			SquareBlock.symSequence[1] = seqArray[0];
			SquareBlock.symSequence[2] = seqArray[1];
			SquareBlock.symSequence[3] = seqArray[2];
		}
	
		/*for (int i = 0; i < seqArray.length; i++) {
			System.out.println("symbols"+symSequence[i]);
		}*/
	}
	
	public static void resetSquareSymbols(String dir) {
		// TODO Auto-generated method stub
		
		int[] seqArray= new int[4];
		for (int i = 0; i < SpinSquareBlock.symSequence.length; i++) {
			seqArray[i]=SpinSquareBlock.symSequence[i];
		}
		if (dir.equals("left")) {
			SpinSquareBlock.symSequence[0] = seqArray[1];
			SpinSquareBlock.symSequence[1] = seqArray[2];
			SpinSquareBlock.symSequence[2] = seqArray[3];
			SpinSquareBlock.symSequence[3] = seqArray[0];
		}
		else
		{
			SpinSquareBlock.symSequence[0] = seqArray[3];
			SpinSquareBlock.symSequence[1] = seqArray[0];
			SpinSquareBlock.symSequence[2] = seqArray[1];
			SpinSquareBlock.symSequence[3] = seqArray[2];
		}
	
		/*for (int i = 0; i < seqArray.length; i++) {
			System.out.println("symbols"+SpinSquareBlock.symSequence[i]);
		}*/
	}


	public static void resetEndlessSquareSymbols(String dir) {
		// TODO Auto-generated method stub
		
		int[] seqArray= new int[4];
		for (int i = 0; i < EndlessSquareBlock.symSequence.length; i++) {
			seqArray[i]=EndlessSquareBlock.symSequence[i];
		}
		if (dir.equals("left")) {
			EndlessSquareBlock.symSequence[0] = seqArray[1];
			EndlessSquareBlock.symSequence[1] = seqArray[2];
			EndlessSquareBlock.symSequence[2] = seqArray[3];
			EndlessSquareBlock.symSequence[3] = seqArray[0];
		}
		else
		{
			EndlessSquareBlock.symSequence[0] = seqArray[3];
			EndlessSquareBlock.symSequence[1] = seqArray[0];
			EndlessSquareBlock.symSequence[2] = seqArray[1];
			EndlessSquareBlock.symSequence[3] = seqArray[2];
		}
	
		/*for (int i = 0; i < seqArray.length; i++) {
			System.out.println("symbols"+SpinSquareBlock.symSequence[i]);
		}*/
	}

}
