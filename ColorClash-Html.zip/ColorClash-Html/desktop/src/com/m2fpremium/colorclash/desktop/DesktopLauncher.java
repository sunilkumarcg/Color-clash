package com.m2fpremium.colorclash.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.m2fpremium.colorclash.MyGdxGame;

public class DesktopLauncher {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
	/*	config.orientationPortrait=true;
		config.orientationLandscape=false;
		*/
		config.width=400;
		config.height=640;


		String osName= System.getProperty("os.name");

		System.out.println(osName+"is os");

		new LwjglApplication(new MyGdxGame(), config);
	}
}
