package com.m2fpremium.colorclash.client;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Graphics;
import com.badlogic.gdx.backends.gwt.GwtApplication;
import com.badlogic.gdx.backends.gwt.GwtApplicationConfiguration;
import com.badlogic.gdx.backends.gwt.GwtGraphics;
import com.google.gwt.dom.client.Document;
import com.google.gwt.dom.client.Style;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.user.client.Window;
import com.m2fpremium.colorclash.DashPlay;
import com.m2fpremium.colorclash.EndlessPlay;
import com.m2fpremium.colorclash.GamePlay;
import com.m2fpremium.colorclash.GameStateManager;
import com.m2fpremium.colorclash.HtmlInterface;
import com.m2fpremium.colorclash.MyGdxGame;
import com.m2fpremium.colorclash.SpinPlay;

public class HtmlLauncher extends GwtApplication implements HtmlInterface {

        GwtApplicationConfiguration gwtApplicationConfiguration;

        @Override
        public GwtApplicationConfiguration getConfig () {

            String osVerName = "";

            try
            {
                osVerName = Window.Navigator.getPlatform();
            }
            catch(Exception e)
            {}

                if(osVerName.contains("Win"))
                {
                        gwtApplicationConfiguration = new GwtApplicationConfiguration(400, 640);
                }
                else {
                        int w = Window.getClientWidth();
                        int h = Window.getClientHeight();

                    if(w<h)
                        gwtApplicationConfiguration = new GwtApplicationConfiguration(w, h);
                    else
                        gwtApplicationConfiguration = new GwtApplicationConfiguration(h, w);

                    gwtApplicationConfiguration.fullscreenOrientation = GwtGraphics.OrientationLockType.PORTRAIT;
                        Window.enableScrolling(false);
                        Window.setMargin("0");
                        Window.scrollTo(0, 1);
                        Window.addResizeHandler(new ResizeListener());
                        gwtApplicationConfiguration.antialiasing = true;
                        gwtApplicationConfiguration.preferFlash = false;


                }
                return gwtApplicationConfiguration;
        }

        @Override
        public ApplicationListener createApplicationListener () {
                return new MyGdxGame(this);
        }

        @Override
        public void scrollWindow() {
            Document.get().getElementById("fullscreen").getStyle().setDisplay(Style.Display.BLOCK);
        }

    @Override
    public void showAds() {
        Document.get().getElementById("fullscreen").getStyle().setDisplay(Style.Display.BLOCK);
        Document.get().getElementById("fullscreen").getStyle().setZIndex(3);
    }

    @Override
    public void updateGame() {

        int index=Integer.parseInt(Document.get().getElementById("fullscreen").getStyle().getZIndex());
        if(index==4)
        {
            PauseTheGame();
        }
    }
    private void PauseTheGame() {
        // TODO Auto-generated method stub
        if (GameStateManager.GAMEPLAY== constants.ConstantValues.stateNo) {
            if (!GamePlay.gameState.equals("pause") && !GamePlay.gameState.contains("gameover") && !GamePlay.gameState.contains("saveme")) {
                GamePlay.gameState = "pause";
            }
        }
        if (GameStateManager.ENDLESSPLAY== constants.ConstantValues.stateNo) {
            if (!EndlessPlay.gameState.equals("pause") && !EndlessPlay.gameState.contains("gameover")&& !EndlessPlay.gameState.contains("saveme")) {
                EndlessPlay.gameState="pause";
            }
        }
        if (GameStateManager.DASHPLAY== constants.ConstantValues.stateNo) {
            if (!DashPlay.gameState.equals("pause") && !DashPlay.gameState.contains("gameover")&& !DashPlay.gameState.contains("saveme")) {
                DashPlay.gameState="pause";
            }
        }
        if (GameStateManager.SPINPLAY== constants.ConstantValues.stateNo) {
            if (!SpinPlay.gameState.equals("pause") && !SpinPlay.gameState.contains("gameover")&& !SpinPlay.gameState.contains("saveme")) {
                SpinPlay.gameState="pause";
            }
        }
    }
    class ResizeListener implements ResizeHandler {
                @Override
                public void onResize(ResizeEvent event) {
                    String osVerName = "";
                    try
                    {
                        osVerName = Window.Navigator.getPlatform();
                    }
                    catch(Exception e)
                    {}

                   // Gdx.graphics.setWindowedMode(Gdx.graphics.getDisplayMode().width, Gdx.graphics.getDisplayMode().height);

                    Graphics.DisplayMode mode = Gdx.graphics.getDisplayMode();
                    Gdx.graphics.setFullscreenMode(mode);

                    int height = Window.getClientHeight();

                    if(osVerName.contains("Win"))
                    {
                    }
                    else if(height<Gdx.graphics.getHeight())
                    {
                     /*   getApplicationListener().resize(  event.getWidth() ,event.getHeight());
                        resizeGame();*/
                        Document.get().getElementById("fullscreen").getStyle().setDisplay(Style.Display.BLOCK);
                    }
                    else if(height>=Gdx.graphics.getHeight())
                    {
                       /* getApplicationListener().resize(  event.getWidth() ,event.getHeight());
                        resizeGame();*/
                        Document.get().getElementById("fullscreen").getStyle().setDisplay(Style.Display.NONE);
                    }
                }
        }

}