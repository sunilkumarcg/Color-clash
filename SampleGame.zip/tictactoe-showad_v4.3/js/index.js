var grid = document.getElementById('grid');
var msg = document.querySelector('.message');
var chooser = document.querySelector('form');
var mark, selectedPlayer;
var cells;

//initialization of Jiogames SDK
var jioGamesSdk = new Jiogames();
var isInterstitialReady = false;
var isRewardedVideoReady = false;
var isInStreamVideoReady = false;

var AdSpot_Interstitial = "a90c53ce";
var AdSpot_RewardedVideo = "de0b6358";
var AdSpot_InStreamVideo = "V470232e2";
var GamePackage = "com.jio.jiogames"

/*try {
    jioGamesSdk.cacheAd("b906aa91", "com.jio.jiogames");
} catch (err) {
    console.log("cacheAd err: ", err);
}
*/
//console.log("--------",jioGamesSdk)
// add click listener to radio buttons

document.addEventListener('DOMContentLoaded', (event) => {
    console.log('DOM fully loaded and parsed');

    setTimeout(function () {
        alert("Sound Enabled? " + jioGamesSdk.isSoundEnable());
    }, 2000);

    jioGamesSdk.cacheAd(AdSpot_Interstitial, GamePackage);
    jioGamesSdk.cacheInStreamAds(AdSpot_InStreamVideo, GamePackage);
    jioGamesSdk.cacheAdRewarded(AdSpot_RewardedVideo, GamePackage);

});

////////////////////////////////////
    window.onAdReady = function (adSpot) {
        var localAdSpot = ""+adSpot.replace('"','');
        adSpot = localAdSpot;
        localAdSpot = ""+adSpot.replace('"','');
        adSpot = localAdSpot;


        localAdSpot == AdSpot_Interstitial && (isInterstitialReady = true, console.log("onAdReady Interstitial " +isInterstitialReady));
        localAdSpot == AdSpot_RewardedVideo && (isRewardedVideoReady = true, console.log("onAdReady RewardedVideo "+isRewardedVideoReady));
        localAdSpot == AdSpot_InStreamVideo && (isInStreamVideoReady = true, console.log("onAdReady InStream "+isInStreamVideoReady));
    };

    window.onAdError = function (adSpot, errorMessage) {
        console.log("window.onAdError: " + adSpot + " errorMessage: " + errorMessage);
        var localAdSpot = ""+adSpot.replace('"','');
        adSpot = localAdSpot;
        localAdSpot = ""+adSpot.replace('"','');
        adSpot = localAdSpot;
        localAdSpot == AdSpot_Interstitial && (isInterstitialReady = false, console.log("onAdError Intestitial "+isInterstitialReady));
        localAdSpot == AdSpot_RewardedVideo && (isRewardedVideoReady = false, console.log("onAdError Rewarded Video "+isRewardedVideoReady));
        localAdSpot == AdSpot_InStreamVideo && (isInStreamVideoReady = false, console.log("onAdError InStream "+isInStreamVideoReady));

//        alert("window.onAdError "+adSpot+" Interstitial "+isInterstitialReady+" Rewarded Video "+isRewardedVideoReady+" InStream "+isInStreamVideoReady);
    };

    window.onAdClick = function (adSpot) {
        //alert("window.onAdClick AdSpot " + adSpot);
        console.log("window.onAdClick: " + adSpot);
    };

    window.onAdClose = function (adSpot) {
        console.log("window.onAdClick: " + adSpot);
        var localAdSpot = ""+adSpot.replace('"','');
        adSpot = localAdSpot;
        localAdSpot = ""+adSpot.replace('"','');
        adSpot = localAdSpot;
        localAdSpot == AdSpot_Interstitial && (isInterstitialReady = false, console.log("onAdClose Intestitial "+isInterstitialReady));
        localAdSpot == AdSpot_RewardedVideo && (isRewardedVideoReady = false, console.log("onAdClose Rewarded Video "+isRewardedVideoReady));
        localAdSpot == AdSpot_InStreamVideo && (isInStreamVideoReady = false, console.log("onAdClose InStream "+isInStreamVideoReady));

//        alert("window.onAdClose "+adSpot+" Interstitial "+isInterstitialReady+" Rewarded Video "+isRewardedVideoReady+" InStream "+isInStreamVideoReady);
    };

    window.onAdMediaEnd = function (adSpot, success, value) {
//        alert("window.onAdMediaEnd "+adSpot+" success "+success+" value "+value);
        console.log("window.onAdMediaEnd: " + adSpot + " success: " + success + " value: " + value);
    };

    window.onAdMediaStart = function (adSpot) {
        console.log("window.onAdMediaStart: " + adSpot);
    };

    window.onAdMediaExpand = function (adSpot) {
        console.log("window.onAdMediaExpand: " + adSpot);
    };

    window.onAdMediaCollapse = function (adSpot) {
        console.log("window.onAdMediaCollapse: " + adSpot);
    };

    window.onAdSkippable = function (adSpot) {
        console.log("window.onAdSkippable: " + adSpot);
    };

    window.onAdView = function (adSpot) {
        console.log("window.onAdView: " + adSpot);
    };

    window.onAdRefresh = function (adSpot) {
        console.log("window.onAdRefresh: " + adSpot);
    };

    window.onAdRender = function (adSpot) {
        console.log("window.onAdRender: " + adSpot);
    };
///////////////////////////////////


function setPlayer() {
    mark = this.value;
    selectedPlayer = mark;
    msg.textContent = mark + ', click on a square to make your move!';
    /*console.log(selectedPlayer);*/
    chooser.classList.add('game-on');
    this.checked = false;
    buildGrid();

//    window.onAdReady("\"a90c53ce\"");
//    window.onAdReady(AdSpot_InStreamVideo);
//    window.onAdReady(AdSpot_RewardedVideo);

    if (!isRewardedVideoReady) {
        jioGamesSdk.cacheAdRewarded(AdSpot_RewardedVideo, GamePackage);
    }
    if (!isInStreamVideoReady) {
        jioGamesSdk.cacheAdInstream(AdSpot_InStreamVideo, GamePackage);
    }
    try {
        jioGamesSdk.setInStreamControl(AdSpot_InStreamVideo, true);
    }catch(exception) {
        console.log("setInStreamControl "+exception);
    }
//    alert("Show Intestitial "+isInterstitialReady);
    if (isInterstitialReady) {
        jioGamesSdk.showAd(AdSpot_Interstitial, GamePackage);
    }
//    jioGamesSdk.showAdInstream("V470232e2", "com.jio.jiogames");
}

// add click listener to each cell
function playerMove() {
    if (this.textContent == '') {
        this.textContent = mark;
        checkRow();
        switchMark();
        computerMove();
    }
}

// let the computer make the next move
function computerMove() {
    var emptyCells = [];
    var random;

    /*  for (var i = 0; i < cells.length; i++) {
        if (cells[i].textContent == '') {
          emptyCells.push(cells[i]);
        }
      }*/

    cells.forEach(function(cell) {
        if (cell.textContent == '') {
            emptyCells.push(cell);
        }
    });

    // computer marks a random EMPTY cell
    random = Math.ceil(Math.random() * emptyCells.length) - 1;
    emptyCells[random].textContent = mark;
    checkRow();
    switchMark();
}

// switch player mark
function switchMark() {
    if (mark == 'X') {
        mark = 'O';
    } else {
        mark = 'X';
    }
}

// determine a winner
function winner(a, b, c) {

    if (a.textContent == mark && b.textContent == mark && c.textContent == mark) {
        msg.textContent = mark + ' is the winner!';
        /* 
        b906aa91
        29b9b700
        5ebe8796
        */
        // show the cached 
        let layout = document.querySelector("#grid-section");
        layout.hidden = true;
        setTimeout(function() {
            resetGrid();
            layout.hidden = false;
        }, 1000);
        try {
            // jioGamesSdk.showAd("b906aa91", "com.jio.jiogames");
             //jioGamesSdk.showAd("7f877c43", "com.jio.jiogames");
//             alert("Show InStream "+isInStreamVideoReady);
            if (isInStreamVideoReady) {
                jioGamesSdk.showAdInstream(AdSpot_InStreamVideo, GamePackage);
             }
//            jioGamesSdk.showAd("a90c53ce", "com.jio.jiogames");
        } catch (err) {
            console.log("showAd err: ", err);
        }
        if (mark == selectedPlayer) {
            // post the score
            try {
                jioGamesSdk.postScore(1);
            } catch (err) {
                console.log("postScore err: ", err);
            }
        }
        a.classList.add('winner');
        b.classList.add('winner');
        c.classList.add('winner');
        return true;
    } else {
        return false;
    }

}

// check cell combinations 
function checkRow() {
    winner(document.getElementById('c1'), document.getElementById('c2'), document.getElementById('c3'));
    winner(document.getElementById('c4'), document.getElementById('c5'), document.getElementById('c6'));
    winner(document.getElementById('c7'), document.getElementById('c8'), document.getElementById('c9'));
    winner(document.getElementById('c1'), document.getElementById('c4'), document.getElementById('c7'));
    winner(document.getElementById('c2'), document.getElementById('c5'), document.getElementById('c8'));
    winner(document.getElementById('c3'), document.getElementById('c6'), document.getElementById('c9'));
    winner(document.getElementById('c1'), document.getElementById('c5'), document.getElementById('c9'));
    winner(document.getElementById('c3'), document.getElementById('c5'), document.getElementById('c7'));
}

// clear the grid
function resetGrid() {
    mark = 'X';
    /* for (var i = 0; i < cells.length; i++) {
       cells[i].textContent = '';
       cells[i].classList.remove('winner');
     }*/
    cells.forEach(function(cell) {
        cell.textContent = '';
        cell.classList.remove('winner');
    });
    msg.textContent = 'Choose your player:';
    chooser.classList.remove('game-on');
    grid.innerHTML = '';
}

// build the grid
function buildGrid() {
    for (var i = 1; i <= 9; i++) {
        var cell = document.createElement('li');
        cell.id = 'c' + i;
        cell.addEventListener('click', playerMove, false);
        grid.appendChild(cell);
    }
    /* cells = document.querySelectorAll('li'); //Returns a NodeList, not an Array
    See https://css-tricks.com/snippets/javascript/loop-queryselectorall-matches */
    cells = Array.prototype.slice.call(grid.getElementsByTagName('li'));
}

var players = Array.prototype.slice.call(document.querySelectorAll('input[name=player-choice]'));
players.forEach(function(choice) {
    choice.addEventListener('click', setPlayer, false);
});

var resetButton = chooser.querySelector('button');
resetButton.addEventListener('click', function(e) {
    console.log ("Reset Button Click");
//    alert("Show Rewarded Video "+isRewardedVideoReady);
    if (isRewardedVideoReady) {
        jioGamesSdk.showAdRewarded(AdSpot_RewardedVideo, GamePackage);
    }
    e.preventDefault();
    resetGrid();
});
