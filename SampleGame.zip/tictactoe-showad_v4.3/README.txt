A Pen created at CodePen.io. You can find this one at https://codepen.io/cannanso/pen/vLNwmw.

 Allow player to choose 'X' or 'O'. It is possible to beat the computer! Written in pure JS.